import React from "react";
import { ReactComponent as DashboardIcon } from "../../Assets/Icon/Pie.svg";
import { ReactComponent as UserIcon } from "../../Assets/Icon/user.svg";
import { ReactComponent as ProductIcon } from "../../Assets/Icon/product.svg";
import { ReactComponent as OrderIcon } from "../../Assets/Icon/order.svg";
import { ReactComponent as WebIcon } from "../../Assets/Icon/Web.svg";
import {ReactComponent as MobileIcon} from "../../Assets/Icon/Mobile.svg";
import { ReactComponent as CmsIcon } from "../../Assets/Icon/Cms.svg";
import { ReactComponent as CommentIcon} from "../../Assets/Icon/Comment.svg";
import Path from "../../Constant/RouterConstant";

export const SidebarData = [
  {
    title: "Dashboard",
    icon: <DashboardIcon />,
    link: Path.dashboard,
  },
  {
    title: "User Management",
    icon: <UserIcon />,
    link: Path.customer,

    subMenus: [
      {
        title: "Customer",
        link: Path.customer,
      },
      // {
      //   title: "Chef",
      //   link: Path.chef,
      // },
    ],
  },
  {
    title: "Catalog Management",
    icon: <ProductIcon />,
    link: Path.allItems,

    subMenus: [
      // {
      //   title: "All Recipe",
      //   link: Path.allItems,
      // },
      {
        title: "Products",
        link: Path.products,
      },
      {
        title: "Attributes",
        link: Path.attribute,
      },
      {
        title: "Categories",
        link: Path.categories,
      },
      {
        title: "Sub Categories",
        link: Path.subcategory,
      },
      {
        title: "Tags",
        link: Path.tags,
      },
      // {
      //   title: "Offers",
      //   link: Path.discount,
      // },
      // {
      //   title: "Promotion",
      //   link: Path.promotion,
      // }
    ],
  },
  {
    title: "Web Management",
    icon: <WebIcon />,

    subMenus: [
      {
        title: "Header Banner",
        link: Path.banner,
      },
      {
        title: "Promotional Banner",
        link: Path.banners,
      },
      {
        title: "Brand",
        link: Path.brand,
      },
      {
        title: "Partners",
        link: Path.partner,
      },
      // {
      //   title: "Pincode",
      //   link: Path.pincode,
      // },
      {
        title: "GST",
        link: Path.gst,
      },
      {
        title: "Unit",
        link: Path.unit,
      }
    ],
  },

  {
    title: "Mobile Management",
    icon: <MobileIcon />,

    subMenus: [
      {
        title: "Mobile Promotional Banner",
        link: Path.mobilebanner,
      },
    ],
  },

  {
    title: "Social Activities",
    icon: <CommentIcon />,
    subMenus: [
      {
        title: "Feedback",
        link: Path.feedback,
      },
      {
        title: "Reason",
        link: Path.reason,
      },
      {
        title: "Reviews",
        link: Path.reviews,
      },
    ]
  },
  {
    title: "Sales",
    icon: <OrderIcon />,

    subMenus: [
      {
        title: "Orders",
        link: Path.orders,
      },
    ],
  },
  {
    title: "CMS",
    icon: <CmsIcon />,

    subMenus: [
      {
        title: "About us",
        link: Path.about,
      },
      {
        title: "Shipping and Return",
        link: Path.shipping,
      },
      {
        title: "Privacy and Policy",
        link: Path.privacy,
      },
      {
        title: "Terms and Conditions",
        link: Path.terms,
      },
    ],
  },
];
