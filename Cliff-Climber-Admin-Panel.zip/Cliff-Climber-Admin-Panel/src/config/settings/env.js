export const development = {
  api: {
    url: "http://192.168.7.204:8081/api/",
    // url: "http://localhost:8081/api/",
    mode: "cors",
  },
};

export const staging = {
  api: {
    url: "http://192.168.7.204:8081/api/",
    // url:"http://localhost:8081/api/",
    mode: "cors",
  },
};

export const imageUrl = "http://192.168.7.204:8081/";
// export const imageUrl = "http://localhost:8081/"


// export const development = {
//   api: {
//     url: "http://192.168.29.127:8081/api/",
//     mode: "cors",
//   },
// };

// export const staging = {
//   api: {
//     url: "http://192.168.29.127:8081/api/",
//     mode: "cors",
//   },
// };

// export const imageUrl = "http://192.168.29.127:8081/";
