import setting from "./settings";

export default (() => {
  return {
    // Basic Auth
    AUTH: setting.api.AUTH,

    // Auth
    login: `${setting.api.url}authenticateadmin`,
    logout: `${setting.api.url}auth/logout`,
    signup: `${setting.api.url}signup`,
    forgotPassword: `${setting.api.url}forgot-password`,
    resetPassword: `${setting.api.url}resetPassword`,
    changePassword: `${setting.api.url}auth/changepassword`,

    // user
    userProfile: `${setting.api.url}auth/profile`,
    viewuserProfile: `${setting.api.url}auth/profile`,
    changeProfileImage: `${setting.api.url}auth/profile-image`,

    // Customer
    customers: `${setting.api.url}admin/getusers`,
    getcustomerDetails: `${setting.api.url}admin/complete-user-details`,
    getcustomerDetail: `${setting.api.url}admin/getuserdetails`,
    deletecustomers: `${setting.api.url}admin/user`,
    discontinueCustomer: `${setting.api.url}admin/confirmuser`,

    // Category
    category: `${setting.api.url}admin/category`,
    editCategory: `${setting.api.url}admin/editcategory`,
    categories: `${setting.api.url}category`,
    deletecategories: `${setting.api.url}admin/deletecategory`,
    catergoryById: `${setting.api.url}category`,
    setCategoryPriority: `${setting.api.url}admin/set-category-priority`,
    deleteCategoryImage: `${setting.api.url}admin/deleteCategoryImage`,
     
    // Category Status
     categoryStatus: `${setting.api.url}admin/category/status`,

    // Sub Category
    subCategory: `${setting.api.url}admin/subcategory`,
    subcategoryFun: `${setting.api.url}subcategory`,
    deleteSubcategories: `${setting.api.url}admin/deletesubcategory`,
    subcatergoryById: `${setting.api.url}subcategory`,
    editSubCategory: `${setting.api.url}admin/editsubcategory`,
    subCatStatus: `${setting.api.url}admin/subcategory/status`,


    // Banner
    addBanner: `${setting.api.url}admin/banner`,
    viewBannerFun: `${setting.api.url}banner`,
    editBannerFun: `${setting.api.url}admin/editbanner`,
    deleteBanner: `${setting.api.url}admin/deletebanner`,
    viewBannerbyId: `${setting.api.url}banner`,
    bannerStatus: `${setting.api.url}admin/banner/status`,

    // //Chef
    // chefDetails: `${setting.api.url}admin/getallchef`,
    // getchefDetails: `${setting.api.url}admin/complete-user-details`,
    // getchefDetail: `${setting.api.url}common/chef-profile`,
    // confirmChef: `${setting.api.url}admin/confirmchef`,
    // deleteChef: `${setting.api.url}admin/user`,

    // tags
    getAllTags: `${setting.api.url}tag`,
    addTag: `${setting.api.url}admin/tag`,
    editTag: `${setting.api.url}admin/edittag`,
    deleteTag: `${setting.api.url}admin/deletetag`,
    getTagId: `${setting.api.url}tag`,
    tagStatus: `${setting.api.url}admin/tag/status`,

    // Brand
    getAllBrand: `${setting.api.url}brand`,
    addBrand: `${setting.api.url}admin/brand`,
    editBrand: `${setting.api.url}admin/editbrand`,
    deleteBrand: `${setting.api.url}admin/deletebrand`,
    getBrandbyId: `${setting.api.url}brand`,
    brandStatus: `${setting.api.url}admin/brand/status`,

    // // All Items
    // allItemsList: `${setting.api.url}admin/getrecpies`,
    // allItembyId: `${setting.api.url}admin/getrecpiedetails`,
    // confirmItem: `${setting.api.url}admin/confirmrecipie`,
    // deleteItem: `${setting.api.url}admin/recipe`,
    // updateRecipe: `${setting.api.url}admin/recipe`,
    // updateRecipeImage: `${setting.api.url}chef/recipe-image`,
    // deleteRecipeImage: `${setting.api.url}admin/delete-image`,

    // //Tax
    // addTax: `${setting.api.url}admin/tax`,
    // editTax: `${setting.api.url}admin/edittax`,
    // getTax: `${setting.api.url}admin/gettaxes`,
    // deleteTax: `${setting.api.url}admin/deletetax`,

    // //Discount
    // getAllCoupans: `${setting.api.url}common/genrate-discount-coupan`,
    // addCoupans: `${setting.api.url}admin/genrate-discount-coupan`,
    // editCoupans: `${setting.api.url}admin/genrate-discount-coupan`,
    // deleteCoupans: `${setting.api.url}admin/delete-genrate-discount-coupan`,
    // getCoupansByID: `${setting.api.url}common/genrate-discount-coupan`,

    // Discount Image
    editOfferImage: `${setting.api.url}admin/edit-offer-image`,

    //Orders
    getAllOrders: `${setting.api.url}admin/getorders`,
    getOrdersByID: `${setting.api.url}admin/getorderdetails`,
    // Pending Order
    getAllPendingOrders: `${setting.api.url}admin/getorders/1`,
    // Approved Order
    getAllApprovedOrders: `${setting.api.url}admin/getorders/2`,
    // Completed Order
    getAllCompletedOrders: `${setting.api.url}admin/getorders/3`,
    // Rejected Order
    getAllRejectedOrders: `${setting.api.url}admin/getorders/4`,
    // Pending Order
    getAllCancelledOrders: `${setting.api.url}admin/getorders/5`,

    // Dashboard
    dashboardService: `${setting.api.url}admin/dashboard`,
    getSalesReportByToday: `${setting.api.url}admin/getSalesReportByToday`,
    getSalesReportByWeek: `${setting.api.url}admin/getSalesReportByWeek`,
    getSalesReportByMonth: `${setting.api.url}admin/getSalesReportByMonth`,

    // // Food
    // getAllFood: `${setting.api.url}common/food-filter-category`,
    // addFood: `${setting.api.url}admin/add-food-filter-category`,
    // editFood: `${setting.api.url}admin/edit-food-filter-category`,
    // deleteFood: `${setting.api.url}admin/delete-food-filter-category`,
    // getFoodbyId: `${setting.api.url}common/food-filter-category`,

    //Promotion
    getAllPromotion: `${setting.api.url}promotionalbanner`,
    addPromotion: `${setting.api.url}admin/promotionalbanner`,
    getPromotionById: `${setting.api.url}promotionalbanner`,
    deletePromotion: `${setting.api.url}admin/deletepromotionalbanner`,
    editPromotionImage: `${setting.api.url}admin/editPromotionalBannerImage`,
    // editPromotion: `${setting.api.url}admin/edit-promotion`,
    promotionalBannerStatus: `${setting.api.url}admin/Promotionalbanner/status`,

    //Partners
    viewPartner: `${setting.api.url}partnerlogo`,
    addPartner: `${setting.api.url}admin/partnerlogo`,
    editPartner: `${setting.api.url}admin/editpartnerlogo`,
    deletePartner: `${setting.api.url}admin/deletepartnerlogo`,
    
    viewPartnerbyId: `${setting.api.url}partnerlogo`,
    partnerStatus: `${setting.api.url}admin/partnerlogo/status`,
    

     // attribute
     attribute: `${setting.api.url}admin/attribute`,
     getAttribute: `${setting.api.url}attribute`,
     attributeStatus: `${setting.api.url}admin/attribute/status`,
     editAttibute: `${setting.api.url}admin/editattribute`,
     singleAttribute: `${setting.api.url}attribute`,
     deleteAttribute: `${setting.api.url}admin/deleteattribute`,
     deleteAttributeOption: `${setting.api.url}admin/deleteattributeoption`,

    //Pincode
    addPincode: `${setting.api.url}admin/pincode`,
    viewPincode: `${setting.api.url}admin/pincode`,
    viewPincodebyID: `${setting.api.url}admin/pincode`,
    editPincode: `${setting.api.url}admin/pincode`,
    pincodeStatus: `${setting.api.url}admin/deliveryarea/status`,
    deletePincode: `${setting.api.url}admin/deletepincode`,

    //Products
    createProduct: `${setting.api.url}admin/create-product`,
    uploadProductImage: `${setting.api.url}admin/uploadproduct`,
    viewProduct: `${setting.api.url}admin/getall-products`,
    deleteProduct: `${setting.api.url}admin/delete-product`,
    deleteProductImage: `${setting.api.url}admin/deleteproductimage`,
    viewProductsbyId: `${setting.api.url}admin/create-product`,
    productStatus: `${setting.api.url}admin/product/status`,
    editProduct: `${setting.api.url}admin/create-product`,

    // GST
    editGST: `${setting.api.url}admin/editgst`,
    deleteGST: `${setting.api.url}admin/deletegst`,
    addGST: `${setting.api.url}admin/gst`,
    viewGSTbyId: `${setting.api.url}gst`,
    viewGST: `${setting.api.url}gst`,


    // Orders
    viewOrders: `${setting.api.url}admin/getorders`,
    viewOrdersByID: `${setting.api.url}admin/getorderdetails`,
    setOrderState: `${setting.api.url}admin/orderstate`,
    changeShipAddress: `${setting.api.url}auth/address`,

    // Invoice By ID
    viewInvoicebyId: `${setting.api.url}admin/invoice`,

    // CMS Page
    addAbout: `${setting.api.url}admin/page?type=aboutus`,
    addTandC: `${setting.api.url}admin/page?type=termandcondition`,
    addPandP: `${setting.api.url}admin/page?type=privacypolicy`,
    addSandR: `${setting.api.url}admin/page?type=shippingandreturn`,
    getPost:`${setting.api.url}page`,
    changePost: `${setting.api.url}admin/page`,

    // Review
    viewReview: `${setting.api.url}admin/review`,
    reviewStatus: `${setting.api.url}admin/review/status`,

    // Feedback
    getAllFeedbacks: `${setting.api.url}admin/feedback`,

    // Reason
    getAllReasons:`${setting.api.url}auth/feedback-reason`,
    addReason:`${setting.api.url}admin/feedback-reason`,
    editReason:`${setting.api.url}admin/feedback-reason`,
    getReasonbyId:`${setting.api.url}auth/feedback-reason`,
    reasonStatus:`${setting.api.url}admin/feedbackreason/status`,

    // Tracking Order
    updateTrackingDetails:`${setting.api.url}admin/tracking-details`,

    // Unit
    postUnit: `${setting.api.url}common/unit`,
    allUnit: `${setting.api.url}unit`,
    singleUnit: `${setting.api.url}unit`,
    deleteUnit: `${setting.api.url}admin/deleteunit`,
    putUnit: `${setting.api.url}admin/editunit`,

    //Add Mobile Promotion
    addMobilePromotion: `${setting.api.url}admin/mobilebanner`
  };
})();
