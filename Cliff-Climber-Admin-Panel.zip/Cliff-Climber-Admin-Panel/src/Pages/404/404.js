import React from "react";
import { Link } from "react-router-dom";
import "./404.css";

const NotFound = () => {
  return (
    <div>
      <div id="wrapper" style={{ height: "100vh" }}>
        <div
          className="d-flex justify-content-center align-items-center"
          id="content-wrapper"
          style={{ height: "100vh" }}
        >
          <div id="content">
            <div className="container-fluid">
              <div className="text-center">
                <div className="error404 mx-auto" data-text="404">
                  404
                </div>
                <p className="lead mb-5">Page Not Found</p>
                <h1
                  className="text-gray-500 mb-0"
                  style={{ color: "gray", fontWeight: "bold" }}
                >
                  Oops!
                </h1>
                <p className="mb-0 mt-3">
                Sorry but the page you are looking for does not exist, have been removed, <br/> name changed or is temporarity unavailable
                </p>
              </div>
              <div className="mt-5 text-center">
                <p className="fs-6 lead text-gray-500">
                  Meanwhile why don't try again by going
                </p>
                <Link to="/">
                  <button className="btn btn-full mt-4 text-white">
                    {" "}
                    &#8617; Back Home
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
