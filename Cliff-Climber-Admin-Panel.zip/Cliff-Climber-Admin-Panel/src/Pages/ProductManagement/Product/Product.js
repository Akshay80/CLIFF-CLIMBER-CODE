import React from "react";
import AddProduct from "../../../Components/Common/Table/ProductTable/AllProductsTable";

const Product = () => {
  return (
    <div>
        <AddProduct/>
    </div>
  );
};

export default Product;