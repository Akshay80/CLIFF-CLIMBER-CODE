import React from "react";
import TagsTable from "../../../Components/Common/Table/TagsTable/TagsTable";

const Tags = () => {
  return (
    <div>
      <TagsTable />
    </div>
  );
};

export default Tags;
