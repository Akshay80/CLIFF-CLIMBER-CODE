import React from "react";
import SubCategoriesTable from "../../../Components/Common/Table/SubCategoriesTable/SubCategoriesTable";

const SubCategories = () => {
  return (
    <div>
      <SubCategoriesTable />
    </div>
  );
};

export default SubCategories;