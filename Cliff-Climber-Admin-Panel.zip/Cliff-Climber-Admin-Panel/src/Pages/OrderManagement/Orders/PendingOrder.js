import React from "react";
// import PendingOrdersTable from "../../../Components/Common/Table/PendingOrderTable/PendingOrdersTable";

import OrdersTable from "../../../Components/Common/Table/OrdersTable/OrdersTable";

export default function PendingOrder() {
  return (
    <>
      <div className="card m-3 mt-0">
        <OrdersTable />
      </div>
    </>
  );
}
