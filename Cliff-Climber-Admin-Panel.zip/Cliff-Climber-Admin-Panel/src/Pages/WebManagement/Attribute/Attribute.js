import React from "react";
import AttributeTable from "../../../Components/Common/Table/AttributesTable/AttributeTable";

const Attribute = () => {
  return (
    <div>
        <AttributeTable />
    </div>
  );
};

export default Attribute;