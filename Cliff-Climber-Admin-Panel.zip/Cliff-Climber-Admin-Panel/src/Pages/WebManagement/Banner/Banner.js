import React from "react";
import BannerTable from "../../../Components/Common/Table/BannerTable/BannerTable";

const Banner = () => {
  return (
    <div>
        <BannerTable />
    </div>
  );
};

export default Banner;