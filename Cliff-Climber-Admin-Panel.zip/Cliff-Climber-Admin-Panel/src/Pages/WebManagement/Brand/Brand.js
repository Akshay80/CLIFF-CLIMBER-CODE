import React from "react";
import BrandTable from "../../../Components/Common/Table/BrandTable/BrandTable";

const Brand = () => {
  return (
    <div>
        <BrandTable />
    </div>
  );
};

export default Brand;