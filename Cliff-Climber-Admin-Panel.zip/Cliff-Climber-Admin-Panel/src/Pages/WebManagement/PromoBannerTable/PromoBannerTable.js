
import React from "react";
import PromoBannerTable from "../../../Components/Common/Table/PromoBannerTable/PromoBannerTable";

const PromoBanner = () => {
  return (
    <div>
        <PromoBannerTable />
    </div>
  );
};

export default PromoBanner;