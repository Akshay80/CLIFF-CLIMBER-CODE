import React from "react";
import PartnerTable from "../../../Components/Common/Table/PartnerTable/PartnerTable";

const Partner = () => {
  return (
    <div>
        <PartnerTable />
    </div>
  );
};

export default Partner;