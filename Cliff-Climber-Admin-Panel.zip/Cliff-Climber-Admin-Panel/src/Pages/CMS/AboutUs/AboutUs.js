import React from "react";
import AboutUsCard from "../../../Components/Common/Cards/AboutUsCard/AboutUs";

const AboutUs = () => {
  return (
    <div>
        <AboutUsCard />
    </div>
  );
};

export default AboutUs;