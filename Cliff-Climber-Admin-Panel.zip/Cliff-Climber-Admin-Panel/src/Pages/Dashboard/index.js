import React, { useEffect } from "react";
import { DashboardCard } from "../../Components/Common/Cards/DashboardCard/DashboardCard";
import { ReactComponent as Pie } from "../../Assets/Icon/Pie.svg";
import "./Dashboard.scss";
import "../../Components/Common/DatePicker/Datepickbutton.scss";
import Chartjs from "../../Components/Common/Chart/Chartjs";
import OrderDetailCard from "../../Components/Common/Cards/OrderDetailCard/OrderDetailCard";
import CustomerData from "../../Components/Common/Cards/Customer/CustomerData";

const Dashboard = () => {
  useEffect(() => {
    window.history.pushState(null, document.title, window.location.href);
    window.addEventListener('popstate', function (event){
        window.history.pushState(null, document.title,  window.location.href);
    });
  }, []);
  return (
    <>
      <div className="dashboard-wrapper d-flex justify-content-between align-items-center">
        <div className="page-heading d-flex p-3">
          <div className="page-heading-wapper align-items-center d-flex">
            <Pie className="page-icon m-0" />
            <h3 className="page-sec-heading m-0 mx-2">Dashboard</h3>
          </div>
        </div>
      </div>
      <div className="dashboard-content">
        <DashboardCard />
      </div>
      <div className="container">
        <div className="row">
          <div className="mb-3 col-md-6 col-sm-12 col-xs-12">
            <div className="card p-3">
              <Chartjs />
            </div>
          </div>
          <div className="mb-3 col-md-6 col-sm-12 col-xs-12">
            <div className="card p-3" style={{ height: "100%" }}>
              <OrderDetailCard />
            </div>
          </div>
        </div>
        <div className="row my-3">
          <div className="col-sm-12 col-xs-12">
            <div className="card p-3">
              <h1 className="fs-3 p-3">All Customers</h1>
              <CustomerData />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
