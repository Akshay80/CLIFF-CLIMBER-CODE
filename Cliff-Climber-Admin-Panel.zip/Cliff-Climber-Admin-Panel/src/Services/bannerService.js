import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// ============= category =============

export function viewBannerFun() {
  return ApiInstance.get(`${Api.viewBannerFun}`);
}

export function deleteBanner(payload) {
  return ApiInstance.post(`${Api.deleteBanner}`, payload);
}

export function addBanner(payload) {
  return ApiInstance.post(`${Api.addBanner}`, payload);
}

export function editBannerFun(payload) {
  return ApiInstance.put(`${Api.editBannerFun}`, payload);
}

export function viewBannerbyId(id) {
  return ApiInstance.get(`${Api.viewBannerbyId}/${id}`);
}
// Banner Status
export function bannerStatus(id) {
  return ApiInstance.get(`${Api.bannerStatus}/${id}`);
}
