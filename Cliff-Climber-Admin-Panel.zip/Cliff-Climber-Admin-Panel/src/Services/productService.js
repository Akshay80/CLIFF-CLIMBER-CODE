import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// ============= products =============

export function createProduct(payload) {
    return ApiInstance.post(`${Api.createProduct}`, payload);
}

export function uploadProductImage(payload) {
    return ApiInstance.post(`${Api.uploadProductImage}`, payload);
}
export function uploadProductImageUpdate(payload) {
    return ApiInstance.put(`${Api.uploadProductImage}`, payload);
}
export function viewProduct() {
  return ApiInstance.get(`${Api.viewProduct}`);
}

export function deleteProduct(payload) {
  return ApiInstance.post(`${Api.deleteProduct}`, payload);
}

export function deleteProductImage(payload) {
  return ApiInstance.post(`${Api.deleteProductImage}`, payload);
}

export function viewProductsbyId(id) {
  return ApiInstance.get(`${Api.viewProductsbyId}/${id}`);
}
// // Product Status
export function productStatus(id) {
  return ApiInstance.get(`${Api.productStatus}/${id}`);
}

// Edit Product
export function editProduct(payload) {
  return ApiInstance.put(`${Api.editProduct}`, payload);
}
