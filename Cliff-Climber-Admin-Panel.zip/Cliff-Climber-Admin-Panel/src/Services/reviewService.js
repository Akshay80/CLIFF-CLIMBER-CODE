import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// get GST
export function viewReview() {
  return ApiInstance?.get(`${Api.viewReview}`);
}

// Partner Status
export function reviewStatus(id) {
    return ApiInstance.get(`${Api.reviewStatus}/${id}`);
  }
