import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

export function deletePincode(payload) {
  return ApiInstance.post(`${Api.deletePincode}`, payload);
}

export function viewPincodebyID(id) {
  return ApiInstance.get(`${Api.viewPincodebyID}/${id}`);
}

export function editPincode(payload) {
  return ApiInstance.put(`${Api.editPincode}`, payload);
}

export function addPincode(payload) {
  return ApiInstance.post(`${Api.addPincode}`, payload);
}

export function viewPincode() {
  return ApiInstance.get(`${Api.viewPincode}`);
}

export function pincodeStatus(id) {
  return ApiInstance.get(`${Api.pincodeStatus}/${id}`);
}