
import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

export function updateTrackingDetails(payload) {
    return ApiInstance?.put(`${Api.updateTrackingDetails}`, payload);
  }