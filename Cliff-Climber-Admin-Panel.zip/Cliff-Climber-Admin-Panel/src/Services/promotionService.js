import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";
// import { resHandle } from "../helper";

// get all promotions
export function getAllPromotion() {
  return ApiInstance?.get(`${Api.getAllPromotion}`);
}

//   add promotion
export function addPromotion(payload) {
  return ApiInstance?.post(`${Api.addPromotion}`, payload);
}

// edit promotion
export function editPromotion(payload) {
  return ApiInstance?.put(`${Api.editPromotion}`, payload);
}

// edit promition image
export function editPromotionImage(payload) {
    return ApiInstance?.put(`${Api.editPromotionImage}`, payload);
  }

//   delete promotion
export function deletePromotion(payload) {
  return ApiInstance?.post(`${Api.deletePromotion}`, payload);
}

//   get promotion by ID
export function getPromotionbyId(id) {
  return ApiInstance?.get(`${Api.getPromotionById}/${id}`);
}

// // Partner Status
export function promotionalBannerStatus(id) {
  return ApiInstance.get(`${Api.promotionalBannerStatus}/${id}`);
}

