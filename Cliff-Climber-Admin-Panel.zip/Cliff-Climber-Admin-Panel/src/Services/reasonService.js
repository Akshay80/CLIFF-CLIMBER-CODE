import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";
// import { resHandle } from "../helper";

// Get All Feedbacks
export function getAllReasons() {
  return ApiInstance?.get(`${Api.getAllReasons}`);
}

//   Add Reason
export function addReason(payload) {
  return ApiInstance?.post(`${Api.addReason}`, payload);
}

// Edit Reason
export function editReason(payload) {
  return ApiInstance?.put(`${Api.editReason}`, payload);
}

//   Get Reason by ID
export function getReasonbyId(id) {
  return ApiInstance?.get(`${Api.getReasonbyId}/${id}`);
}

// Reason Status
export function reasonStatus(id) {
  return ApiInstance.get(`${Api.reasonStatus}/${id}`);
}
