import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";
// import { resHandle } from "../helper";

// get all feedbacks
export function getAllFeedbacks() {
  return ApiInstance?.get(`${Api.getAllFeedbacks}`);
}

//   add feedback
export function addBrands(payload) {
  return ApiInstance?.post(`${Api.addBrand}`, payload);
}

// edit feedback
export function editBrandFun(payload) {
  return ApiInstance?.put(`${Api.editBrand}`, payload);
}

//   get feedback by ID
export function getBrandbyId(id) {
  return ApiInstance?.get(`${Api.getBrandbyId}/${id}`);
}

// Feedback Status
export function brandStatus(id) {
  return ApiInstance.get(`${Api.brandStatus}/${id}`);
}