import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// All Orders
export function viewOrders() {
  return ApiInstance?.get(`${Api.viewOrders}`);
}

// Order By ID
export function viewOrdersByID(id) {
    return ApiInstance?.get(`${Api.viewOrdersByID}/${id}`);
  }

  export function setOrderState(payload){
    return ApiInstance?.post(`${Api.setOrderState}`, payload);
  }

// Invoice By ID

export function viewInvoicebyId(id) {
  return ApiInstance?.get(`${Api.viewInvoicebyId}/${id}`);
}

// Update Address
export function changeShipAddress(payload) {
  return ApiInstance?.put(`${Api.changeShipAddress}`, payload);
}


//   // Pending Orders
//   export function getAllPendingOrders()
//   {
//     return ApiInstance?.get(`${Api.getAllPendingOrders}`)
//   }

//   // Rejected Orders
//   export function getAllRejectedOrders()
//   {
//     return ApiInstance?.get(`${Api.getAllRejectedOrders}`)
//   }
// // Completed Orders
// export function getAllCompletedOrders()
// {
//   return ApiInstance?.get(`${Api.getAllCompletedOrders}`)
// }

// // Approved Orders
// export function getAllApprovedOrders()
// {
//   return ApiInstance?.get(`${Api.getAllApprovedOrders}`)
// }

// // Cancelled Orders
// export function getAllCancelledOrders()
// {
//   return ApiInstance?.get(`${Api.getAllCancelledOrders}`)
// }