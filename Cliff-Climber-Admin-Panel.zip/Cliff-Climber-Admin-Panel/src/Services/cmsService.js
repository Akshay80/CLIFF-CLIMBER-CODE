import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// Get CMS Data
export function getPost(payload) {
  return ApiInstance?.post(`${Api.getPost}`, payload);
}


// POSTING CMS DATA - ABOUT
export function addAbout(payload) {
  return ApiInstance?.post(`${Api.addAbout}`, payload);
}

// POSTING CMS DATA - TERMS AND CONDITIONS
export function addTandC(payload) {
  return ApiInstance?.post(`${Api.addTandC}`, payload);
}

// POSTING CMS DATA - PRIVACY POLICY
export function addPandP(payload) {
  return ApiInstance?.post(`${Api.addPandP}`, payload);
}


// CHANGING CMS DATA
export function changePost(payload) {
  return ApiInstance?.put(`${Api.changePost}`, payload);
}