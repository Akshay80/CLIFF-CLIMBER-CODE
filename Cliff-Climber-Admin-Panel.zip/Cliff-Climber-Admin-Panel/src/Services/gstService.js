import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// get GST
export function viewGST() {
  return ApiInstance?.get(`${Api.viewGST}`);
}

//   add GST
export function addGST(payload) {
  return ApiInstance?.post(`${Api.addGST}`, payload);
}

// edit GST
export function editGST(payload) {
  return ApiInstance?.put(`${Api.editGST}`, payload);
}

//   delete GST
export function deleteGST(payload) {
  return ApiInstance?.post(`${Api.deleteGST}`, payload);
}

//   get GST by ID
export function viewGSTbyId(id) {
  return ApiInstance?.get(`${Api.viewGSTbyId}/${id}`);
}
