import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// ============= category =============

export function viewPartner() {
  return ApiInstance.get(`${Api.viewPartner}`);
}

export function deletePartner(payload) {
  return ApiInstance.post(`${Api.deletePartner}`, payload);
}

export function addPartner(payload) {
  return ApiInstance.post(`${Api.addPartner}`, payload);
}

export function editPartner(payload) {
  return ApiInstance.put(`${Api.editPartner}`, payload);
}

export function viewPartnerbyId(id) {
  return ApiInstance.get(`${Api.viewPartnerbyId}/${id}`);
}
// Partner Status
export function partnerStatus(id) {
  return ApiInstance.get(`${Api.partnerStatus}/${id}`);
}