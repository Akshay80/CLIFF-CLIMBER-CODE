import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";
// import { resHandle } from "../helper";

// get all promotions
export function getMobilePromotion() {
  return ApiInstance?.get(`${Api.getMobilePromotion}`);
}

//   add promotion
export function addMobilePromotion(payload) {
  return ApiInstance?.post(`${Api.addMobilePromotion}`, payload);
}

// edit promotion
export function editMobilePromotion(payload) {
  return ApiInstance?.put(`${Api.editMobilePromotion}`, payload);
}

// edit promition image
export function editMobilePromotionImage(payload) {
    return ApiInstance?.put(`${Api.editMobilePromotionImage}`, payload);
  }

//   delete promotion
export function deleteMobilePromotion(payload) {
  return ApiInstance?.post(`${Api.deleteMobilePromotion}`, payload);
}

//   get promotion by ID
export function getMobilePromotionbyId(id) {
  return ApiInstance?.get(`${Api.getMobilePromotionbyId}/${id}`);
}

// // Partner Status
export function promotionalMobileBannerStatus(id) {
  return ApiInstance.get(`${Api.promotionalMobileBannerStatus}/${id}`);
}

