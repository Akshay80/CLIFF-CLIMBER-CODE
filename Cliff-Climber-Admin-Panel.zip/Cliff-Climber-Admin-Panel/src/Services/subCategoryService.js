import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// ============= category =============

export function viewSubCategoryFun() {
  return ApiInstance.get(`${Api.subcategoryFun}`);
}

export function deleteSubCategoryFun(payload) {
  return ApiInstance.post(`${Api.deleteSubcategories}`, payload);
}

export function subCategory(payload) {
  return ApiInstance.post(`${Api.subCategory}`, payload);
}

export function editSubCategoryFun(payload) {
  return ApiInstance.put(`${Api.editSubCategory}`, payload);
}

export function viewSubCategorybyId(id) {
  return ApiInstance.get(`${Api.subcatergoryById}/${id}`);
}

// Sub Category Status
export function subCatStatus(id) {
  return ApiInstance.get(`${Api.subCatStatus}/${id}`);
}