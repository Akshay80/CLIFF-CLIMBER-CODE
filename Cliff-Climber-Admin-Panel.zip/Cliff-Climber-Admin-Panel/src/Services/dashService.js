import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// All Dashboard Data
export function dashboardService() {
  return ApiInstance?.get(`${Api.dashboardService}`);
}

// Get Sales Report by Today
export function getSalesReportByToday() {
  return ApiInstance?.get(`${Api.getSalesReportByToday}`);
}

// Get Sales Report by Week
export function getSalesReportByWeek() {
  return ApiInstance?.get(`${Api.getSalesReportByWeek}`);
}

// Get Sales Report by Month
export function getSalesReportByMonth() {
  return ApiInstance?.get(`${Api.getSalesReportByMonth}`);
}

