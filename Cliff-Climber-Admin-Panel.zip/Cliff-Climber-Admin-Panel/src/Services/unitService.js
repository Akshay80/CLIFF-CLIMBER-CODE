import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

// Adding a Unit
export function postUnit(payload) {
  return ApiInstance?.post(`${Api.postUnit}`, payload);
}

// Editing a Unit
export function putUnit(payload) {
  return ApiInstance?.put(`${Api.putUnit}`, payload);
}

//  Delete a Unit
export function deleteUnit(payload) {
  return ApiInstance?.post(`${Api.deleteUnit}`, payload);
}

// All Units
export function allUnit() {
  return ApiInstance?.get(`${Api.allUnit}`);
}

// Specific Unit
export function singleUnit(id) {
  return ApiInstance?.get(`${Api.singleUnit}/${id}`);
}
