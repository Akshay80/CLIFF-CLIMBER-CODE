import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";
// import { resHandle } from "../helper";

// get brand
export function getAllBrandFun() {
  return ApiInstance?.get(`${Api.getAllBrand}`);
}

//   add brand
export function addBrands(payload) {
  return ApiInstance?.post(`${Api.addBrand}`, payload);
}

// edit Brand
export function editBrandFun(payload) {
  return ApiInstance?.put(`${Api.editBrand}`, payload);
}

//   delete brand
export function deleteBrand(payload) {
  return ApiInstance?.post(`${Api.deleteBrand}`, payload);
}

//   get brands by ID
export function getBrandbyId(id) {
  return ApiInstance?.get(`${Api.getBrandbyId}/${id}`);
}

// Brand Status
export function brandStatus(id) {
  return ApiInstance.get(`${Api.brandStatus}/${id}`);
}