import ApiInstance from "../config/Intercepter";
import Api from "../config/Api";

export function addAttribute(payload) {
  return ApiInstance.post(`${Api.attribute}`, payload);
}
export function viewAttributeFun() {
  return ApiInstance.get(`${Api.getAttribute}`);
}
export function attributeStatus(id) {
  return ApiInstance.get(`${Api.attributeStatus}/${id}`);
}
export function singleAttribute(id) {
  return ApiInstance.get(`${Api.singleAttribute}/${id}`);
}
export function editAttribute(payload) {
  return ApiInstance.put(`${Api.editAttibute}`, payload);
}
export function deleteAttribute(payload) {
  return ApiInstance.post(`${Api.deleteAttribute}`, payload);
}
export function deleteAttributeOption(payload) {
  return ApiInstance.post(`${Api.deleteAttributeOption}`, payload);
}