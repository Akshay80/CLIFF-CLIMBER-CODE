import { Route, Routes } from "react-router-dom";
import Login from "./Components/Auth/Login/Login";
import ForgotPassword from "./Components/Auth/ForgotPassword/ForgotPassword";
import Path from "./Constant/RouterConstant";
import LoginRoute from "./Routes/LoginRoute";
import RestrictedRoute from "./Routes/RestrictedRoute";
import PrivateRoutes from "./Routes/PrivateRoutes";
import NotFound from "./Pages/404/404";

function App() {
  return (
    <>
      <Routes>
        
        <Route exact path={Path.dashboard} element={<LoginRoute />}>
          
        </Route>
        <Route
          exact
          path={Path.dashboard}
          element={<RestrictedRoute />}
        ></Route>
        <Route exact path={Path.login} element={<Login />} />
        <Route exact path={Path.forgotPassword} element={<ForgotPassword />} />
      
      </Routes>

      
      <PrivateRoutes />
    </>
  );
}

export default App;
