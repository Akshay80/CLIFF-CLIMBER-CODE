import React, { useEffect, useState, useRef } from "react";
// import { Bar } from "react-chartjs-2";
// import "chartjs-adapter-date-fns";

import {
  getSalesReportByToday,
  getSalesReportByMonth,
  getSalesReportByWeek,
} from "../../../Services/dashService";
// import { Others } from "@rsuite/icons";
// import moment from "moment";

// OLD PACKAGES

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Chartjs = () => {
  const [today, setToday] = useState([]);
  const [weeks, setWeek] = useState([]);
  const [month, setMonths] = useState([]);
  const [defaultTime, setDefaults] = useState([]);
  const [weekState, setWeekState] = useState(false);
  const [todayState, setTodayState] = useState(false);
  const [monthState, setMonthState] = useState(false);
  const [defaultState, setDefaultState] = useState(false);

  const myToday = () => {
    setTodayState(true);
    setWeekState(false);
    setMonthState(false);
    getSalesReportByToday()
      .then((response) => {
        console.log(response.data.data);
        setToday(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const myWeek = () => {
    setTodayState(false);
    setWeekState(true);
    setMonthState(false);
    getSalesReportByWeek()
      .then((response) => {
        console.log(response.data.data);
        setWeek(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const myMonth = () => {
    setTodayState(false);
    setWeekState(false);
    setMonthState(true);
    getSalesReportByMonth()
      .then((response) => {
        console.log(response.data.data);
        setMonths(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getIntroOfPage = (label) => {
    if (label !== "Page A") {
      return "Order";
    }
    return "";
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip">
          <p className="label2 fw-400">{label}</p>
          <p
            className="label"
            style={{ color: "#0B62A4" }}
          >{`Order : ${payload[0].value}`}</p>

          <p className="intro d-none">{getIntroOfPage(label)}</p>
        </div>
      );
    }

    return "";
  };

  useEffect(() => {
    setTodayState(false);
    setWeekState(false);
    setMonthState(false);
    setDefaultState(true);
    getSalesReportByToday()
      .then((response) => {
        setDefaults(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div className="Chart">
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          paddingBottom: 15,
        }}
      >
        <h5>Sales Report</h5>
        <div>
          <button className="btn btn-danger fw-bold btn-sm" onClick={myToday}>
            Today
          </button>
          <button
            className="btn btn-warning fw-bold btn-sm"
            style={{ margin: "0 10px", color: "white" }}
            onClick={myWeek}
          >
            Last 7 Days
          </button>
          <button className="btn btn-success fw-bold btn-sm" onClick={myMonth}>
            Last 30 Days
          </button>
        </div>
      </div>
      {/* CHART STARTS */}
      <div
        style={{
          width: "100%",
          height: 300,
          textAlign: "center",
          justifyContent: "center",
          alignItems: "center",
          display: "flex",
        }}
      >
        <ResponsiveContainer>
          <BarChart
            data={
              (todayState && today) ||
              (weekState && weeks) ||
              (monthState && month) ||
              (defaultState && defaultTime)
            }
            syncId="noOfOrder"
          >
            <CartesianGrid style={{ fontSize: 12 }} />
            <XAxis dataKey="orderDuration"></XAxis>
            <YAxis dataKey="noOfOrder"></YAxis>
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="noOfOrder" fill="#0B62A4" syncId="anyId" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* CHART ENDS */}
    </div>
  );
};

export default Chartjs;
