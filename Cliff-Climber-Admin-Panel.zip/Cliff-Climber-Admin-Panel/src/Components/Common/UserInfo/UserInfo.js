import Path from "../../../Constant/RouterConstant";

export const UserInfo = [
  {
    name: "Name",
    email: "Email",
    userInfo: "Profile",
    changePasswordText: "Change Password",
    signout: "Logout",
    profile: Path.userProfile,
    logout: Path.logout,
    changePassword: Path.changePassword,
  },
];
