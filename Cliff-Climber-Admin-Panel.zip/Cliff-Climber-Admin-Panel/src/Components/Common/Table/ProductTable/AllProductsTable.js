import React, { useState, useEffect } from "react";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { ReactComponent as EditIcon } from "../../../../Assets/Icon/Edit.svg";
import { ReactComponent as BagIcon } from "../../../../Assets/Icon/Shoppingbasket.svg";
import { ReactComponent as AddIcon } from "../../../../Assets/Icon/Add.svg";
import "react-confirm-alert/src/react-confirm-alert.css";
import ProductIcon from "../../../../Assets/Images/product.png";
import { useForm } from "react-hook-form";
import {
  viewProduct,
  deleteProduct,
  productStatus,
} from "../../../../Services/productService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { Modal, Button, Form } from "react-bootstrap";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import { Input } from "reactstrap";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import $ from "jquery";
import jQuery from "jquery";
import Loader from "../../../../Assets/Icon/loading.gif";
import { imageUrl } from "../../../../config/settings/env";
import paginationFactory, {
  PaginationProvider,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import { confirmAlert } from "react-confirm-alert";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const AllProductsTable = () => {
  const [categoryData, setCategoryData] = useState([]);
  const [isOpen, setOpen] = useState(false);
  const [categImg, setCategImg] = useState();
  const [catId, setCatId] = useState();
  const [imageId, setImageID] = useState();
  const [catFile, setCatFile] = useState();
  const [slug, setSlug] = useState("");
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [show, setShow] = useState(false);
  const [status, setStatus] = useState(false);
  const [cate, setCate] = useState(false);
  const handleShow = () => {
    reset();
    setCate(false);
    setSlug("");
    setShow(true);
  };

  const handleClose = () => {
    setShow(false);
    setSlug("");
    reset();
  };

  const navigate = useNavigate();

  const [show1, setShow1] = useState(false);
  const handleClose1 = () => {
    setShow1(false);
    setCatFile();
    setImage({ preview: "", raw: "" });
  };
  const handleShow1 = () => setShow1(true);
  const [loading, setLoading] = useState(false);
  const [currency, setCurrency] = useState("");

  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  // ====================  get all data =================

  useEffect(() => {
    categories();
  }, []);

  const categories = () => {
    setLoading(true);
    setTimeout(() => {
      viewProduct()
        .then((res) => {
          setLoading(false);
          res.data.data.map((item) => setCurrency(item.currencySymbol));
          console.log(res.data.data);
          setCategoryData(res.data.data);
        })
        .catch(function (error) {});
    }, 1000);
  };

  const { SearchBar } = Search;

  const columns = [
    {
      dataField: "sl no.",
      text: "Serial No",
      // headerAlign: "center",
      // align: "center",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
    {
      dataField: "name",
      text: "Name",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "image",
      text: "Image",
      // sort: true,
      formatter: (row) => {
        return (
          <div>
            {row === null? 
            <input
            type="image"
            className="categoryImages"
            src={ProductIcon}
            alt="product_image"
            onClick={() => openLightbox(ProductIcon)}
          />
            : <input
              type="image"
              className="categoryImages"
              src={imageUrl + row}
              alt="product_image"
              onClick={() => openLightbox(imageUrl + row)}
            />}
          </div>
        );
      },
      // headerAlign: "center",
      align: "center",
    },
    {
      dataField: "productType",
      text: "Type",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "qty",
      text: "Quantity",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "stockAvailability",
      text: "Stock Availablity",
      sort: true,
      formatter: (row, rowContent) => {
        return (
          <div>
            {row === 0 ? (
              <p style={{ color: "red" }}>Out of Stock</p>
            ) : (
              <p style={{ color: "green" }}>Available</p>
            )}
            {/* <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            /> */}
          </div>
        );
      },
    },
    {
      dataField: "sku",
      text: "SKU",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },

    {
      dataField: "price",
      text: "Price",
      sort: true,
      formatter: (row, rowContent) => {
        return <div>{currency + row}</div>;
      },
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "status",
      text: "Status",
      formatter: (row, rowContent) => {
        return (
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            />
          </div>
        );
      },
    },

    {
      dataField: "link",
      text: "Action",
      // headerAlign: "center",
      // align: "center",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            <EditIcon
              className="edit-icon"
              onClick={() => handleEdit(row.id, row.name)}
            />

            <DeleteIcon
              className="iconHover delete-icon"
              onClick={() => handleDelete(row.id, row.name)}
            />
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  async function openLightbox(MyUrl) {
    setOpen(true);
    console.log("callFun");
    await setCategImg(MyUrl);
    // await setCategImg(imageUrl + MyUrl);
  }

  // ===================== get api in modal ================

  const handleEdit = (rowId, rowName) => {
    console.log(rowId);
    navigate(`/product/${rowId}`);
    // viewProductById(rowId).then((response) => {
    //   console.log(response.data.data);
    // })
    // .catch((error) => {
    //   console.log(error);
    // })
    // handleShow1();
    // reset();
    // // Getting Data for Specific category
    // viewCategorybyId(rowId)
    //   .then(function (response) {
    //     setImageID(response.data.data.MediaObjects[0].id);
    //     setCatId(response.data.data.id);
    //     setValue("id", response.data.data.MediaObjects[0].id);
    //     setValue("name", response.data.data.name);
    //     setValue(
    //       "slug",
    //       response.data.data.slug.replaceAll(" ", "-").toLowerCase()
    //     );
    //     setCatFile(`${imageUrl}${response.data.data.MediaObjects[0].imageUrl}`);
    //     setValue(
    //       "category",
    //       `${imageUrl}${response.data.data.MediaObjects[0].imageUrl}`
    //     );
    //   })
    //   .catch(function (error) {});
  };

  // ================== upload category file ========================
  const handleChange = (e) => {
    if (e?.target?.files?.length) {
      setImage({
        preview: URL.createObjectURL(e?.target?.files[0]),
        raw: e?.target?.files[0],
      });
    }
  };

  // ========================= delete api =================
  function confirmDelete(rowId) {
    const deleteById = {
      id: rowId,
    };
    deleteProduct(deleteById)
      .then(function (res) {
        toast.success(res.data.data, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        categories();
      })
      .catch(function (error) {
        toast.error('Unable to delete product as it is used in a order!', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  function handleDelete(rowId, name) {
    confirmAlert({
      title: "Delete",
      message: `Are you sure you want to remove ${name} from the table?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            confirmDelete(rowId);
          },
        },
        {
          label: "No",
          className: "btn btn-success",
        },
      ],
    });
  }

  $(document).ready(function () {
    (function ($) {
      $("#filter").keyup(function () {
        var rex = new RegExp($(this).val(), "i");
        $(".searchable tr").hide();
        $(".searchable tr")
          .filter(function () {
            return rex.test($(this).text());
          })
          .show();
        $(".no-data").hide();
        if ($(".searchable tr:visible").length === 0) {
          $(".no-data").show();
        }
      });
    })(jQuery);
  });

  const apiCheck = (rowId) => {
    productStatus(rowId)
      .then((response) => {
        if (response.data.data.status === true) {
          toast.success(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        } else {
          toast.error(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // generate random number
  const randomNumber = () => {
    console.log(Math.floor(100 + Math.random() * 9000));
    if (JSON.parse(localStorage.getItem("productRadomNum"))) {
      localStorage.removeItem("productRadomNum");
      localStorage.setItem(
        "productRadomNum",
        JSON.stringify(Math.floor(100 + Math.random() * 9000))
      );
    } else {
      localStorage.setItem(
        "productRadomNum",
        JSON.stringify(Math.floor(100 + Math.random() * 9000))
      );
    }
  };

  return (
    <>
      <div className="page-heading d-flex align-items-center justify-content-between">
        <div className="page-heading-wapper d-flex">
          <BagIcon className="page-icon m-0" />
          <h3 className="page-sec-heading m-0 mx-2">Products </h3>
        </div>

        <div className="d-flex align-items-center">
          <Link
            className="btn btn-secondary btn-sm"
            to={"/product"}
            onClick={() => randomNumber()}
          >
            {" "}
            <AddIcon /> Add New Products
          </Link>
        </div>
      </div>

      <div className="card mt-3">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              sizePerPage: 5,
              prePageText: "Previous",
              nextPageText: "Next",
              withFirstAndLast: false,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: categoryData.length,
                },
              ],
              hideSizePerPage: categoryData.length === 0,
            })}
            keyField="serialno"
            columns={columns}
            data={categoryData.map((item) => item)}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="serialno"
                columns={columns}
                data={categoryData.map((item) => item)}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3 me-2">
                      {/* <SizePerPageDropdownStandalone {...paginationProps} /> */}
                      <SearchBar {...toolkitprops.searchProps} srText=" " />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      condensed={false}
                      data={categoryData}
                      bootstrap4
                      noDataIndication={
                        loading ? (
                          <img src={Loader} alt="loader" width={24} />
                        ) : (
                          "No Data Is Available"
                        )
                      }
                    />
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div>

      {isOpen === true ? (
        <Lightbox mainSrc={categImg} onCloseRequest={() => setOpen(false)} />
      ) : null}

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default AllProductsTable;
