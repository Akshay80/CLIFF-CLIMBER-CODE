import React, { useEffect, useState } from "react";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory, {
  PaginationProvider,
} from "react-bootstrap-table2-paginator";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { viewOrders, viewOrdersByID } from "../../../../Services/orderService";
import { ReactComponent as ViewIcon } from "../../../../Assets/Icon/View.svg";
import "./Orders.css";
import { Link, useNavigate } from "react-router-dom";
import moment from "moment";
import Loader from "../../../../Assets/Icon/loading.gif";
import { ReactComponent as OrderIcon } from "../../../../Assets/Icon/order.svg";


const OrdersTable = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  // const products = OrdersData.map((custom) => [
  //   {
  //     id: custom.id,
  //     date: custom.date,
  //     customername: custom.customername,
  //     chefname: custom.chefname,
  //     amount: custom.amount,
  //     status: custom.status,
  //   },
  // ]);

  const { SearchBar } = Search;
  const headerSortingStyle = { backgroundColor: "#e3edf8" };

  useEffect(() => {
    orderData();
  }, []);

  const orderData = async () => {
    setLoading(true);
    setTimeout(() => {
      viewOrders()
      .then((response) => {
        setLoading(false);
        setOrders(response.data.data);
        // console.log(response.data.data);
      })
      .catch(function (error) {});
    }, 1000);
  
  };

  function handleEdit(row)
  {
    navigate(`/edit-orders/${row.id}`);
  }


  const columns = [
    {
      dataField: "sl no.",
      text: "Serial No",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
    {
      dataField: "createdAt",
      text: "Date",
      sort: true,
      headerSortingStyle,
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            {moment(row.createdAt).format("MMMM Do YYYY")}
          </div>
        );
      },
    },
    {
      dataField: "orderNumber",
      text: "Order No",
      sort: true,
      headerSortingStyle,
    },
    {
      dataField: "orderType",
      text: "Order Type",
      sort: true,
    },
    
    {
      dataField: "customerFullName",
      text: "Customer Name",
      headerSortingStyle,
      sort: true,
    },
    {
      dataField: "customerEmail",
      text: "Customer Email",
      headerSortingStyle,
      sort: true,
    },
    {
      dataField: "paymentState",
      text: "Payment Status",
      headerSortingStyle,
      sort: true,
    },
    {
      dataField: "shipmentStatus",
      text: "Shipment Status",
      sort: true,
      headerSortingStyle,
      formatter: (rowContent, row) =>
        {
          return (
            <div>
          {row.shipmentStatus == null && <p style={{color: "red"}}>Not Shipped Yet</p>}
          </div>
          )
        }
    },
   
    // {
    //   dataField: "total",
    //   text: "Total",
    //   sort: true,
    // },

    {
      dataField: "link",
      text: "Action",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            {/* <Link to="/edit-orders" > */}
              <ViewIcon className="view-icon" onClick={() => handleEdit(row)} />
            {/* </Link> */}
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

 
  return (
    
    
      <>
      {/* <div className="page-heading d-flex align-items-center mb-3 justify-content-between">
        <div className="page-heading-wapper d-flex">
          <OrderIcon className="page-icon m-0" />
          <h3 className="page-sec-heading m-0 mx-2">Reviews</h3>
        </div>
      </div> */}
      <div className="page-heading d-flex align-items-center mb-3 justify-content-between">
      <div className="page-heading-wapper d-flex">
        <OrderIcon className="page-icon m-0" />
        <h3 className="page-sec-heading m-0 mx-2"> Orders</h3>
      </div>
    </div>
    <div className="card mt-0">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              totalSize: orders.length,
              prePageText: "Previous",
              nextPageText: "Next",
              withFirstAndLast: false,
              page: 1,
              sizePerPage: 4,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: orders.length,
                },
              ],
              hideSizePerPage: orders.length === 0,
            })}
            keyField="id"
            columns={columns}
            data={orders.map((item) => item)}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="id"
                columns={columns}
                data={orders.map((item) => item)}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3">
                      {/* <SizePerPageDropdownStandalone {...paginationProps} /> */}
                      <SearchBar {...toolkitprops.searchProps} srText=" " />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      condensed={false}
                      bootstrap4={true}
                      noDataIndication={
                        loading ? (
                          <img src={Loader} alt="loader" width={24} />
                        ) : (
                          "No Data Is Available"
                        )
                      }
                       />
                    {/* <div className="d-flex justify-content-end">
                      <PaginationListStandalone {...paginationProps} />
                    </div> */}
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div></>
  );
};

export default OrdersTable;
