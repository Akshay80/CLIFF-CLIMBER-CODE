export const TagsData = [
    {
      serialno: "01",
      date: `26th Jan 2021`,
      tags: "Medium Spicy",
    },
    {
      serialno: "01",
      date: `26th Jan 2021`,
      tags: "Veg"
    },
  ];
  