export const AttributeItemsData = [
  {
    serial_no: "01",
    attr_name: "Brand",
    attr_type: "Select",
    attr_code: "brand",
    attr_options: [],
  },
  {
    serial_no: "02",
    attr_name: "Color",
    attr_type: "Select",
    attr_code: "color",
    attr_options: [],
  },
  {
    serial_no: "03",
    attr_name: "Material",
    attr_type: "Select",
    attr_code: "material",
    attr_options: [],
  },
  {
    serial_no: "04",
    attr_name: "Brand",
    attr_type: "Select",
    attr_code: "Size",
    attr_options: [],
  },
];
