import React, { useState, useEffect } from "react";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { ReactComponent as EditIcon } from "../../../../Assets/Icon/Edit.svg";
// import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import "./AttributeTable.css";
// import { confirmAlert } from "react-confirm-alert";
import { ReactComponent as PaintIcon } from "../../../../Assets/Icon/Paint.svg";
import { ReactComponent as AddIcon } from "../../../../Assets/Icon/Add.svg";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useForm } from "react-hook-form";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { Modal, Button, Form } from "react-bootstrap";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import $ from "jquery";
import jQuery from "jquery";
import Loader from "../../../../Assets/Icon/loading.gif";
import { imageUrl } from "../../../../config/settings/env";
import paginationFactory, {
  PaginationProvider,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import { confirmAlert } from "react-confirm-alert";
import { Link } from "react-router-dom";
import {
  addAttribute,
  viewAttributeFun,
  attributeStatus,
  singleAttribute,
  editAttribute,
  deleteAttribute,
  deleteAttributeOption,
} from "../../../../Services/attributeService";

const AttributeTable = () => {
  const [categoryData, setCategoryData] = useState([]);
  const [isOpen, setOpen] = useState(false);
  const [categImg, setCategImg] = useState();
  const [catId, setCatId] = useState();
  const [imageId, setImageID] = useState();
  const [catFile, setCatFile] = useState();
  const [slug, setSlug] = useState("");
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [show, setShow] = useState(false);
  const [status, setStatus] = useState(false);
  const [addOption, setOption] = useState(false);
  const [newData, setNewData] = useState();
  const [arr, setArr] = useState([]);

  const [editOptionName, setEditOptionName] = useState("");
  const [editOptionCode, setEditOptionCode] = useState("");
  const [editID, setEditID] = useState("");

  const handleClose = () => {
    setShow(false);
    setSlug("");
    reset();
    setNewData();
  };
  const handleShow = () => {
    reset();
    setShow(true);
    setOption(false);
    setOpen(false);
    attributeReset();
  };

  const [show1, setShow1] = useState(false);
  const handleClose1 = () => {
    setShow1(false);
    setCatFile();
    setImage({ preview: "", raw: "" });
  };
  const handleShow1 = () => {
    setShow1(true);
    setNewData();
  }
  const [loading, setLoading] = useState(false);

  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const { SearchBar } = Search;

  const columns = [
    {
      dataField: "myItem.serial_no",
      text: "Serial No",
      // headerAlign: "center",
      // align: "center",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
    {
      dataField: "name",
      text: "Attribute Name",
    },
    {
      dataField: "nameCode",
      text: "Attribute Code",
      sort: true,
    },
    {
      dataField: "status",
      text: "Status",
      formatter: (row, rowContent) => {
        return (
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            />
          </div>
        );
      },
    },

    {
      dataField: "link",
      text: "Action",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            <EditIcon
              className="edit-icon"
              onClick={() => handleEdit(row.id, row.name)}
            />
            {/* <DeleteIcon
              className="iconHover delete-icon"
              onClick={() => handleDelete(row.id, row.name)}
            /> */}
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  async function openLightbox(MyUrl) {
    setOpen(true);
    await setCategImg(imageUrl + MyUrl);
  }

  // ====================  get all data =================
  useEffect(() => {
    viewAttributeData();
  }, []);

  const viewAttributeData = () => {
    setLoading(true);
    setTimeout(() => {
      viewAttributeFun()
        .then((res) => {
          setLoading(false);
          setCategoryData(res.data.data);
        })
        .catch(function (error) {});
    }, 1000);
  };

  //  ================= add categrory =============
  const onSubmit = (data) => {
    var formData = new FormData();
    formData.append("name", data.name);
    formData.append("category", data.category[0]);
    formData.append("slug", slug.replaceAll(" ", "-").toLowerCase());
    addAttribute(formData)
      .then(function (res) {
        setSlug("");
        toast.success("Attribute added successfully", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        viewAttributeData();
        reset();
      })

      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ===================== get attribute api in modal ================

  const handleEdit = (rowId, rowName) => {
    setNewData();
    handleShow1();
    reset();
    setEditID(rowId);
    // Getting Data for Specific category
    singleAttribute(rowId)
      .then(function (response) {
        if (response.data.success === true) {
          setNewData(response.data.data);
          editAttributeSetValue(
            "editAttributeName",
            response?.data?.data?.name
          );
          editAttributeSetValue(
            "editAttributeCode",
            response?.data?.data?.nameCode
          );
        }
      })
      .catch(function (error) {});
  };

  // =================== edit category modal ==================

  const EditSubmit = async (e) => {
    const newArr = [...arr, ...addInputFields];
    console.log(newArr);

    const params = {
      attribute: {
        id: newData.id,
        name: e.editAttributeName,
        nameCode: e.editAttributeCode,
      },
      attributeOption: newArr,
    };

    console.log("params", params);
    await editAttribute(params)
      .then((res) => {
        console.log("res", res);
        if (res.data.success === true) {
          viewAttributeData();
          handleClose1();
          toast.info(res.data.data, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
          // viewAttributeData();
        }
        else
        {
          toast.error(res.data.error, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ========================= delete api =================
  function confirmDelete(rowId) {
    const deleteById = {
      id: rowId,
    };
    deleteAttribute(deleteById)
      .then(function (res) {
        toast.success(res.data.data, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        viewAttributeData();
      })
      .catch(function (error) {
        console.log("error : ", error.error)
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  function handleDelete(rowId, name) {
    console.log(rowId);
    confirmAlert({
      title: "Delete",
      message: `Are you sure you want to remove this item from the table?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            confirmDelete(rowId);
          },
        },
        {
          label: "No",
          className: "btn btn-success",
        },
      ],
    });
  }

  $(document).ready(function () {
    (function ($) {
      $("#filter").keyup(function () {
        var rex = new RegExp($(this).val(), "i");
        $(".searchable tr").hide();
        $(".searchable tr")
          .filter(function () {
            return rex.test($(this).text());
          })
          .show();
        $(".no-data").hide();
        if ($(".searchable tr:visible").length === 0) {
          $(".no-data").show();
        }
      });
    })(jQuery);
  });

  // Status Button Functionality
  const toggleStatus = () => {
    setStatus(!status);
  };

  // add option
  const [inputList, setInputList] = useState([]);

  // handle input change
  const handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = [...inputList];
    list[index][name] = value;
    list[index]["nameCode"] = value.toLowerCase();
    list[index]["order"] = index;
    setInputList(list);
    console.log("inputList", inputList);
  };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
    console.log(list);
  };

  // handle click event of the Add button
  const handleAddClick = () => {
    setInputList([...inputList, { name: "", nameCode: "" }]);
  };

  // ============== add attribute =============
  const {
    register: attributeRegister,
    setValue: attributeSetValue,
    reset: attributeReset,
    handleSubmit: attributeSubmit,
    formState: { errors: attributeErrors },
  } = useForm();

  const attributeHandler = async (attribute) => {
    console.log("attributeHandler", attribute)
    const params = {
      attribute: {
        name: attribute.attributeName,
        nameCode: attribute.attributeName.toLowerCase(),
      },
      attributeOption: inputList,
    };

    await addAttribute(params)
      .then((res) => {
        if (res.data.success) {
          viewAttributeData();
          handleClose();
          toast.info(res.data.data, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
          attributeReset();
        }
        else
        {
          toast.error(res.data.error, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });

    console.log("params", params);
  };

  const apiCheck = (rowId) => {
    attributeStatus(rowId)
      .then((response) => {
        if (response.data.data.status === true) {
          toast.success(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        } else {
          toast.error(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // ================ attribute edit modal =============

  const handleChange = (e, index) => {
    const { name, value } = e.target;
    const orignalPosition = newData.AttributeOptions.findIndex((proStat) => {
      console.log("pro", proStat);
      return proStat.id === e.target.id;
    });

    const newOrder = newData.AttributeOptions.map((ord, index) => {
      if (index === orignalPosition) {
        ord.name = value;
        ord.nameCode = value.toLowerCase();
        return ord;
      }

      return ord;
    });

    const newOrderArr = newOrder.map(({ status, ...rest }) => ({ ...rest }));

    console.log("newOrder", newOrderArr);

    setArr(newOrderArr);
  };

  // ANOTHER LOGIc FOR ADD AttributeOptions

  const [addInputFields, setAddInputFields] = useState([]);
  const addInputField = () => {
    setAddInputFields([...addInputFields, { name: "", nameCode: "" }]);
  };

  const removeInputFields = (index) => {
    const rows = [...addInputFields];
    rows.splice(index, 1);
    setAddInputFields(rows);
  };

  const handleAddChange = (e, index) => {
    const { name, value } = e.target;
    const newList = [...addInputFields];
    newList[index]["id"] = null;
    newList[index]["name"] = value;
    newList[index]["nameCode"] = value.toLowerCase();
    newList[index]["order"] = index;
    setAddInputFields(newList);
    // console.log("newList", newList);
  };

  const {
    register: editAttributeRegister,
    setValue: editAttributeSetValue,
    reset: editAttributeReset,
    handleSubmit: editAttributeSubmit,
    formState: { errors: editAattributeErrors },
  } = useForm();

  // remove attribute option
  const removeAttributeOption = async (id) => {
    const deleteById = {
      id: id,
    };
    await deleteAttributeOption(deleteById)
      .then(function (res) {
        handleEdit(editID);
      })
      .catch(function (error) {
        toast.error('Unable to delete attribute option as it is used in a product', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  return (
    <>
      <div className="page-heading d-flex align-items-center justify-content-between">
        <div className="page-heading-wapper d-flex">
          <PaintIcon className="page-icon m-0" />
          <h3 className="page-sec-heading m-0 mx-2">Attributes </h3>
        </div>

        <div className="d-flex align-items-center">
          <button
            type="submit"
            className="btn btn-secondary btn-sm"
            onClick={handleShow}
          >
            {" "}
            <AddIcon /> Add New Attribute
          </button>
        </div>
      </div>
      {/* Modal for Adding New Category */}
      <Modal
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={attributeSubmit(attributeHandler)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mb-1">
              <Form.Label>Attribute Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="attribute name"
                autoComplete="off"
                {...attributeRegister("attributeName", {
                  required: "Attribute name is required!",
                  pattern: {
                    value: /^[a-zA-Z]*$/,
                    message: "Invalid attribute name!"
                  }
                })}
                // onChange={(e) => setSlug(e.target.value)}
              />
            </Form.Group>
            {attributeErrors.attributeName && (
              <p className="errors">{attributeErrors.attributeName.message}</p>
            )}
            <Form.Group className="mt-3">
              <Form.Label>Attribute Code</Form.Label>
              <Form.Control
                type="text"
                placeholder="attribute code"
                style={{ textTransform: "lowercase" }}
                autoComplete="off"
                // defaultValue={slug.replaceAll(" ", "-").toLowerCase()}
                // required
                {...attributeRegister("attributeCode", {
                  required: "Attribute Code is required!",
                  pattern: {
                    value: /^[a-zA-Z]*$/,
                    message: "Invalid attribute code!"
                  }
                })}
              />
            </Form.Group>
            {attributeErrors.attributeCode && (
              <p className="errors">{attributeErrors.attributeCode.message}</p>
            )}
            <Form.Group className="mt-3">
              <Form.Label>Attribute Options</Form.Label>
              <br />
              {inputList.map((singleService, index) => (
                <Form.Group
                  className="mb-3 d-flex align-items-center justify-content-between"
                  controlId="formBasicOption"
                  key={index}
                >
                  <Form.Control
                    type="text"
                    name="name"
                    id="form-attribute"
                    defaultValue={singleService.service}
                    onChange={(e) => {
                      handleInputChange(e, index);
                    }}
                  />
                  {inputList.length > 0 && (
                    <Link
                      to="#"
                      onClick={() => handleRemoveClick(index)}
                      className="text-danger text-decoration-none"
                    >
                      Remove
                    </Link>
                  )}
                </Form.Group>
              ))}
              {errors.attributeOption && (
                <p className="errors">{errors.attributeOption.message}</p>
              )}

              <Link
                to="#"
                className="text-decoration-none fw-medium"
                onClick={() => handleAddClick()}
              >
                Add Option
              </Link>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="primary" type="submit">
              Add Attribute
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {isOpen === true ? (
        <Lightbox mainSrc={categImg} onCloseRequest={() => setOpen(false)} />
      ) : null}

      {/* Modal for Edit */}

      <Modal
        aria-labelledby="contained-modal-title-2-vcenter"
        centered
        show={show1}
        onHide={handleClose1}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={editAttributeSubmit(EditSubmit)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mb-1">
              <Form.Label>Attribute Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Name"
                autoComplete="off"
                {...editAttributeRegister("editAttributeName")}
              />
            </Form.Group>
            <Form.Group className="mt-3">
              <Form.Label>Attribute Name Code</Form.Label>
              <Form.Control
                type="text"
                placeholder="Name Code"
                autoComplete="off"
                {...editAttributeRegister("editAttributeCode")}
              />
            </Form.Group>
            <Form.Group className="mt-3">
              <Form.Label>Attribute Options</Form.Label>
              <br />
              {newData?.AttributeOptions?.map((option, index) => (
                <Form.Group
                  className="mb-3 d-flex align-items-center justify-content-between"
                  controlId="formBasicOption"
                  key={index}
                >
                  <input
                    type="text"
                    defaultValue={option?.name}
                    className="form-control attribute"
                    name="name"
                    onChange={(e) => {
                      handleChange(e, index);
                    }}
                    id={option?.id}
                  />
                  <Link
                    to="#"
                    onClick={() => removeAttributeOption(option?.id)}
                    className="text-danger text-decoration-none"
                  >
                    Remove
                  </Link>
                </Form.Group>
              ))}
              {addInputFields.map((e, index) => (
                <Form.Group
                  className="mb-3 d-flex align-items-center justify-content-between"
                  controlId="formBasicOption"
                  key={index}
                >
                  {console.log(addInputFields.length)}
                  <Form.Control
                    type="text"
                    // defaultValue={option?.name}
                    name="optionEditName"
                    onChange={(e) => {
                      handleAddChange(e, index);
                    }}
                  />
                  <Link
                    to="#"
                    onClick={() => removeInputFields(index)}
                    className="text-danger text-decoration-none"
                  >
                    Remove
                  </Link>
                </Form.Group>
              ))}
              <Link
                to="#"
                className="text-decoration-none fw-medium"
                onClick={() => addInputField()}
              >
                Add Option
              </Link>
            </Form.Group>
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="success" type="submit">
              Update
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      <div className="card mt-3">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              totalSize: categoryData.length,
              prePageText: "Previous",
              nextPageText: "Next",
              withFirstAndLast: false,
              page: 1,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: categoryData.length,
                },
              ],
              hideSizePerPage: categoryData.length === 0,
            })}
            keyField="id"
            columns={columns}
            // data={categoryData.map((item) => item)}
            data={categoryData.map((item) => item)}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="id"
                columns={columns}
                // data={categoryData.map((item) => item)}
                data={categoryData.map((item) => item)}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3">
                      <SizePerPageDropdownStandalone {...paginationProps} />
                      <SearchBar
                        className="ms-2"
                        {...toolkitprops.searchProps}
                        srText=" "
                      />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      condensed={false}
                      data={categoryData.map((item) => item)}
                      bootstrap4
                      noDataIndication={
                        loading ? (
                          <img src={Loader} alt="loader" width={24} />
                        ) : (
                          "No Data Is Available"
                        )
                      }
                    />
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default AttributeTable;
