export const CategoriesItemsData = [
    {
      serialno: "01",
      date: `26th Jan 2021`,
      cat: "Indian",

    },
    {
      serialno: "02",
      date: `26th Jan 2021`,
      cat: "Chinese",
    },
  ];
  