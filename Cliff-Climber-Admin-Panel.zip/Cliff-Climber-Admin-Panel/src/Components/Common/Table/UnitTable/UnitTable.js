import React, { useState, useEffect } from "react";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory, {
  PaginationProvider,
  SizePerPageDropdownStandalone,
  PaginationListStandalone,
} from "react-bootstrap-table2-paginator";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { ReactComponent as EditIcon } from "../../../../Assets/Icon/Edit.svg";
import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import "./UnitTable.css";
import { confirmAlert } from "react-confirm-alert";
import { ReactComponent as HelmetIcon } from "../../../../Assets/Icon/Helmet.svg";
import { ReactComponent as AddIcon } from "../../../../Assets/Icon/Add.svg";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useForm } from "react-hook-form";
import {
  postUnit,
  putUnit,
  deleteUnit,
  allUnit,
  singleUnit,
} from "../../../../Services/unitService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { Modal, Button, Form } from "react-bootstrap";

const UnitTable = () => {
  const [unitId, setUnitId] = useState();
  const [unitData, setUnitData] = useState([]);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    reset();
    setShow(true);
  };

  const [show1, setShow1] = useState(false);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);

  const { SearchBar } = Search;
  const headerSortingStyle = { backgroundColor: "#e3edf8" };
  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const columns = [
    {
      dataField: "sl no.",
      text: "Serial No",
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
    {
      dataField: "unitName",
      text: "Name",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },

    {
      dataField: "unitAddress",
      text: "Address",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },

    {
      dataField: "careOf",
      text: "Care-Of",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },

    

    {
      dataField: "unitPincode",
      text: "Pincode",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },

    
    // {
    //   dataField: "sortName",
    //   text: "Quantity",
    //   headerSortingStyle,
    //   sort: true,
    //   headerAlign: "center",
    //   align: "center",
    // },

    {
      dataField: "link",
      text: "Action",
      // headerAlign: "center",
      // align: "center",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            <EditIcon
              className="edit-icon"
              onClick={() => handleEdit(row.id, row.name)}
            />
            <DeleteIcon
              className="iconHover delete-icon"
              onClick={() => handleDelete(row.id, row.name)}
            />
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  // ================= get all units ==============
  useEffect(() => {
    units();
  }, []);

  async function units() {
    await allUnit()
      .then(function (res) {
        setUnitData(res.data.data);
      })
      .catch(function (error) {});
  }

  // ==================== add unit ============

  const onSubmit = (data) => {
    const unitData = {
      unitName: data.unitName,
      unitPincode: data.unitPincode,
      UnitCreatedBy: "ADMIN",
      unitAddress: data.unitAddress,
      careOf: data.careOf
      // sortName: data.sortname,
    };
    postUnit(unitData)
      .then(function (res) {
        handleClose();
        toast.success("Unit Added Successfully", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        units();
        reset();
      })

      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ================ put unit in modal ===============

  async function handleEdit(rowId) {
    handleShow1();
    reset();
    // Getting Data for Specific category
    await singleUnit(rowId)
      .then(function (response) {
        setUnitId(response.data.data.id);
        setValue("unitName", response.data.data.unitName);
        setValue("unitPincode", response.data.data.unitPincode)
        setValue("unitAddress", response.data.data.unitAddress)
        setValue("careOf", response.data.data.careOf)      
        // setValue("sortname", response.data.data.sortName);
      })
      .catch(function (error) {});
  }

  const EditSubmit = (data) => {
    const editData = {
      id: unitId,
      unitName: data.unitName,
      unitPincode: data.unitPincode,
      unitAddress: data.unitAddress,
      careOf: data.careOf,
      UnitCreatedBy: "ADMIN"
    };
    putUnit(editData)
      .then(function (res) {
        handleClose1();
        toast.info("Units Edited Successfully", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        units();
      })

      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ===================== confirm delete unit =============

  function confirmDelete(rowId) {
    const deleteById = {
      id: rowId,
    };
    deleteUnit(deleteById)
      .then(function (res) {
        toast.success("Unit Deleted Successfully", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        units();
      })
      .catch((error) => {
        toast.error('Unable to delete unit as it is used in a order', {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  function handleDelete(rowId, name) {
    confirmAlert({
      title: "Delete",
      message: `Are you sure you want to remove this item from the table?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            confirmDelete(rowId);
          },
        },
        {
          label: "No",
        },
      ],
    });
  }

  return (
    <>
      <div className="page-heading d-flex align-items-center mb-3 justify-content-between">
      <div className="page-heading-wapper d-flex">
          <HelmetIcon className="page-icon m-0" />
          <h3 className="page-sec-heading m-0 mx-2">Unit</h3>
        </div>

        <div className="add-btn d-flex align-items-center">
          <button
            type="submit"
            className="btn btn-secondary btn-sm"
            onClick={handleShow}
          >
            {" "}
            <AddIcon /> Add New Unit
          </button>
        </div>
      </div>
      {/* Modal for Adding New Unit */}
      <Modal
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mb-1">
              <Form.Label>Unit Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="name"
                autoComplete="off"
                {...register("unitName", {
                  required: "Unit Name is required!",
                })}
              />
            </Form.Group>
            {errors.unitName && (
              <p className="errors">{errors.unitName.message}</p>
            )}

<Form.Group className="mt-3">
              <Form.Label>Unit Pincode</Form.Label>
              <Form.Control
                type="text"
                placeholder="pincode (in Numbers)"
                autoComplete="off"
                {...register("unitPincode", {
                  required: "Unit Pincode is required!",
                })}
              />
            </Form.Group>
            {errors.unitPincode && (
              <p className="errors">{errors.unitPincode.message}</p>
            )}


<Form.Group className="mt-3">
              <Form.Label>Unit Address</Form.Label>
              <Form.Control
               as="textarea" 
                placeholder="unit name"
                autoComplete="off"
                {...register("unitAddress", {
                  required: "Unit Address is required!",
                })}
              />
            </Form.Group>
            {errors.unitAddress && (
              <p className="errors">{errors.unitAddress.message}</p>
            )}



<Form.Group className="mt-3">
              <Form.Label>CareOf</Form.Label>
              <Form.Control
                type="text"
                placeholder="CareOf (in Numbers)"
                autoComplete="off"
                {...register("careOf", {
                  required: "CareOf is required!",
                })}
              />
            </Form.Group>
            {errors.careOf && (
              <p className="errors">{errors.careOf.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="primary" type="submit">
              Add Units
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {/* Modal for Edit */}

      <Modal
        aria-labelledby="contained-modal-title-2-vcenter"
        centered
        show={show1}
        onHide={handleClose1}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(EditSubmit)}>
          <Modal.Body className="p-4 pt-0">
          <Form.Group className="mb-1">
              <Form.Label>Unit Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="name"
                autoComplete="off"
                {...register("unitName", {
                  required: "Unit Name is required!",
                })}
              />
            </Form.Group>
            {errors.unitName && (
              <p className="errors">{errors.unitName.message}</p>
            )}

<Form.Group className="mt-3">
              <Form.Label>Unit Pincode</Form.Label>
              <Form.Control
                type="text"
                placeholder="pincode (in Numbers)"
                autoComplete="off"
                {...register("unitPincode", {
                  required: "Unit Pincode is required!",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Invalid Pincode!"
                  }
                })}
              />
            </Form.Group>
            {errors.unitPincode && (
              <p className="errors">{errors.unitPincode.message}</p>
            )}


<Form.Group className="mt-3">
              <Form.Label>Unit Address</Form.Label>
              <Form.Control
                as="textarea" 
                placeholder="unit name"
                autoComplete="off"
                {...register("unitAddress", {
                  required: "Unit Address is required!",
                })}
              />
            </Form.Group>
            {errors.unitAddress && (
              <p className="errors">{errors.unitAddress.message}</p>
            )}



<Form.Group className="mt-3">
              <Form.Label>CareOf</Form.Label>
              <Form.Control
                type="text"
                placeholder="careOf (in Numbers)"
                autoComplete="off"
                {...register("careOf", {
                  required: "CareOf is required!",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Invalid CareOf!"
                  }
                })}
              />
            </Form.Group>
            {errors.careOf && (
              <p className="errors">{errors.careOf.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="success" type="submit">
              Update
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      <div className="card">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              totalSize: unitData.length,
              prePageText: "Previous",
              nextPageText: "Next",
              page: 1,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: unitData.length,
                },
              ],
              hideSizePerPage: unitData.length === 0,
            })}
            keyField="id"
            columns={columns}
            data={unitData}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="id"
                columns={columns}
                data={unitData}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3 me-2">
                      {/* <SizePerPageDropdownStandalone {...paginationProps} /> */}
                      <SearchBar {...toolkitprops.searchProps} srText=" " />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      bootstrap4
                      data={unitData}
                      condensed={false}
                      noDataIndication="No Data Is Available"
                    />
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default UnitTable;
