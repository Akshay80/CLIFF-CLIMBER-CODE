import React, { useState, useEffect } from "react";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory, {
  PaginationProvider,
} from "react-bootstrap-table2-paginator";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "./ReviewTable.css";
import { confirmAlert } from "react-confirm-alert";
import { ToastContainer, toast, Flip } from "react-toastify";
import { ReactComponent as ReviewIcon } from "../../../../Assets/Icon/ReviewIcon.svg";
import Loader from "../../../../Assets/Icon/loading.gif";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useForm } from "react-hook-form";
import { viewReview, reviewStatus } from "../../../../Services/reviewService";
import { Rating } from "@mui/material";
// import ReactStars from "react-stars-new";

const ReviewTable = () => {
  const [editId, setEditId] = useState();
  const [tag, setTag] = useState([]);
  const [cate, setCate] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm();

  const [show, setShow] = useState(false);
  const handleClose = () => {
    setShow(false);
  };
  const handleShow = () => {
    reset();
    setShow(true);
    setCate(false);
  };

  const [show2, setShow2] = useState(false);
  const handleClose2 = () => setShow2(false);
  const handleShow2 = () => setShow2(true);
  const [loading, setLoading] = useState(false);

  const { SearchBar } = Search;
  const headerSortingStyle = { backgroundColor: "#e3edf8" };

  useEffect(() => {
    tagdata();
  }, []);

  const tagdata = () => {
    setLoading(true);
    setTimeout(() => {
      viewReview()
        .then((res) => {
          setLoading(false);
          setTag(res?.data?.data);
        })
        .catch(function (error) {});
    }, 1000);
  };

  const columns = [
    {
      dataField: "serialno",
      text: "Serial No",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "createdBy",
      text: "Customer ID",
      headerSortingStyle,
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "fullname",
      text: "Commented By",
      headerSortingStyle,
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "comments",
      text: "Comments",
      headerSortingStyle,
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "rating",
      text: "Ratings",
      headerSortingStyle,
      sort: true,
      formatter: (row) => {
        console.log(row);
        return (
          <Rating name="half-rating-read" defaultValue={row} precision={0.5} readOnly />
          // <ReactStars
          //   count={row}
          //   decimal={true}
          //   edit={false}
          //   half={true}
          //   size={24}
          //   color1={"#ffd700"}
          // />
        );
      },
    },

    {
      dataField: "status",
      text: "Status",
      formatter: (row, rowContent) => {
        return (
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            />
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "serialno",
      order: "asc",
    },
  ];

  const apiCheck = (rowId) => {
    reviewStatus(rowId)
      .then((response) => {
        if (response.data.data.status === true) {
          toast.success(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        } else {
          toast.error(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="page-heading d-flex align-items-center mb-3 justify-content-between">
        <div className="page-heading-wapper d-flex">
          <ReviewIcon className="page-icon m-0" />
          <h3 className="page-sec-heading m-0 mx-2">Reviews</h3>
        </div>
      </div>

      <div className="card">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              prePageText: "Previous",
              nextPageText: "Next",
              withFirstAndLast: false,
              sizePerPage: 5,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: tag.length,
                },
              ],
              hideSizePerPage: tag.length === 0,
            })}
            keyField="serialno"
            columns={columns}
            data={tag}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="serialno"
                columns={columns}
                data={tag}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3 me-2">
                      {/* <SizePerPageDropdownStandalone {...paginationProps} /> */}
                      <SearchBar {...toolkitprops.searchProps} srText=" " />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      bootstrap4
                      data={tag}
                      condensed={false}
                      noDataIndication={
                        loading ? (
                          <img src={Loader} alt="loader" width={24} />
                        ) : (
                          "No Data Is Available"
                        )
                      }
                    />
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default ReviewTable;
