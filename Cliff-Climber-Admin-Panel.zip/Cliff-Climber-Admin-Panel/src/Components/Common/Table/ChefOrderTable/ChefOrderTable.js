import React, { useEffect , useState} from "react";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory, {
  PaginationProvider,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "./ChefOrderTable.css";
import { useParams } from "react-router-dom";
import { getchefDetail, getchefDetails } from "../../../../Services/chefServices";
import moment from "moment";

const ChefOrderTable = () => {
  const {chefId} = useParams();
  const [orderData, setorderData] = useState([]);

  const { SearchBar } = Search;
  const headerSortingStyle = { backgroundColor: "#e3edf8" };

  const columns = [
    {
      dataField: "sl.no",
      text: "Serial no.",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
      headerSortingStyle,
    },
    {
      dataField: "createdAt",
      text: "Date",
      sort: true,
      headerSortingStyle,
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            {moment(row.createdAtn).format("MMMM Do YYYY")}
          </div>
        );
      },
    },
    {
      dataField: "customerName",
      text: "Customer Name",
      headerSortingStyle,
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "deliveryAddress.street",
      text: "Delivery Address ",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "totalAmount",
      text: "Amount",
      sort: true,
      headerSortingStyle,
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            {`$`+ row.totalAmount}
          </div>
        );
      },
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "orderState",
      text: "Status",
      sort: true,
      headerSortingStyle,
      // headerAlign: "center",
      // align: "center",
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  useEffect(() => {
    fetchchefID();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchchefID = () => {
    getchefDetail(chefId).then((response) => {
      fetchChefDetail(response.data.data.chefProfile.createdBy);
    })
    .catch(function (error) {
      console.log(error)
    })
  }
  const fetchChefDetail = async(CID) => {
    await getchefDetails(CID)
      .then((response) => {
        console.log(response.data.data.convertedOrderDetailsJSON)
        setorderData(response.data.data.convertedOrderDetailsJSON);
      })
      .catch(function (error) {});
  };

  return (
    <div className="table-responsive" style={{ padding: "20px" }}>
      <PaginationProvider
        pagination={paginationFactory({
          custom: false,
          totalSize: orderData.length,
          prePageText: "Previous",
          nextPageText: "Next",
          withFirstAndLast: false,
          page: 1,
          sizePerPageList: [
            {
              text: "5",
              value: 5,
            },

            {
              text: "10",
              value: 10,
            },
            {
              text: "30",
              value: 30,
            },
            {
              text: "50",
              value: 50,
            },
            {
              text: "All",
              value: orderData.length,
            },
          ],
          hideSizePerPage: orderData.length === 0,
        })}
        keyField="id"
        columns={columns}
        data={orderData.map((item) => item)}
      >
        {({ paginationProps, paginationTableProps }) => (
          <ToolkitProvider
            keyField="id"
            columns={columns}
            data={orderData.map((item) => item)}
            search
          >
            {(toolkitprops) => (
              <>
                <div className="d-flex justify-content-end mb-3">
                  <SizePerPageDropdownStandalone {...paginationProps} />
                  <SearchBar
                    className="ms-2"
                    {...toolkitprops.searchProps}
                    srText=" "
                  />
                </div>
                <BootstrapTable
                  {...toolkitprops.baseProps}
                  {...paginationTableProps}
                  defaultSorted={defaultSorted}
                  defaultSortDirection="asc"
                  wrapperClasses="table-responsive"
                  hover
                  striped
                  condensed={false}
                  noDataIndication="No Data Is Available"
                />
                {/* <div className="d-flex justify-content-end">
                  <PaginationListStandalone {...paginationProps} />
                </div> */}
              </>
            )}
          </ToolkitProvider>
        )}
      </PaginationProvider>
    </div>
  );
};

export default ChefOrderTable;