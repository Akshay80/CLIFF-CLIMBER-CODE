export const chefOrderData = [
    // {
    //   id: "#5552311",
    //   date: `18 Oct 2021 12:26 PM`,
    //   name: "Airi Satou",
    //   address: "35 Station Road singapore",
    //   amount: "S$ 82.46",
    //   status: "Pending"
    // },
    // {
    //   id: "#5552322",
    //   date: "18 Oct 2021 10:35 AM",
    //   name: "Angelica Ramos",
    //   address: "79 The Drive singapore",
    //   amount: "S$ 11.22",
    //   status: "Delievered"
    // },
    // {
    //   id: "#5552323",
    //   date: "18 Oct 2021 10:20 AM",
    //   name: "Ashton Cox",
    //   address: "544 Manor Road singapore",
    //   amount: "S$ 22.18",
    //   status: "Cancelled"
    // },
    // {
    //   id: "#5552349",
    //   date: "18 Oct 2021 09:10 AM",
    //   name: "Bradley Greer",
    //   address: "Corner Street 5th singapore",
    //   amount: "S$ 34.41",
    //   status: "Delievered"
    // },
    // {
    //   id: "#5563424",
    //   date: "1 Oct 1995 1:00 PM",
    //   name: "Brad White",
    //   address: "79 Mussorie Road Dehradun",
    //   amount: "S$ 62.01",
    //   status: "Cancelled"
    // },
  ];
  