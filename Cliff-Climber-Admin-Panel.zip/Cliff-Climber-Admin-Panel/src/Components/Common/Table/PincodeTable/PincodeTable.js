import React, { useState, useEffect } from "react";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { ReactComponent as EditIcon } from "../../../../Assets/Icon/Edit.svg";
// import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import "./PincodeTable.css";
// import { confirmAlert } from "react-confirm-alert";
import { ReactComponent as AddIcon } from "../../../../Assets/Icon/Add.svg";
import { ReactComponent as PinLocation } from "../../../../Assets/Icon/Location.svg";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useForm } from "react-hook-form";
import {
  viewPincode,
  addPincode,
  deletePincode,
  viewPincodebyID,
  editPincode,
  pincodeStatus
} from "../../../../Services/pincodeService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { Modal, Button, Form, InputGroup } from "react-bootstrap";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import $ from "jquery";
import jQuery from "jquery";
import Loader from "../../../../Assets/Icon/loading.gif";
import { imageUrl } from "../../../../config/settings/env";
import paginationFactory, {
  PaginationProvider,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import { confirmAlert } from "react-confirm-alert";

const PincodeTable = () => {
  const [categoryData, setCategoryData] = useState([]);
  const [isOpen, setOpen] = useState(false);
  const [categImg, setCategImg] = useState();
  const [catId, setCatId] = useState();
  const [catFile, setCatFile] = useState();
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    reset();
    setShow(true);
  };

  const [show1, setShow1] = useState(false);
  const handleClose1 = () => {
    setShow1(false);
    setCatFile();
    setImage({ preview: "", raw: "" });
  };
  const handleShow1 = () => setShow1(true);
  const [loading, setLoading] = useState(false);

  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const { SearchBar } = Search;

  const columns = [
    {
      dataField: "sl no.",
      text: "Serial No",
      // headerAlign: "center",
      // align: "center",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
    {
      dataField: "pincode",
      text: "Pincode",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "city",
      text: "City",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "deliveryDays",
      text: "Delivery Days",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },
    {
      dataField: "deliveryCharges",
      text: "Delivery Charges (in Rupees)",
      sort: true,
      // headerAlign: "center",
      // align: "center",
    },

    {
      dataField: "status",
      text: "Status",
      formatter: (row, rowContent) => {
        return (
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            />
          </div>
        );
      },
    },
    {
      dataField: "link",
      text: "Action",
      // headerAlign: "center",
      // align: "center",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            <EditIcon
              className="edit-icon"
              onClick={() => handleEdit(row.id, row.name)}
            />
            <DeleteIcon
              className="iconHover delete-icon"
              onClick={() => handleDelete(row.id, row.name)}
            />
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  async function openLightbox(MyUrl) {
    setOpen(true);
    await setCategImg(imageUrl + MyUrl);
  }

  // ====================  get all data =================

  useEffect(() => {
    categories();
  }, []);

  const categories = () => {
    setLoading(true);
    setTimeout(() => {
      viewPincode()
        .then((res) => {
          console.log("data", res);
          setLoading(false);
          setCategoryData(res.data.data);
        })
        .catch(function (error) {});
    }, 1000);
  };

  //  ================= add categrory =============
  const onSubmit = (data) => {
    const params = {
      pincode: data.pincode,
      city: data.city,
      state: data.state,
      deliveryDays: data.deliveryDays,
      deliveryCharges: data.deliveryCharges,
    };
    addPincode(params)
      .then(function (res) {
        handleClose();
        toast.success("Pincode Added Successfully", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        categories();
        reset();
      })

      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ===================== get api in modal ================

  const handleEdit = (rowId, rowName) => {
    handleShow1();
    reset();
    // Getting Data for Specific category
    viewPincodebyID(rowId)
      .then(function (response) {
        setCatId(response.data.data[0].id);
        setValue("pincode", response.data.data[0].pincode);
        setValue("city", response.data.data[0].city);
        setValue("state", response.data.data[0].state);
        setValue("deliveryDays", response.data.data[0].deliveryDays);
        setValue("deliveryCharges", response.data.data[0].deliveryCharges);
      })
      .catch(function (error) {});
  };

  // =================== edit category modal ==================

  const EditSubmit = async (e) => {
    // var formData2 = new FormData();
    // formData2.append("name", e.name);
    // formData2.append("partnerlogo", image.raw);
    const params = {
      id: catId,
      pincode: e.pincode,
      city: e.city,
      state: e.state,
      delieveryDays: e.deliveryDays,
      deliveryCharges: e.deliveryCharges

    }
    editPincode(params)
      .then((res) => {
        if (res.statusText === "OK") {
          categories();
          handleClose1();
          toast.info(res.data.data, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ========================= delete api =================
  function confirmDelete(rowId) {
    const deleteById = {
      id: rowId,
    };
    deletePincode(deleteById)
      .then(function (res) {
        toast.success(res.data.data, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        categories();
      })
      .catch(function (error) {
        toast.error("Error while deleting Banner!", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  function handleDelete(rowId, name) {
    confirmAlert({
      title: "Delete",
      message: `Are you sure you want to remove this item from the table?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            confirmDelete(rowId);
          },
        },
        {
          label: "No",
          className: "btn btn-success",
        },
      ],
    });
  }

  $(document).ready(function () {
    (function ($) {
      $("#filter").keyup(function () {
        var rex = new RegExp($(this).val(), "i");
        $(".searchable tr").hide();
        $(".searchable tr")
          .filter(function () {
            return rex.test($(this).text());
          })
          .show();
        $(".no-data").hide();
        if ($(".searchable tr:visible").length === 0) {
          $(".no-data").show();
        }
      });
    })(jQuery);
  });

  const apiCheck = (rowId) => {
    pincodeStatus(rowId)
      .then((response) => {
        if (response.data.data.status === true) {
          toast.success(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        } else {
          toast.error(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="page-heading d-flex align-items-center justify-content-between">
        <div className="page-heading-wapper d-flex">
          <PinLocation
            className="page-icon m-0"
            style={{ paddingTop: 13, paddingLeft: 13 }}
          />
          <h3 className="page-sec-heading m-0 mx-2">Pincodes </h3>
        </div>

        <div className="d-flex align-items-center">
          <button
            type="submit"
            className="btn btn-secondary btn-sm"
            onClick={handleShow}
          >
            {" "}
            <AddIcon /> Add New Pincode
          </button>
        </div>
      </div>
      {/* Modal for Adding New Category */}
      <Modal
        aria-labelledby="contained-modal-title-vonSubmitbanncenter"
        centered
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mt-2">
              <Form.Label>Pincode</Form.Label>
              <Form.Control
                type="text"
                placeholder="pincode"
                autoComplete="off"
                {...register("pincode", {
                  required: "Pincode is required!",
                })}
              />
            </Form.Group>
            {errors.pincode && <p className="errors">{errors.pincode.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>City</Form.Label>
              <Form.Control
                type="text"
                placeholder="city"
                autoComplete="off"
                {...register("city", {
                  required: "City is required!",
                })}
              />
            </Form.Group>
            {errors.city && <p className="errors">{errors.city.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>State</Form.Label>
              <Form.Control
                type="text"
                placeholder="state"
                autoComplete="off"
                {...register("state", {
                  required: "State is required!",
                })}
              />
            </Form.Group>
            {errors.state && <p className="errors">{errors.state.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>Delivery Days</Form.Label>
              <Form.Control
                placeholder="delivery days"
                autoComplete="off"
                {...register("deliveryDays", {
                  required: "Delivery day is required!",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Invalid day!",
                  },
                })}
              />
            </Form.Group>
            {errors.deliveryDays && (
              <p className="errors">{errors.deliveryDays.message}</p>
            )}

            <Form.Label className="mt-3">Delivery Charges</Form.Label>
            <InputGroup>
              <InputGroup.Text id="basic-addon1">₹</InputGroup.Text>
              <Form.Control
                placeholder="delivery charges"
                autoComplete="off"
                {...register("deliveryCharges", {
                  required: "Delivery charges is required!",
                  pattern: {
                    value: /^[1-9]\d*(\.\d+)?$/,
                    message: "Invalid charges!",
                  },
                })}
              />
            </InputGroup>
            {errors.deliveryCharges && (
              <p className="errors">{errors.deliveryCharges.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="primary" type="submit">
              Add Pincode
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {isOpen === true ? (
        <Lightbox mainSrc={categImg} onCloseRequest={() => setOpen(false)} />
      ) : null}

      {/* Modal for Edit */}

      <Modal
        aria-labelledby="contained-modal-title-2-vcenter"
        centered
        show={show1}
        onHide={handleClose1}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(EditSubmit)}>
        <Modal.Body className="p-4 pt-0">
            <Form.Group className="mt-2">
              <Form.Label>Pincode</Form.Label>
              <Form.Control
                type="text"
                placeholder="pincode"
                autoComplete="off"
                {...register("pincode", {
                  required: "Pincode is required!",
                })}
              />
            </Form.Group>
            {errors.pincode && <p className="errors">{errors.pincode.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>City</Form.Label>
              <Form.Control
                type="text"
                placeholder="city"
                autoComplete="off"
                {...register("city", {
                  required: "City is required!",
                })}
              />
            </Form.Group>
            {errors.city && <p className="errors">{errors.city.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>State</Form.Label>
              <Form.Control
                type="text"
                placeholder="state"
                autoComplete="off"
                {...register("state", {
                  required: "State is required!",
                })}
              />
            </Form.Group>
            {errors.state && <p className="errors">{errors.state.message}</p>}

            <Form.Group className="mt-2">
              <Form.Label>Delivery Days</Form.Label>
              <Form.Control
                placeholder="delivery days"
                autoComplete="off"
                {...register("deliveryDays", {
                  required: "Delivery day is required!",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Invalid day!",
                  },
                })}
              />
            </Form.Group>
            {errors.deliveryDays && (
              <p className="errors">{errors.deliveryDays.message}</p>
            )}

            <Form.Label className="mt-3">Delivery Charges</Form.Label>
            <InputGroup>
              <InputGroup.Text id="basic-addon1">₹</InputGroup.Text>
              <Form.Control
                placeholder="delivery charges"
                autoComplete="off"
                {...register("deliveryCharges", {
                  required: "Delivery charges is required!",
                  pattern: {
                    value: /^[1-9]\d*(\.\d+)?$/,
                    message: "Invalid charges!",
                  },
                })}
              />
            </InputGroup>
            {errors.deliveryCharges && (
              <p className="errors">{errors.deliveryCharges.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="success" type="submit">
              Update
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      <div className="card mt-3">
        <div className="table-responsive" style={{ padding: "20px" }}>
          <PaginationProvider
            pagination={paginationFactory({
              custom: false,
              totalSize: categoryData.length,
              prePageText: "Previous",
              nextPageText: "Next",
              withFirstAndLast: false,
              page: 1,
              sizePerPageList: [
                {
                  text: "5",
                  value: 5,
                },

                {
                  text: "10",
                  value: 10,
                },
                {
                  text: "30",
                  value: 30,
                },
                {
                  text: "50",
                  value: 50,
                },
                {
                  text: "All",
                  value: categoryData.length,
                },
              ],
              hideSizePerPage: categoryData.length === 0,
            })}
            keyField="id"
            columns={columns}
            data={categoryData.map((item) => item)}
          >
            {({ paginationProps, paginationTableProps }) => (
              <ToolkitProvider
                keyField="id"
                columns={columns}
                data={categoryData.map((item) => item)}
                search
              >
                {(toolkitprops) => (
                  <>
                    <div className="d-flex justify-content-end mb-3">
                      <SizePerPageDropdownStandalone {...paginationProps} />
                      <SearchBar
                        className="ms-2"
                        {...toolkitprops.searchProps}
                        srText=" "
                      />
                    </div>
                    <BootstrapTable
                      {...toolkitprops.baseProps}
                      {...paginationTableProps}
                      defaultSorted={defaultSorted}
                      bootstrap4
                      defaultSortDirection="asc"
                      wrapperClasses="table-responsive"
                      hover
                      striped
                      condensed={false}
                      noDataIndication={
                        loading ? (
                          <img src={Loader} alt="loader" width={24} />
                        ) : (
                          "No Data Is Available"
                        )
                      }
                    />
                  </>
                )}
              </ToolkitProvider>
            )}
          </PaginationProvider>
        </div>
      </div>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default PincodeTable;
