import React, { useState, useEffect } from "react";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import { ReactComponent as EditIcon } from "../../../../Assets/Icon/Edit.svg";
// import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import "./MobileBannerTable.css";
// import { confirmAlert } from "react-confirm-alert";
import { ReactComponent as AddIcon } from "../../../../Assets/Icon/Add.svg";
import { ReactComponent as PromoBannerIcon } from "../../../../Assets/Icon/MobPromoBanner.svg";
import "react-confirm-alert/src/react-confirm-alert.css";
import { useForm } from "react-hook-form";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { Modal, Button, Form } from "react-bootstrap";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import { Input } from "reactstrap";
import $ from "jquery";
import jQuery from "jquery";
import Loader from "../../../../Assets/Icon/loading.gif";
import { imageUrl } from "../../../../config/settings/env";
import paginationFactory, { PaginationProvider, SizePerPageDropdownStandalone } from "react-bootstrap-table2-paginator";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import BootstrapTable from "react-bootstrap-table-next";
import { ReactComponent as DeleteIcon } from "../../../../Assets/Icon/Delete.svg";
import { confirmAlert } from "react-confirm-alert";
import { getAllPromotion, addPromotion, deletePromotion, promotionalBannerStatus, getPromotionbyId, editPromotionImage } from "../../../../Services/promotionService";
import { addMobilePromotion } from "../../../../Services/mobilepromotionService";

const MobileBannerTable = () => {
  const [categoryData, setCategoryData] = useState([]);
  const [isOpen, setOpen] = useState(false);
  const [categImg, setCategImg] = useState();
  const [catId, setCatId] = useState();
  const [catFile, setCatFile] = useState();
  const [image, setImage] = useState({ preview: "", raw: "" });
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => {
    reset();
    setShow(true);
  };

  const [show1, setShow1] = useState(false);
  const handleClose1 = () => {
    setShow1(false);
    setCatFile();
    setImage({ preview: "", raw: "" });
  }
  
  const handleShow1 = () => setShow1(true);
  const [loading, setLoading] = useState(false);

  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const { SearchBar } = Search;

  const columns = [
    {
      dataField: "sl no.",
      text: "Serial No",
      // headerAlign: "center",
      // align: "center",
      formatter: (cell, row, rowIndex, formatExtraData) => {
        return rowIndex + 1;
      },
    },
   
    {
      dataField: "imageUrl",
      text: "Image",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            {console.log("row : ", row)}
            {row.MediaObjects.map((rows, key) => (
              <input
                key={key}
                type="image"
                className="categoryImages"
                src={imageUrl + rows.imageUrl}
                alt="food_image"
                onClick={() => openLightbox(rows.imageUrl)}
              />
            ))}
          </div>
        );
      },
    },

    {
      dataField: "status",
      text: "Status",
      formatter: (row, rowContent) => {
        return (
          <div className="form-check form-switch">
            <input
              className="form-check-input"
              type="checkbox"
              role="switch"
              id="flexSwitchCheckDefault"
              defaultChecked={row}
              onClick={() => apiCheck(rowContent.id)}
            />
          </div>
        );
      },
    },

    {
      dataField: "link",
      text: "Action",
      formatter: (rowContent, row) => {
        return (
          <div className="d-flex">
            <EditIcon
              className="edit-icon"
              onClick={() => handleEdit(row.id, row.name)}
            />
            <DeleteIcon
              className="iconHover delete-icon"
              onClick={() => handleDelete(row.id, row.name)}
            />
          </div>
        );
      },
    },
  ];

  const defaultSorted = [
    {
      dataField: "id",
      order: "asc",
    },
  ];

  async function openLightbox(MyUrl) {
    setOpen(true);
    await setCategImg(imageUrl + MyUrl);
  }

  // ====================  get all data =================

  useEffect(() => {
    categories();
  }, []);

  const categories = () => {
    setLoading(true);
    setTimeout(() => {
      getAllPromotion()
      .then((res) => {
        setLoading(false);
        setCategoryData(res.data.data);
      })
      .catch(function (error) {});  
    }, 1000);
    
  };

  //  ================= add categrory =============
  const onSubmit = (data) => {
    var formData = new FormData();
    formData.append("banner", data.banner[0]);
    addMobilePromotion(formData)
      .then(function (res) {
        handleClose();
        toast.success("Mobile promotional banner added successfully", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        categories();
        reset();
      })

      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ===================== get api in modal ================

  const handleEdit = (rowId, rowName) => {
    handleShow1();
    reset();
    // Getting Data for Specific category
    getPromotionbyId(rowId)
      .then(function (response) {
        console.log(response.data.data)
        setCatId(response.data.data.id);
        setCatFile(
          `${imageUrl}${response.data.data.MediaObjects[0].imageUrl}`
        );
        setValue(
          "banner",
          `${imageUrl}${response.data.data.MediaObjects[0].imageUrl}`
        );
        
      })
      .catch(function (error) {});
  };

  // =================== edit category modal ==================

  // ================== upload category file ========================
  const handleChange = (e) => {
    if (e?.target?.files?.length) {
      setImage({
        preview: URL.createObjectURL(e?.target?.files[0]),
        raw: e?.target?.files[0],
      });
    }
  };

  const EditSubmit = async (e) => {
    var formData2 = new FormData();
    formData2.append("banner", image.raw);
    formData2.append("id", catId);
    editPromotionImage(formData2)
      .then((res) => {
        if (res.statusText === "OK") {
          categories();
          handleClose1();
          toast.info("Promotional Banner Edited Successfully", {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  // ========================= delete api =================
  function confirmDelete(rowId) {
    const deleteById = {
      id: rowId,
    };
    deletePromotion(deleteById)
      .then(function (res) {
        toast.success(res.data.data, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        categories();
      })
      .catch(function (error) {
        toast.error("Error while deleting Promotional Banner!", {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  function handleDelete(rowId, name) {
    confirmAlert({
      title: "Delete",
      message: `Are you sure you want to remove this item from the table?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            confirmDelete(rowId);
          },
        },
        {
          label: "No",
          className: "btn btn-success"
        },
      ],
    });
  }

  $(document).ready(function () {
    (function ($) {
      $("#filter").keyup(function () {
        var rex = new RegExp($(this).val(), "i");
        $(".searchable tr").hide();
        $(".searchable tr")
          .filter(function () {
            return rex.test($(this).text());
          })
          .show();
        $(".no-data").hide();
        if ($(".searchable tr:visible").length === 0) {
          $(".no-data").show();
        }
      });
    })(jQuery);
  });

  const apiCheck = (rowId) => {
    promotionalBannerStatus(rowId)
      .then((response) => {
        if (response.data.data.status === true) {
          toast.success(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        } else {
          toast.error(response.data.data.message, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      <div className="page-heading d-flex align-items-center justify-content-between">
        <div className="page-heading-wapper d-flex">
          <PromoBannerIcon className="page-icon m-0" style={{paddingTop: 13, paddingLeft: 13}}/>
          <h3 className="page-sec-heading m-0 mx-2">Mobile Promotional Banner</h3>
        </div>

        <div className="d-flex align-items-center">
          <button
            type="submit"
            className="btn btn-secondary btn-sm"
            onClick={handleShow}
          >
            {" "}
            <AddIcon /> Add new mobile promotional banner
          </button>
        </div>
      </div>
      {/* Modal for Adding New Category */}
      <Modal
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mt-3">
              <Form.Label>Mobile Promotional Banner image</Form.Label>
              <Form.Control
                type="file"
                id="formFile"
                {...register("banner", {
                  required: "Please provide an image!",
                })}
              />
            </Form.Group>
            {errors.banner && (
              <p className="errors">{errors.banner.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="primary" type="submit">
              Add Mobile Promotional Banner
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      {isOpen === true ? (
        <Lightbox mainSrc={categImg} onCloseRequest={() => setOpen(false)} />
      ) : null}

      {/* Modal for Edit */}

      <Modal
        aria-labelledby="contained-modal-title-2-vcenter"
        centered
        show={show1}
        onHide={handleClose1}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header
          className="border-0 shadow-none"
          closeButton
        ></Modal.Header>
        <Form onSubmit={handleSubmit(EditSubmit)}>
          <Modal.Body className="p-4 pt-0">
            <Form.Group className="mt-3">
              <Form.Label>Mobile promotional banner image</Form.Label>
              <div className="profile-pic-wrapper">
                <div className="profile-pic-holder">
                  <label htmlFor="upload-button">
                    {image.preview ? (
                      <img
                        src={image.preview}
                        id="profilePic"
                        className="pic"
                        alt="user_image"
                        {...register("banner", {})}
                      />
                    ) : (
                      <img
                        id="profilePic"
                        className="pic"
                        alt="user_image"
                        src={catFile}
                        {...register("banner", {})}
                      />
                    )}
                  </label>
                  <label htmlFor="upload-button" className="upload-file-block">
                    <div className="text-center">
                      <div className="mb-2"></div>
                      <div className="text-uppercase">
                        Update <br /> Promotional Image
                      </div>
                    </div>
                  </label>
                  <Input
                    className="uploadProfileInput d-none"
                    type="file"
                    name="profile_pic"
                    id="upload-button"
                    accept="image/*"
                    onChange={handleChange}
                  />
                </div>
              </div>
            </Form.Group>
            {errors.banner && (
              <p className="errors">{errors.banner.message}</p>
            )}
          </Modal.Body>
          <Modal.Footer className="border-0 pt-0 pb-4 d-flex justify-content-center">
            <Button variant="success" type="submit">
              Update
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
      <div className="card mt-3">
      <div className="table-responsive" style={{ padding: "20px" }}>
      <PaginationProvider
        pagination={paginationFactory({
          custom: false,
          totalSize: categoryData.length,
          prePageText: "Previous",
          nextPageText: "Next",
          withFirstAndLast: false,
          page: 1,
          sizePerPageList: [
            {
              text: "5",
              value: 5,
            },

            {
              text: "10",
              value: 10,
            },
            {
              text: "30",
              value: 30,
            },
            {
              text: "50",
              value: 50,
            },
            {
              text: "All",
              value: categoryData.length,
            },
          ],
          hideSizePerPage: categoryData.length === 0,
        })}
        keyField="id"
        columns={columns}
        data={categoryData}
      >
        {({ paginationProps, paginationTableProps }) => (
          <ToolkitProvider
            keyField="id"
            columns={columns}
            data={categoryData}
            search
          >
            {(toolkitprops) => (
              <>
                <div className="d-flex justify-content-end mb-3">
                  <SizePerPageDropdownStandalone {...paginationProps} />
                  <SearchBar
                    className="ms-2"
                    {...toolkitprops.searchProps}
                    srText=" "
                  />
                </div>
                <BootstrapTable
                  {...toolkitprops.baseProps}
                  {...paginationTableProps}
        
                  defaultSortDirection="asc"
                  wrapperClasses="table-responsive"
                  hover
                  striped
                  condensed={false}
                  // noDataIndication="No Data Available"
                  noDataIndication={loading?<img src={Loader} alt="loader" width={24} />:"No Data Is Available"}
                />
              </>
            )}
          </ToolkitProvider>
        )}
      </PaginationProvider>
    </div>
    </div>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};

export default MobileBannerTable;
