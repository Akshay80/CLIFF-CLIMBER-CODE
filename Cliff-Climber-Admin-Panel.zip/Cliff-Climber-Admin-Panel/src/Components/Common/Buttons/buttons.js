import React from 'react'

export const buttons = () => {
    return (
        <div className="btn-primary">
            btn
        </div>
    )
}

