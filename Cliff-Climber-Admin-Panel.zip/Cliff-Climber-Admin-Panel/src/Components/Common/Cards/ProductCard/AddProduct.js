import React, { useEffect, useState } from "react";
import "./Product.css";
import General from "./AddProductComp/Genral";
import Media from "./AddProductComp/Media";
import Variant from "./AddProductComp/Variant";
import SearchEngine from "./AddProductComp/SearchEngine";
import ProductStatus from "./AddProductComp/ProductStatus";
import Inventory from "./AddProductComp/Inventory";
import SelectCategories from "./AddProductComp/SelectCategories";
import Brands from "./AddProductComp/Brands";
import AddAttribute from "./AddProductComp/AddAttribute";
import GST from "./AddProductComp/GST";
import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";
import e from "cors";
import { tagStatus } from "../../../../Services/tagServices";
import Tags from "./AddProductComp/Tags";
import { createProduct } from "../../../../Services/productService";
import { ToastContainer, toast, Flip } from "react-toastify";
import { useNavigate } from "react-router-dom";

const AddProduct = () => {
  const navigate = useNavigate();
  const [variationArr, setVariationArr] = useState([]);
  const [isLoading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const productSubmit = async (e) => {
    console.log("variation ki value: ", variationArr.variant);
    const params = {
      simple: {
        productInfo: {
          productType: e.product_type,
          sku: e.productSku,
          price: e.productPrice,
          weight: e.productWeight,
          hsn: e.hsn,
          qty: e.quantity,
          brandId: e.brand,
          manageStock: e.manageStock,
          stockAvailability: true,
          status: e.status === "true" ? true : false,
          visibility: e.visibility === "true" ? true : false,
          isFeatured: e.featured,
          gstId: e.gst,
          parent: 1,
        },
        ProductAdditionalInfos: {
          weight: e.productWeight,
          dimensions: `${e.length} x ${e.breadth} x ${e.height}`,
          materials: e.materials,
          otherInfo: e.otherInfo,
          
          weightType: e.product
        },
        descriptions: {
          name: e.productName,
          description: e.productLongDescription,
          shortDescription: e.productShortDescription,
          urlKey: e.urlKey,
          metaTitle: e.metaTitle,
          metaDescription: e.metaDescription,
          metaKeywords: e.metaKeyword,
        },
        categories: {
          categoryId: e.category,
          subCategoryId: e.subCategory,
        },
        attributes: JSON.parse(localStorage.getItem("attributeArr")),
        tags: JSON.parse(localStorage.getItem("tags")),
        productImages: JSON.parse(localStorage.getItem("items")),
      },
      variations:
        variationArr.variant !== undefined ? variationArr.variant : [],
    };

    for (let index in params?.variations) {
      if (params?.variations.hasOwnProperty(index)) {
          console.log("params if: ", params.variations[index].hsn);
          params.variations[index].hsn = e.hsn;
        } 
    }

    console.log(params);

    await createProduct(params)
      .then((response) => {
        console.log(response.data.data.error);
        console.log(response.data.data.success);
        if (response.data.success === true) {
          setLoading(true);
          toast.success(response.data.data, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
          setTimeout(() => {
            navigate(-1);
          }, 3000);
        } else {
          toast.error(response.data.error, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3500,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });

    // localStorage?.getItem("tags")?.map((str, index) => console.log({ tagId: str }))
    // console.log("e", e);
    // console.log("tags", JSON.parse(localStorage.getItem("tags")));
    // console.log(
    //   "attributeArr",
    //   JSON.parse(localStorage.getItem("attributeArr"))
    // );
    // console.log(
    //   "productImages",
    //   JSON.parse(localStorage.getItem("productImages"))
    // );
  };

  useEffect(() => {
    const json = localStorage.getItem("productImages");
    console.log(json);
  }, []);
  return (
    <div className="test">
      <form id="product-edit-form" onSubmit={handleSubmit(productSubmit)}>
        <div className="page-heading d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center">
            <Link to={"/products"} className="btn btn-secondary btn-sm">
              {" "}
              Back To All Product
            </Link>
          </div>
        </div>
        <div className="row">
          <div className="col-md-8">
            <General register={register} formStateError={errors} />
            <div className="row">
              <div className="col-md-6">
                <SelectCategories register={register} />
                <Brands register={register} formStateError={errors} />
              </div>
              <div className="col-md-6">
                <AddAttribute register={register} />
                <Tags />
              </div>
            </div>

            <Media />
            {/* <Variant register={register}/>
            <SearchEngine register={register} formStateError={errors} /> */}
          </div>
          <div className="col-md-4">
            <ProductStatus register={register} />
            <Inventory register={register} formStateError={errors} />
            <GST register={register} formStateError={errors} />
            {/* <AddAttribute register={register} /> */}
          </div>
        </div>
        <Variant register={register} setVariationArr={setVariationArr} />
        <SearchEngine register={register} formStateError={errors} />
        <div className="form-submit-button flex border-t border-divider my-5 justify-between">
          {/* <button type="button" className="btn btn-success mx-3">
            <span>Cancel</span>
          </button> */}
          {isLoading ? (
            <button type="submit" className="btn btn-success mx-3" disabled>
              <span><i class="fa fa-refresh fa-spin"></i> Saving...</span>
            </button>
          ) : (
            <button type="submit" className="btn btn-success mx-3">
              <span>Save</span>
            </button>
          )}
          {/* <button type="submit" className="btn btn-success mx-3">
            <span>Save</span>
          </button> */}
        </div>
      </form>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </div>
  );
};

export default AddProduct;
