import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { viewAttributeFun } from "../../../../../Services/attributeService";

const EditAttribute = ({ register, attributes, setValue }) => {
  const [id, setId] = useState();
  const [attributeData, setAttributeData] = useState([]);
  const [attributeArr, setAttributeArr] = useState([]);
  const [variationRelationId, setVariationRelId] = useState();
  const [categoryID, setCategoryID] = useState();
  const [boolCheck, setBoolean] = useState(false);
  const [newData, setNewData] = useState([]);
  const [state, setState] = useState(false);
  const [names, setNames] = useState();
  const [IDS, setIDS] = useState();
  const [arr, setArr] = useState();

 

  const viewAttributeData = async() => {
    await viewAttributeFun()
      .then((res) => {
        setAttributeData(res?.data?.data);
        attributeData.forEach((item) => {
          attributes.forEach((attr) => {
            if (item?.id === attr?.attributeId) {
              item?.AttributeOptions.forEach((data) => {
                if (data?.name === attr.optionText) {
                  data.selected = true;
                  const datas = attributeData.map((item) =>
                    item?.AttributeOptions?.map((items) => items)
                  );
                  const names = attributeData.map((item) =>
                    item?.AttributeOptions?.map((items) => items?.optionText)
                  );
                  const issue = attributeData.map((item) =>
                    item?.AttributeOptions?.map((items) => items?.id)
                  );
                  setNames(names);
                  setState(datas);
                  setIDS(issue);
                }
              });
            }
          });
        });
      })
      .catch(function (error) {});
    setNewData(attributeData);
  };

  const attributeChange = (e) => {
    setId(e.target.id);
    setBoolean(true);
    const index = e.target.selectedIndex;
    const el = e.target.childNodes[index];
    const option = el.getAttribute("id");
    setCategoryID(option);

    if (e.target.name === "color") {
      setVariationRelId(e.target.selectedOptions[0].id);
    }
    const arr = {
      attributeId: e.target.id,
      attributeOptionId: e.target.selectedOptions[0].id,
      optionText: e.target.value,
      variationRelationId:
        e.target.name === "color"
          ? e.target.selectedOptions[0].id
          : variationRelationId,
    };
    // console.log(arr);
    // localStorage.setItem("attributeArr", JSON.stringify(arr));
    setAttributeArr((prev) => [...prev, arr]);
  };

  if (attributeArr) {
    localStorage.setItem("attributeArr", JSON.stringify(attributeArr));
  }

  useEffect(() => {
    viewAttributeData();
    // localStorage.removeItem("attributeArr");
    setArr(attributes.map((item) => item));
    // console.log(attributes.map((item) => item));
    setValue("attributes", attributes.map(item => item))
   
  }, [attributes, setValue]);

  return (
    <div className="card shadow  my-3">
      <div className="card-section pb-1 box-border">
        <div className="flex justify-between pb-0 card-section-header mb-1">
          <h3 className="card-session-title">Attributes</h3>
        </div>
        <div className="card-session-content pt-lg">
          <table className="table table-auto">
            <tbody>
              {newData?.map((data) => (
                <tr key={data?.id}>
                  <td>{data?.name}</td>
                  <td>
                    <div className="form-field-container dropdown null">
                      <div className="field-wrapper flex flex-grow items-baseline">
                        <select
                          className="form-field"
                          id={data?.id}
                          name={data?.nameCode}
                          // {...register("attributes")}
                          onChange={(e) => {
                            attributeChange(e);
                          }}
                        >
                          {/* NEW THING */}
                          {data?.AttributeOptions?.map((option, key) => (
                            <option
                              key={key}
                              id={option?.id}
                              value={option?.optionText}
                              // {...register("attributes")}
                              pid={option?.id}
                              selected={option.selected === true}
                            >
                              {option?.name}
                            </option>
                          ))}
                        </select>

                        <div className="field-border"></div>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default EditAttribute;
