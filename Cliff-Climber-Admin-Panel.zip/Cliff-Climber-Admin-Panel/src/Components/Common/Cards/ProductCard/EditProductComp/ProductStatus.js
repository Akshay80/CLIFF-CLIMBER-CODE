import React from "react";
import { useEffect, useState } from "react";

const ProductStatus = ({ register, status, visibility, featured, setValue, productType }) => {
  // const {
  //   // handleSubmit,
  //   // formState: { errors },
  //   setValue
  // } = useForm();
  const [productName, setProductName] = useState();
  const [boolCheck, setBoolean] = useState(false);

useEffect(() => {
  // console.log(status);
  setValue("status", `${status}`);
  setValue("visibility",`${visibility}`);
  setValue("featured", `${featured}`);

},[status, visibility, featured, setValue]);

const handleChange = (e) => {
  setBoolean(true);
  const index = e.target.selectedIndex;
  const el = e.target.childNodes[index];
  const option = el.getAttribute("id");
  setProductName(option);
};
  return (
    <div className="card shadow my-3 subdued">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Product status</h2>
      </div>
      <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="status">Status</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="status0" className="flex">
                  <input
                    type="radio"
                    id="status0"
                    name="status"
                    aria-label="radio 1"
                    label="Design"
                    value={false}
                    {...register("status")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">Disabled</span>
                </label>
              </div>
              <div>
                <label htmlFor="status1" className="flex">
                  <input
                    aria-label="radio 1"
                    type="radio"
                    id="status1"
                    name="status"
                    value={true}
                    {...register("status")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Enabled</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div className="card-section   box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="visibility">Visibility</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="visibility0" className="flex">
                  <input
                    type="radio"
                    id="visibility0"
                    name="visibility"
                    value={false}
                    {...register("visibility")}
                  />
                  {/* <span className="radio-checked">
                    <span></span>
                  </span> */}
                  <span className="pl-1">Not visible</span>
                </label>
              </div>
              <div>
                <label htmlFor="visibility1" className="flex">
                  <input
                    type="radio"
                    id="visibility1"
                    name="visibility"
                    value={true}
                    {...register("visibility")}
                  />
                  {/* <span className="radio-unchecked"></span> */}
                  <span className="pl-1">Visible</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="visibility">Featured product</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="visibility0" className="flex">
                  <input
                    type="radio"
                    id="featured"
                    value={false}
                    {...register("featured")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">Disabled</span>
                </label>
              </div>
              <div>
                <label htmlFor="visibilit1" className="flex">
                  <input
                    type="radio"
                    id="featured"
                    value={true}
                    {...register("featured")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Enabled</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="card-section  box-border">
        <div className="form-field-container dropdown null">
          <label htmlFor="status">Product Type</label>
          <div className="field-wrapper flex flex-grow items-baseline">
            <select className="form-field" {...register("product_type")} 
            onChange={(e) => handleChange(e)}
            id="product_Type"
            value={boolCheck === true ? productName : productType}
            > 
              <option value="Other Order" id="Other Order">Other Order</option>
              <option value="Combat Uniform" id="Combat Uniform">Combat Uniform</option>
              <option value="Combat Jackets" id="Combat Jackets">Combat Jackets</option>
            </select>
            <div className="field-border"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProductStatus;
