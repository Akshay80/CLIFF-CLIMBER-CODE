import React, { useEffect } from "react";

const General = ({
  register,
  formStateError,
  name,
  sku,
  price,
  weight,
  currency,
  shortDescription,
  longDescription,
  setValue,
  additionalInfo,
}) => {
  useEffect(() => {
    settingValues();
  }, [settingValues]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  function settingValues() {
    console.log("additional Info: ", additionalInfo)
    var data = additionalInfo?.dimensions;
    var splitData = data?.split("x");
    var arr = [];
    for (var i = 0; i < splitData?.length; i++) {
      arr.push(splitData[i]);
    }

    setValue("productName", name);
    setValue("productSku", sku);
    setValue("productPrice", price);
    setValue("productWeight", weight);
    setValue("productShortDescription", shortDescription);
    setValue("productLongDescription", longDescription);
    setValue("length", arr[0] === undefined? "": arr[0]);
    setValue("breadth", arr[1] === undefined? "": arr[1]);
    setValue("height", arr[2] === undefined? "": arr[2]);
    setValue("materials", additionalInfo?.materials);
    setValue("otherInfo", additionalInfo?.otherInfo);
    setValue("weight", additionalInfo?.weight);
  }
  return (
    <div className="card shadow my-3">
      <div className="flex justify-between card-header">
        <h2 className="card-title">General</h2>
      </div>
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          <div className="">
            <div className="form-field-container null">
              <label htmlFor="name">Name</label>
              <div className="field-wrapper flex flex-grow">
                <input
                  type="text"
                  placeholder="Name"
                  defaultValue={name}
                  // defaultValue=""
                  {...register("productName")}
                />

                <div className="field-border"></div>
              </div>
              {formStateError.productName && (
                <p className="errors">{formStateError.productName.message}</p>
              )}
            </div>
            <div className="row my-2">
              <div className="col-md-4">
                <div className="form-field-container null">
                  <label htmlFor="sku">SKU</label>
                  <div className="field-wrapper flex flex-grow">
                    <input
                      type="text"
                      placeholder="SKU"
                      defaultValue={sku}
                      {...register("productSku")}
                    />
                    <div className="field-border"></div>
                  </div>
                  {formStateError.productSku && (
                    <p className="errors">
                      {formStateError.productSku.message}
                    </p>
                  )}
                </div>
              </div>
              <div className="col-md-4">
                <div className="form-field-container null">
                  <label htmlFor="price">Price</label>
                  <div className="field-wrapper flex flex-grow">
                    <div className="input-group mb-3">
                      <span className="input-group-text">{currency}</span>
                      <input
                        type="text"
                        placeholder="Price"
                        // defaultValue=""
                        defaultValue={price}
                        {...register("productPrice")}
                      />
                      <div className="field-border"></div>
                    </div>
                    {formStateError.productPrice && (
                      <p className="errors">
                        {formStateError.productPrice.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="form-field-container null">
                  <label htmlFor="weight">Weight</label>
                  <div className="field-wrapper flex flex-grow">
                    <input
                      type="text"
                      placeholder="Weight"
                      // defaultValue=""
                      defaultValue={weight}
                      {...register("productWeight")}
                    />
                    <div className="field-border"></div>
                  </div>
                  {formStateError.productWeight && (
                    <p className="errors">
                      {formStateError.productWeight.message}
                    </p>
                  )}
                </div>
              </div>
              {/* 1 */}
              <div className="col-md-9">
                <div className="form-field-container null">
                  <label>Dimensions</label>
                  <div className="input-group">
                    <input
                      type="text"
                      aria-label="Length"
                      className="form-control"
                      placeholder="Length"
                      {...register("length")}
                    />
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text"
                        style={{ borderRadius: "0!important" }}
                      >
                        x
                      </span>
                    </div>
                    <input
                      type="text"
                      aria-label="Breadth"
                      className="form-control"
                      placeholder="Breadth"
                      {...register("breadth")}
                    />
                    <div className="input-group-prepend">
                      <span
                        className="input-group-text"
                        style={{ borderRadius: "0!important" }}
                      >
                        x
                      </span>
                    </div>
                    <input
                      type="text"
                      aria-label="Height"
                      className="form-control"
                      placeholder="Height"
                      {...register("height")}
                    />
                  </div>
                </div>
              </div>

              {/* 2 */}
              <div className="col-md-3">
                <div className="form-field-container null">
                  <label htmlFor="weight">Material</label>
                  <div className="field-wrapper flex flex-grow">
                    <input
                      type="text"
                      placeholder="Material"
                      // defaultValue=""
                      {...register("materials")}
                    />
                    <div className="field-border"></div>
                  </div>
                  {formStateError.materials && (
                    <p className="errors">{formStateError.materials.message}</p>
                  )}
                </div>
              </div>
              {/* 3 */}
              <div className="col-md-12">
                <div className="form-field-container null">
                  <label htmlFor="weight">Additional Information</label>
                  <div className="field-wrapper flex flex-grow">
                    <textarea
                      {...register("otherInfo")}
                    />
                    <div className="field-border"></div>
                  </div>
                  {formStateError.otherInfo && (
                    <p className="errors">{formStateError.otherInfo.message}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="form-field-container null">
              <label htmlFor="description">Short Description</label>
              <div className="field-wrapper flex flex-grow">
                <textarea
                  type="text"
                  className="form-field"
                  id="Shortdescription"
                  defaultValue={shortDescription}
                  {...register("productShortDescription")}
                ></textarea>
                <div className="field-border"></div>
              </div>
              {formStateError.productShortDescription && (
                <p className="errors">
                  {formStateError.productShortDescription.message}
                </p>
              )}
            </div>

            <div className="form-field-container null">
              <label htmlFor="description">Long Description</label>
              <div className="field-wrapper flex flex-grow">
                <textarea
                  type="text"
                  className="form-field"
                  id="description"
                  defaultValue={longDescription}
                  {...register("productLongDescription")}
                ></textarea>
                <div className="field-border"></div>
              </div>
              {formStateError.productLongDescription && (
                <p className="errors">
                  {formStateError.productLongDescription.message}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default General;
