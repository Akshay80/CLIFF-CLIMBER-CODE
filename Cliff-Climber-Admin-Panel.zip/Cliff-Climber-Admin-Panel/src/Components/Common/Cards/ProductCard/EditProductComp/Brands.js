import React from "react";
import { useState, useEffect } from "react";
import { getAllBrandFun } from "../../../../../Services/brandService";

const Brands = ({ register, brandId, setValue }) => {
  const [brand, setBrand] = useState([]);
  const [categoryID, setCategoryID] = useState('');
  const [boolCheck, setBoolean] = useState(false);
 
  //   const TagsData = createContext(tagValues);

  useEffect(() => {
    brandData();
   
    setValue("brand", brandId)
  }, [brandId, setValue]);

  //   brand api call
  const brandData = async () => {
    await getAllBrandFun()
      .then((res) => {
        setBrand(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const handleChange = (e) => {
    setBoolean(true);
    const index = e.target.selectedIndex;
    const el = e.target.childNodes[index];
    const option = el.getAttribute("id");
    setCategoryID(option);
  };

 
  return (
    <div className="card shadow my-3">
      
      <div className="card-section  box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">Brands</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  id="group_id"
                  {...register("brand")}
                  onChange={(e) => handleChange(e)}
                  value={boolCheck === true ? categoryID : brandId}
                >
                  {brand?.map((brandData, key) => {
                    return (
                      <option value={brandData?.id} key={brandData?.id} id={brandData?.id}>
                        {brandData?.name}
                      </option>
                    );
                  })}
                </select>
                <div className="field-border"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

     
    </div>
  );
};
export default Brands;
