import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { viewCategoryFun } from "../../../../../Services/categoryService";
import { viewSubCategoryFun } from "../../../../../Services/subCategoryService";

const SelectCategories = ({ register, selectValue, selectSubvalue, setValue }) => {
  const [categoryData, setCategoryData] = useState([]);
  const [subCategoryData, setSubCategoryData] = useState([]);
  const [displaySubCategory, setDisplaySubCategory] = useState(false);
  const [categoryID, setCategoryID] = useState();
  const [boolCheck, setBoolean] = useState(false);
  const categories = async () => {
    await viewCategoryFun()
      .then((res) => {
        setCategoryData(res.data.data);
      })
      .catch(function (error) {});
  };

  const subCategory = async () => {
    await viewSubCategoryFun()
      .then((res) => {
        res?.data?.data?.map((subCate) => {
          setSubCategoryData((prev) => [...prev, subCate]);
        });
      })
      .catch(function (error) {});
  };

  useEffect(() => {
    categories();
    subCategory();
  }, []);

  useEffect(() => {
    // console.log(selectValue.name);
    // console.log(selectSubvalue.name);
    setValue("category", selectValue.categoryId);
    setValue("subCategory", selectSubvalue.subCategoryId);
  }, [selectValue.name, selectSubvalue.name])

  const handleChange = (e) => {
    setBoolean(true);
    const index = e.target.selectedIndex;
    const el = e.target.childNodes[index];
    const option = el.getAttribute("id");
    setCategoryID(option);
  };

  //   sub category
  // const categoryChange = (e) => {
  //   if (e.target.value) {
  //     // setDisplaySubCategory(true);
  //   } else {
  //     console.log("something went wrong");
  //   }
  // };

 

  return (
    <div className="card shadow my-3">
      <div className="card-section  box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">Categories</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  id="group_id"
                  {...register("category")}
                  
                  onChange={(e) => handleChange(e)}
                  value={boolCheck === true ? categoryID : selectValue.categoryId}
                  // selected={selectValue.name}
                  // onChange={(e) => categoryChange(e)}
                >
                  {categoryData?.map((category, key) => (
                    <option
                      value={category.id}
                      key={category.id}
                      id={category.id}
                    >
                      {category.name}
                    </option>
                  ))}
                </select>
                <div className="field-border"></div>
              </div>
              {/* {displaySubCategory && ( */}
              <div className="field-wrapper flex flex-grow items-baseline mt-3 mb-4">
                <select
                  className="form-field"
                  // id="group_id"
                  {...register("subCategory")}
                  // selected={selectSubvalue.name}
                  onChange={(e) => handleChange(e)}
                value={boolCheck === true ? categoryID : selectSubvalue.subCategoryId}
                >
                  {subCategoryData?.map((data, key) => (
                    <option
                      key={data.id}
                      id={data.id}
                      value={data.id}
                      // value={data?.id}
                      // value={boolCheck === true ? categoryID : selectValue.id}
                    >
                      {data?.name}
                    </option>
                  ))}
                </select>
                <div className="field-border"></div>
              </div>
              {/* )} */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SelectCategories;
