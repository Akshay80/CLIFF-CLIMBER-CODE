import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import Select from "react-select";
import makeAnimated from "react-select/animated";
import { getAllTagFun } from "../../../../../Services/tagServices";

const animatedComponents = makeAnimated();

const Tags = ({ register, tags , setValue}) => {
  const [tag, setTag] = useState([]);
  const [tagValues, setTagValues] = useState({value: "", label: ""});

  useEffect(() => {
    tagdata();
    localStorage.removeItem("edittags");
  }, []);

  //   tag api call
  const tagdata = () => {
    getAllTagFun()
      .then((res) => {
        setTag(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const Options = tag.map(({ id, name }) => ({ value: id, label: name }));

  useEffect(() => {
    let tagss = tags.map(({tagId, name }) => ({value: tagId, label: name}))
    setTagValues(tagss);
    setValue("tags", tags);
  }, [tags]);

  const handleChange = (e) => {
    setTagValues(e)
  }

  return (
    <div className="card shadow my-3">
      <div className="card-section  box-border">
        <div className="flex pb-1 justify-between card-section-header mb-1">
          <h3 className="card-session-title">Tags</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <Select
                  components={animatedComponents}
                  isMulti
                  options={Options}
                  value={tagValues}
                  className="basic-multi-select tags"
                  classNamePrefix="select"
                  onChange={(e) => {
                    localStorage.setItem(
                      "edittags",
                      JSON.stringify(e.map((VAL) => ({ tagId: VAL.value })))
                    );
                    handleChange(e);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Tags;
