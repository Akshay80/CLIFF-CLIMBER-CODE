import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { viewGST } from "../../../../../Services/gstService";

const GST = ({ register, gstId, setValue, gst }) => {
  const [gsts, setGST] = useState([]);
  const [categoryID, setCategoryID] = useState('');
  const [boolCheck, setBoolean] = useState(false);

  //   const TagsData = createContext(tagValues);

  useEffect(() => {
    gstData();
    setValue("gst", gstId)
  }, [gst, setValue]);

  //   brand api call
  const gstData = async () => {
    await viewGST()
      .then((res) => {
        setGST(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const handleChange = (e) => {
    setBoolean(true);
    const index = e.target.selectedIndex;
    const el = e.target.childNodes[index];
    const option = el.getAttribute("id");
    setCategoryID(option);
  };

  return (
    // <div className="card shadow my-3">
      // <div className="card-section  box-border">
      <div className="card shadow my-3 subdued">
      <div className="flex justify-between card-header">
        <h2 className="card-title">GST</h2>
      </div>
        {/* <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">GST</h3>
        </div> */}
        <div className="card-session-content pt-lg p-4">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  id="group_id"
                  {...register("gst")}
                  onChange={(e) => handleChange(e)}
                  value={boolCheck === true ? categoryID : gstId}
                >
                  {/* <option defaultValue="" disabled="">
                    Select GST
                  </option> */}
                  {gsts?.map((gstData, key) => {
                    return (
                      <option value={gstData?.id} key={key}>
                        {gstData?.gst}
                      </option>
                    );
                  })}
                </select>
                <div className="field-border"></div>
              </div>
            </div>
          </div>
        </div>
        </div>
    //   </div>
    // </div>
  );
};
export default GST;
