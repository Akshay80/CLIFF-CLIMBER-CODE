/* eslint-disable react-hooks/exhaustive-deps */
import React, { useCallback, useEffect } from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
// import ImageUploader from "react-images-upload";
import { viewAttributeFun } from "../../../../../Services/attributeService";
import { viewGST } from "../../../../../Services/gstService";
import { imageUrl } from "../../../../../config/settings/env";
import {
  deleteProductImage,
  uploadProductImage,
  uploadProductImageUpdate,
} from "../../../../../Services/productService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { isEmpty } from "lodash";
import { data } from "jquery";

const Variant = ({ variants, setVariants, sku }) => {
  const [variant, setVariant] = useState(true);
  const [createVariant, setCreateVariant] = useState(true);
  const [newVariant, setNewVariant] = useState(true);
  const [attributeData, setAttributeData] = useState([]);
  const [id, setId] = useState();
  const [attributeArr, setAttributeArr] = useState([]);
  const [variationRelationId, setVariationRelId] = useState();
  const [gst, setGST] = useState([]);
  const [deleted, setDeleted] = useState([]);
  const [key, _] = useState(Math.floor(1000 + Math.random() * 9000));
  const [key1, __] = useState(Math.floor(1000 + Math.random() * 9000));
  const [click, setClick] = useState(false);
  const [imag, setImage] = useState([]);
  const [hideStatus, setHideStatus] = useState(false);
  const [random, setRandom] = useState(Math.floor(1000 + Math.random() * 9000));
  const [change, setChange] = useState([]);
  useEffect(() => {
    gstData();
    // setVariationArr(variants)
  }, []);

  //   GST api call
  const gstData = async () => {
    await viewGST()
      .then((res) => {
        setGST(res?.data?.data);
        // console.log(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const viewAttributeData = () => {
    viewAttributeFun()
      .then((res) => {
        setAttributeData(res?.data?.data);
      })
      .catch(function (error) {});
  };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    const list = [...variants];
    list.splice(index, 1);
    setVariants(list);
  };

  const handleAddClick = () => {
    const values = [...variants];
    setRandom(Math.floor(1000 + Math.random() * 9000));
    // console.log(values.map((item) => item[0]?.variantGroupId));
    if (values?.length <= 1) {
      values.push({
        productId: null,
        variantGroupId: variants[0].variantGroupId,
        sku: "",
        price: "",
        qty: "",
        gst: "",
        ProductAdditionalInfos: {
          weight: "",
          dimensions: "",
          materials: "",
          otherInfo: "",
        },
        attributes: [
          {
            attributeId: "",
            attributeOptionId: "",
            optionText: "",
            variationRelationId: "",
          },
        ],
        productImages: [],
      });
    } else {
      values.push({
        productId: null,
        variantGroupId: variants[0].variantGroupId,
        sku: "",
        price: "",
        qty: "",
        gst: "",
        ProductAdditionalInfos: {
          weight: "",
          dimensions: "",
          materials: "",
          otherInfo: "",
        },
        attributes: [
          {
            attributeId: "",
            attributeOptionId: "",
            optionText: "",
            variationRelationId: "",
          },
        ],
        productImages: [],
      });
    }
    // setRand(Math.floor(1000 + Math.random() * 9000));

    setVariants(values);
  };

  const addNewVariant = () => {
    setRandom(Math.floor(1000 + Math.random() * 9000));
    console.log("clicked");
    if (isEmpty(variants)) {
      setVariants([
        {
          variantGroupId: null,
          sku: "",
          price: "",
          qty: "",
          gstId: "",
          ProductAdditionalInfos: {
            weight: "",
            dimensions: "",
            materials: "",
            otherInfo: "",
          },
          attributes: [
            {
              attributeId: "",
              attributeOptionId: "",
              optionText: "",
              variationRelationId: "",
            },
          ],
          productImages: [],
        },
      ]);
    } else {
      handleAddClick();
    }
    setNewVariant(true);
  };

  const handleOnChange = (i, subindex, type, value) => {
    const values = [...variants];
    console.log(values[i].ProductAdditionalInfos);
    if (subindex === 0 && subindex !== false) {
      values[i].ProductAdditionalInfos[subindex][type] = value;
    } else if (!subindex) {
      values[i][type] = value;
    }

    if (
      !isEmpty(values[i].ProductAdditionalInfos.length) &&
      !isEmpty(values[i].ProductAdditionalInfos.breadth) &&
      !isEmpty(values[i].ProductAdditionalInfos.height)
    ) {
      values[i].ProductAdditionalInfos[
        "dimensions"
      ] = `${values[i].ProductAdditionalInfos.length} x ${values[i].ProductAdditionalInfos.breadth} x ${values[i].ProductAdditionalInfos.height}`;
    }

    // if (
    //   !isEmpty(values[i].ProductAdditionalInfos[0].length) &&
    //   !isEmpty(values[i].ProductAdditionalInfos[0].breadth) &&
    //   !isEmpty(values[i].ProductAdditionalInfos[0].height)
    // ) {
    //   values[i].ProductAdditionalInfos[0][
    //     "dimensions"
    //   ] = `${values[i].ProductAdditionalInfos[0].length} x ${values[i].ProductAdditionalInfos[0].breadth} x ${values[i].ProductAdditionalInfos[0].height}`;
    // }
    setVariants(values);
  };

  useEffect(() => {
    viewAttributeData();
  }, []);

  const attributeChange = (i, subindex, value) => {
    let innerVal = [];
    let selectedAttributeData = [];
    const values = [...variants];

    if (
      values[i].attributes.length === 1 &&
      values[i].attributes[0].optionText === ""
    ) {
      attributeData.forEach((data) => {
        innerVal = data.AttributeOptions.filter((val) => val.name == value);
        if (!isEmpty(innerVal)) {
          values[i].attributes[subindex].optionText = value;
          values[i].attributes[subindex].attributeId = data.id;
          values[i].attributes[subindex].attributeOptionId = innerVal[0].id;
          values[i].attributes[subindex].variationRelationId = innerVal[0].id;
        }
      });
    } else if (
      values[i].attributes.length === 1 &&
      values[i].attributes[0].optionText !== value
    ) {
      attributeData.forEach((data) => {
        selectedAttributeData = data;
        innerVal = data.AttributeOptions.filter((val) => val.name === value);
      });
      values[i].attributes.push({
        attributeId: selectedAttributeData.id,
        attributeOptionId: innerVal[0].id,
        optionText: value,
        variationRelationId: values[i].attributes[0].variationRelationId,
      });
    }

    if (
      values[i].attributes.length === 2 &&
      values[i].attributes[0].optionText !== ""
    ) {
      attributeData.forEach((data) => {
        innerVal = data.AttributeOptions.filter((val) => val.name == value);
        if (!isEmpty(innerVal)) {
          values[i].attributes[subindex].optionText = value;
          values[i].attributes[subindex].attributeId = data.id;
          values[i].attributes[subindex].attributeOptionId = innerVal[0].id;
          values[i].attributes[subindex].variationRelationId = innerVal[0].id;
        }
      });
    } else if (
      values[i].attributes.length === 2 &&
      values[i].attributes[0].optionText !== value
    ) {
      attributeData.forEach((data) => {
        selectedAttributeData = data;
        innerVal = data.AttributeOptions.filter((val) => val.name === value);
      });
      values[i].attributes.push({
        attributeId: selectedAttributeData.id,
        attributeOptionId: innerVal[0].id,
        optionText: value,
        variationRelationId: values[i].attributes[0].variationRelationId,
      });
    }

    setVariants(values);
  };

  if (attributeArr.length > 0) {
    localStorage.setItem("VarattributeArr", JSON.stringify(attributeArr));
  }

  const onButton = async (e, i, sku, productId) => {
    setClick(false);
    let imageKey = sku ? sku : random;
    var formData = new FormData();
    formData.append("key", imageKey);
    formData.append("product", e.target.files[0]);
    const imageData = [...imag];
    // API call for Image Upload
    console.log("productID: ", productId)
    if (productId !== null) {
      formData.append("productId", productId);
      await uploadProductImageUpdate(formData)
        .then((response) => {
          if (response.data.success === true) {
            // getProductsByID();
            toast.success("Variant Image has been Uploaded!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: false,
              progress: 0,
              toastId: "my_toast",
            });
          }

          setHideStatus(true);
          setImage(response.data.data);
          const values = [...variants];
          const apiVal = response.data.data;
          const element = [];
          for (const key in apiVal) {
            if (Object.hasOwnProperty.call(apiVal, key)) {
              element.push({ image: apiVal[key].imageUrl, key: imageKey });
            }
          }
          values[i].productImages = element;
          setVariants(values);
          if (variants) {
            let imageUpdateObj = response.data.data;
            let apiImageObj = variants.productImages;
            for (const key in imageUpdateObj) {
              if (Object.hasOwnProperty.call(imageUpdateObj, key)) {
                const element1 = imageUpdateObj[key];
                for (const key in apiImageObj) {
                  if (Object.hasOwnProperty.call(apiImageObj, key)) {
                    const element2 = apiImageObj[key];
                    if (element1.imageUrl === element2.image) {
                      element1.id = element2.id;
                    } else {
                      if (!element1.id) {
                        element1.id = null;
                      }
                    }
                  }
                }
              }
            }
            localStorage.setItem("AR", JSON.stringify(imageUpdateObj));
          }
        })
        .catch((error) => {
          toast.error(error.error, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        });
    } else {
      await uploadProductImage(formData)
        .then((response) => {
          if (response.data.success === true) {
            // getProductsByID();
            toast.success("Variant Image has been Uploaded!", {
              position: "top-right",
              autoClose: 2000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: false,
              progress: 0,
              toastId: "my_toast",
            });
          }

          setHideStatus(true);
          setImage(response.data.data);
          const values = [...variants];
          const apiVal = response.data.data;
          const element = [];
          for (const key in apiVal) {
            if (Object.hasOwnProperty.call(apiVal, key)) {
              element.push({ image: apiVal[key].imageUrl, key: imageKey });
            }
          }
          values[i].productImages = element;
          setVariants(values);
          if (variants) {
            let imageUpdateObj = response.data.data;
            let apiImageObj = variants.productImages;
            for (const key in imageUpdateObj) {
              if (Object.hasOwnProperty.call(imageUpdateObj, key)) {
                const element1 = imageUpdateObj[key];

                for (const key in apiImageObj) {
                  if (Object.hasOwnProperty.call(apiImageObj, key)) {
                    const element2 = apiImageObj[key];
                    if (element1.imageUrl === element2.image) {
                      element1.id = element2.id;
                    } else {
                      if (!element1.id) {
                        element1.id = null;
                      }
                    }
                  }
                }
              }
            }
            localStorage.setItem("AR", JSON.stringify(imageUpdateObj));
          }
        })
        .catch((error) => {
          toast.error(error.error, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        });
    }

    // });
  };

  const deleteImage = async (name, sku, variants) => {
    setClick(true);
    const params = {
      key: sku,
      filename: name,
    };
    await deleteProductImage(params)
      .then((response) => {
        toast.success("Image deleted successfully", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        // console.log(imag);
        setDeleted(response.data.data);
        localStorage.setItem(
          `finalArrVar-${sku}`,
          JSON.stringify(response.data.data)
        );
      })
      .catch((error) => {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
    for (let index in variants) {
      if (variants.hasOwnProperty(index)) {
        // console.log('items',items);
        let filterImage = variants[index]?.productImages.filter((item) => {
          if (item.image != name) {
            return item;
          }
        });
        variants[index].productImages = filterImage;
        setChange(filterImage);
      }
    }
  };

  useEffect(() => {
    setVariants(variants);
    // localStorage.setItem("finalArr", JSON.stringify([]));
  }, [change]);

  return (
    <div className="card shadow my-3">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Variant</h2>
      </div>
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          <div>
            {variants &&
              variants?.map((data, index) => (
                <div className="container">
                  <div className="row py-5">
                    <div className="col-md-5">
                      <label className="custom-file-upload">
                        <i className="fa fa-camera"></i>
                        <input
                          type="file"
                          id="file-upload"
                          // className="file-upload-2"
                          // onClick={console.log("hello")}
                          onChange={(e) =>
                            onButton(e, index, data.sku, data.productId)
                          }
                        />
                      </label>

                      <div className="uploadPicturesWrapper">
                        <div
                          // key={index}
                          style={{
                            position: "relative",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            flexWrap: "wrap",
                            width: "100%",
                            marginTop: 15,
                          }}
                        >
                          {
                            data?.productImages.length > 0 &&
                              // hideStatus === false
                              data?.productImages?.map((item, index) => (
                                <div
                                  key={index}
                                  className="uploadPictureContainer mt-3"
                                >
                                  <input
                                    type="button"
                                    key={index}
                                    name={item?.image}
                                    className="deleteImage"
                                    value="X"
                                    onClick={(e) =>
                                      deleteImage(
                                        e.target.name,
                                        data.sku,
                                        variants
                                      )
                                    }
                                  />
                                  {item?.image ? (
                                    <img
                                      src={imageUrl + item?.image}
                                      className="uploadPicture"
                                      alt="preview"
                                    />
                                  ) : (
                                    ""
                                  )}
                                </div>
                              ))
                            //   : imag.map((apiData, id) => (
                            //       <div
                            //         key={id}
                            //         className="uploadPictureContainer mt-3"
                            //       >
                            //         <input
                            //           type="button"
                            //           key={id}
                            //           className="deleteImage"
                            //           name={apiData?.imageUrl}
                            //           onClick={(e) =>
                            //             deleteImage(e.target.name, data.sku)
                            //           }
                            //           value="X"
                            //         />
                            //         <img
                            //           src={imageUrl + apiData?.imageUrl}
                            //           className="uploadPicture"
                            //           alt="preview"
                            //         />
                            //       </div>
                            // ))
                          }
                        </div>
                      </div>
                    </div>

                    <div className="col-md-7">
                      {isEmpty(data?.attributes) ? (
                        <div className="row">
                          {attributeData.map((data1, subindex) => (
                            <div className="col-md-6">
                              <div className="form-field-container dropdown null">
                                <div className="field-wrapper flex flex-grow items-baseline">
                                  <select
                                    className="form-field"
                                    id={data1?.id}
                                    name={data1?.name}
                                    onChange={(e) => {
                                      attributeChange(
                                        index,
                                        subindex,
                                        e.target.value
                                      );
                                    }}
                                  >
                                    {data1?.AttributeOptions?.map(
                                      (option, key) => (
                                        <option
                                          key={key}
                                          id={option?.id}
                                          value={option?.name}
                                          pid={option?.id}
                                        >
                                          {option?.name}
                                        </option>
                                      )
                                    )}
                                  </select>
                                  <div className="field-border"></div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <>
                          {data?.attributes.length == 2 ? (
                            <div className="row">
                              {data?.attributes.map((data1, subindex) => (
                                <div className="col-md-6">
                                  <div className="form-field-container dropdown null">
                                    <div className="field-wrapper flex flex-grow items-baseline">
                                      <select
                                        className="form-field"
                                        id={data1?.id}
                                        name={data1?.name}
                                        defaultValue={data1.optionText}
                                        onChange={(e) => {
                                          attributeChange(
                                            index,
                                            subindex,
                                            e.target.value
                                          );
                                        }}
                                      >
                                        {attributeData.map((data2) =>
                                          data2?.AttributeOptions?.map(
                                            (option, key) =>
                                              data2.id ==
                                                data1?.attributeId && (
                                                <option
                                                  key={key}
                                                  id={option?.id}
                                                  value={option?.name}
                                                  pid={option?.id}
                                                >
                                                  {option?.name}
                                                </option>
                                              )
                                          )
                                        )}
                                      </select>
                                      <div className="field-border"></div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="row">
                              {data?.attributes.map((data1, subindex) => (
                                <div className="col-md-12">
                                  <div className="form-field-container dropdown null">
                                    <div className="field-wrapper flex flex-grow items-baseline">
                                      {attributeData.map((data1, subindex) => (
                                        <select
                                          className="form-field"
                                          id={data1?.id}
                                          name={data1?.name}
                                          onChange={(e) => {
                                            attributeChange(
                                              index,
                                              subindex,
                                              e.target.value
                                            );
                                          }}
                                        >
                                          {data1?.AttributeOptions?.map(
                                            (option, key) => (
                                              <option
                                                key={key}
                                                id={option?.id}
                                                value={option?.name}
                                                pid={option?.id}
                                              >
                                                {option?.name}
                                              </option>
                                            )
                                          )}
                                        </select>
                                      ))}
                                      <div className="field-border"></div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </>
                      )}

                      <hr />

                      <div className="row">
                        <div className="col-md-4">
                          <div className="form-field-container null">
                            <label htmlFor="sku">SKU</label>
                            <div className="field-wrapper flex flex-grow">
                              <input
                                type="text"
                                name="sku"
                                placeholder="SKU"
                                defaultValue={data.sku}
                                onChange={(e) => {
                                  handleOnChange(
                                    index,
                                    false,
                                    "sku",
                                    e.target.value
                                  );
                                }}
                              />
                              <div className="field-border"></div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="form-field-container null">
                            <label htmlFor="price">Price</label>
                            <div className="field-wrapper flex flex-grow">
                              <input
                                type="text"
                                name="price"
                                placeholder="Price"
                                defaultValue={data.price}
                                onChange={(e) => {
                                  handleOnChange(
                                    index,
                                    false,
                                    "price",
                                    e.target.value
                                  );
                                }}
                              />
                              <div className="field-border"></div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="form-field-container null">
                            <label htmlFor="quantity">Quantity</label>
                            <div className="field-wrapper flex flex-grow">
                              <input
                                type="text"
                                name="qty"
                                placeholder="Quantity"
                                defaultValue={data.qty}
                                onChange={(e) => {
                                  handleOnChange(
                                    index,
                                    false,
                                    "qty",
                                    e.target.value
                                  );
                                }}
                              />
                              <div className="field-border"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-field-container null">
                          <label htmlFor="GST">GST</label>
                          <div className="field-wrapper flex flex-grow">
                            <select
                              className="form-field"
                              id="gst"
                              name="gst"
                              defaultValue={data?.gst}
                              onChange={(e) => {
                                handleOnChange(
                                  index,
                                  false,
                                  "gst",
                                  e.target.value
                                );
                              }}
                            >
                              <option selected={true} disabled>
                                Please Select GST
                              </option>
                              {gst?.map((gstData, key) => {
                                return (
                                  <option
                                    // value={gstData?.gst}
                                    key={key}
                                    selected={data?.gst}
                                    defaultValue={gstData?.gst}
                                  >
                                    {gstData?.gst}
                                  </option>
                                );
                              })}
                            </select>
                          </div>
                        </div>
                      </div>
                      {/* DIV FOR DIMENSIONS */}
                      {/* {console.log("dimensions: ",  item.dimensions.split("x")))} */}

                      <div className="row">
                        {/* {console.log("data", data)} */}
                        <div className="col-md-12">
                          <>
                            <div className="form-field-container null">
                              <label>Dimensions</label>
                              <div className="input-group">
                                <input
                                  type="text"
                                  aria-label="Length"
                                  className="form-control"
                                  placeholder="Length"
                                  name="length"
                                  defaultValue={data?.ProductAdditionalInfos[0]?.dimensions
                                    ?.split("x")[0]
                                    ?.trim()}
                                  // defaultValue={
                                  //   item.dimensions
                                  //     ? item.dimensions.split("x")[0].trim()
                                  //     : ""
                                  // }
                                  onChange={(e) => {
                                    handleOnChange(
                                      index,
                                      // subIndex,
                                      "length",
                                      e.target.value
                                    );
                                  }}
                                />
                                <div className="input-group-prepend">
                                  <span
                                    className="input-group-text"
                                    style={{ borderRadius: "0!important" }}
                                  >
                                    x
                                  </span>
                                </div>
                                <input
                                  type="text"
                                  aria-label="Breadth"
                                  className="form-control"
                                  placeholder="Breadth"
                                  name="breadth"
                                  // defaultValue={
                                  //   item.dimensions
                                  //     ? item.dimensions.split("x")[1].trim()
                                  //     : ""
                                  // }
                                  defaultValue={data?.ProductAdditionalInfos[0]?.dimensions
                                    ?.split("x")[1]
                                    ?.trim()}
                                  onChange={(e) => {
                                    handleOnChange(
                                      index,
                                      // subIndex,
                                      "breadth",
                                      e.target.value
                                    );
                                  }}
                                />
                                <div className="input-group-prepend">
                                  <span
                                    className="input-group-text"
                                    style={{ borderRadius: "0!important" }}
                                  >
                                    x
                                  </span>
                                </div>
                                <input
                                  type="text"
                                  aria-label="Height"
                                  className="form-control"
                                  placeholder="Height"
                                  name="height"
                                  // defaultValue={
                                  //   item.dimensions
                                  //     ? item.dimensions.split("x")[2].trim()
                                  //     : ""
                                  // }
                                  defaultValue={data?.ProductAdditionalInfos[0]?.dimensions
                                    ?.split("x")[2]
                                    ?.trim()}
                                  onChange={(e) => {
                                    handleOnChange(
                                      index,
                                      // subIndex,
                                      "height",
                                      e.target.value
                                    );
                                  }}
                                />
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-6">
                                <div className="form-field-container null">
                                  <label htmlFor="weight">Material</label>
                                  <div className="field-wrapper flex flex-grow">
                                    <input
                                      type="text"
                                      placeholder="Material"
                                      name="materials"
                                      defaultValue={
                                        data?.ProductAdditionalInfos[0]
                                          ?.materials
                                      }
                                      onChange={(e) => {
                                        handleOnChange(
                                          index,
                                          // subIndex,
                                          "materials",
                                          e.target.value
                                        );
                                      }}
                                    />
                                    <div className="field-border"></div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="row">
                              <div className="col-md-9">
                                <div className="form-field-container null">
                                  <label htmlFor="otherInfo">
                                    Additional Information
                                  </label>
                                  <div className="field-wrapper flex flex-grow">
                                    <textarea
                                      placeholder=""
                                      name="otherInfo"
                                      // defaultValue={item.otherInfo}
                                      defaultValue={
                                        data?.ProductAdditionalInfos[0]
                                          ?.otherInfo
                                      }
                                      onChange={(e) => {
                                        handleOnChange(
                                          index,
                                          // subIndex,
                                          "otherInfo",
                                          e.target.value
                                        );
                                      }}
                                    />
                                    <div className="field-border"></div>
                                  </div>
                                </div>
                              </div>

                              <div className="col-md-3">
                                <div className="form-field-container null">
                                  <label htmlFor="weight">Weight</label>
                                  <div className="field-wrapper flex flex-grow">
                                    <input
                                      type="text"
                                      placeholder="weight"
                                      name="weight"
                                      // defaultValue={item.weight}
                                      defaultValue={
                                        data?.ProductAdditionalInfos[0]?.weight
                                      }
                                      onChange={(e) => {
                                        handleOnChange(
                                          index,
                                          // subIndex,
                                          "weight",
                                          e.target.value
                                        );
                                      }}
                                    />
                                    <div className="field-border"></div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <button
                              className="btn btn-remove"
                              onClick={() => handleRemoveClick(index)}
                            >
                              {" "}
                              Remove{" "}
                            </button>
                          </>
                          {/* ))} */}
                        </div>
                      </div>
                      {/* DIV FOR DIMENSIONS END*/}
                    </div>
                  </div>
                </div>
              ))}
            {createVariant && (
              <>
                <div className="row">
                  <div className="col-md-6">
                    <Link
                      to="#"
                      className="mt-1 btn text-primary"
                      onClick={() => {
                        addNewVariant();
                      }}
                    >
                      Add a new variant{" "}
                    </Link>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Variant;
