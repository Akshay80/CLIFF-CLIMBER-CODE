import React, { useState, useEffect } from "react";
import {
  uploadProductImage,
  deleteProductImage,
  uploadProductImageUpdate
} from "../../../../../Services/productService";
import { imageUrl } from "../../../../../config/settings/env";
import "../../../../../Styles/_custom.scss";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";

const Media = ({ productImages, sku, setValue, getProductsByID,productId }) => {
  const [imag, setImage] = useState([]);
  const [hideStatus, setHideStatus] = useState(false);
  const [deleted, setDeleted] = useState([]);
  const [click, setClick] = useState(false);
  const [testArr, setArr] = useState([]);

  const onButton = async (files) => {
    const arr = [];
    arr.push({ id: null, image: files });
    localStorage.setItem("a", JSON.stringify(arr));
    var formData = new FormData();
    formData.append("key", sku);
    formData.append("product", files);
     formData.append("productId", productId);
    // API call for Image Upload

    await uploadProductImageUpdate(formData)
      .then((response) => {
        if (response.data.success === true) {
          getProductsByID();
          toast.success("Product Image has been Uploaded!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
        setHideStatus(true);
        setImage(response.data.data);
        console.log(response.data.data);
        // if (productImages) {
        //   let imageUpdateObj = response.data.data;
        //   let apiImageObj = productImages;
        //   for (const key in imageUpdateObj) {
        //     if (Object.hasOwnProperty.call(imageUpdateObj, key)) {
        //       const element1 = imageUpdateObj[key];

        //       for (const key in apiImageObj) {
        //         if (Object.hasOwnProperty.call(apiImageObj, key)) {
        //           const element2 = apiImageObj[key];
        //           if (element1.imageUrl != element2.image) {
        //             // element1.id = element2.id;
        //             element1.id = null;
        //           } 
        //           // else {
        //           //   if (!element1.id) {
        //           //   }
        //           // }
        //         }
        //       }
        //     }
        //   }
        //   localStorage.setItem("a", JSON.stringify([]));
        // }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // API CALL FOR DELETING IMAGE
  async function deleteImage(name) {
    setClick(true);
    const params = {
      key: sku,
      filename: name,
    };

    await deleteProductImage(params)
      .then((response) => {
        toast.success("Product image deleted!", {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        localStorage.setItem("finalArr", JSON.stringify(response.data.data))
        setTimeout(() => {
          getProductsByID();
        }, 2000)
        setDeleted(response.data.data);
        
      })

      .catch((error) => {
        console.log(error);
        toast.error(error.error, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  }

  useEffect(() => {
    // setArr(localStorage.getItem("a"));
    localStorage.setItem("finalArr", JSON.stringify([]))
  },[])

  return (
    <>
      <div className="card shadow my-3">
        <div className="flex justify-between card-header">
          <h2 className="card-title">Media</h2>
        </div>
        <div className="card-section  box-border">
          <div className="card-session-content pt-lg">
            <label htmlFor="file-upload" className="custom-file-upload">
              <i className="fa fa-camera"></i>
            </label>
            <input
              id="file-upload"
              // name="media"
              type="file"
              onChange={(e) => onButton(e.target.files[0])}
            />

            <div className="uploadPicturesWrapper">
              <div
                style={{
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexWrap: "wrap",
                  width: "100%",
                  marginTop: 15,
                }}
              >

                {hideStatus === false
                  ? productImages.map((item, index) => (
                      <div key={index} className="uploadPictureContainer mt-3">
                        <input
                          type="button"
                          key={index}
                          name={item?.image}
                          className="deleteImage"
                          value="X"
                          onClick={(e) => deleteImage(e.target.name)}
                        />

                        <img
                          src={imageUrl + item?.image}
                          className="uploadPicture"
                          alt="preview"
                        />
                      </div>
                    ))
                  : imag.map((apiData, id) => (
                      <div key={id} className="uploadPictureContainer mt-3">
                        <input
                          type="button"
                          key={id}
                          className="deleteImage"
                          name={apiData?.imageUrl}
                          onClick={(e) => deleteImage(e.target.name)}
                          value="X"
                        />
                        <img
                          src={imageUrl + apiData?.imageUrl}
                          className="uploadPicture"
                          alt="preview"
                        />
                      </div>
                    ))}

                {/* </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </>
  );
};
export default Media;
