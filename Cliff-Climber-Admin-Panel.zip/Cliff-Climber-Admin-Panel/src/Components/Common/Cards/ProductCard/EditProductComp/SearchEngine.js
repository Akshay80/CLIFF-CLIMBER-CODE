import React, {useEffect} from "react";

const SearchEngine = ({ register, formStateError, urlKey, metaDescription, metaTitle, metaKeywords, setValue }) => {
  useEffect(() => {
    settingValues();
  }, [settingValues]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  function settingValues() {
    setValue("urlKey", urlKey);
    setValue("metaTitle", metaTitle);
    setValue("metaKeyword", metaKeywords);
    setValue("metaDescription", metaDescription);
  }
  return (
    <div className="card shadow my-3">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Search engine optimize</h2>
      </div>
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          <div className="">
            <div className="form-field-container null">
              <label htmlFor="url_key">Url key</label>
              <div className="field-wrapper flex flex-grow">
                <input
                  type="text"
                  defaultValue={urlKey}
                  {...register("urlKey")}
                />
                <div className="field-border"></div>
              </div>
              {formStateError.urlKey && (
                <p className="errors">{formStateError.urlKey.message}</p>
              )}
            </div>
            <div className="form-field-container null">
              <label htmlFor="meta_title">Meta title</label>
              <div className="field-wrapper flex flex-grow">
                <input
                  type="text"
                  name="meta_title"
                  defaultValue={metaTitle}
                  {...register("metaTitle")}
                />
                <div className="field-border"></div>
              </div>
              {formStateError.metaTitle && (
                <p className="errors">{formStateError.metaTitle.message}</p>
              )}
            </div>
            <div className="form-field-container null">
              <label htmlFor="meta_keywords">Meta keywords</label>
              <div className="field-wrapper flex flex-grow">
                <input
                  type="text"
                  name="meta_keywords"
                  defaultValue={metaKeywords}
                  {...register("metaKeyword")}
                />
                <div className="field-border"></div>
              </div>
              {formStateError.metaKeyword && (
                <p className="errors">{formStateError.metaKeyword.message}</p>
              )}
            </div>
            <div className="form-field-container null">
              <label htmlFor="meta_description">Meta description</label>
              <div className="field-wrapper flex flex-grow">
                <textarea
                  type="text"
                  className="form-field"
                  id="meta_description"
                  defaultValue={metaDescription}
                  {...register("metaDescription")}
                ></textarea>
                <div className="field-border"></div>
              </div>
              {formStateError.metaDescription && (
                <p className="errors">
                  {formStateError.metaDescription.message}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SearchEngine;
