import React, { useEffect } from "react";

import "./Product.css";
import General from "./EditProductComp/Genral";
import Media from "./EditProductComp/Media";
import Variant from "./EditProductComp/Variant";
import SearchEngine from "./EditProductComp/SearchEngine";
import ProductStatus from "./EditProductComp/ProductStatus";
import Inventory from "./EditProductComp/Inventory";
import SelectCategories from "./EditProductComp/SelectCategories";
import Brands from "./EditProductComp/Brands";
import GST from "./EditProductComp/GST";
import EditAttribute from "./EditProductComp/EditAttribute";
import { useForm } from "react-hook-form";
import { Link, useNavigate, useParams } from "react-router-dom";
import Tags from "./EditProductComp/Tags";
import { viewProductsbyId } from "../../../../Services/productService";
import { ToastContainer, toast, Flip } from "react-toastify";
import { useState } from "react";
import { editProduct } from "../../../../Services/productService";
import { slice } from "lodash";

const EditProduct = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [productDesc, setProductDescription] = useState([]);
  const [productImages, setProductImages] = useState([]);
  const [additionalInfo, setAdditionInfo] = useState([]);
  const [selectValue, setSelectValue] = useState([]);
  const [selectSubvalue, setSubValue] = useState([]);
  const [attributes, setProductAttribute] = useState([]);
  const [tags, setTags] = useState([]);
  const [variants, setVariants] = useState([]);
  const [gst, setGST] = useState("");
  const [varSKU, setvarSKU] = useState("");
  const [productId, setProductId] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm();

  useEffect(() => {
    getProductsByID();
  }, []);

  const productSubmit = async (e) => {
    console.log( typeof e.status);
    // const image = JSON.parse(localStorage.getItem("a"));
    // const imageArr = JSON.parse(localStorage.getItem("finalArray"));
    // console.log("imageArr : ", imageArr);
   
    // console.log("variants: ", variants);
    let params = {
      simple: {
        productInfo: {
          productId: id,
          productType: e.product_type,
          sku: e.productSku,
          price: e.productPrice,
          weight: e.productWeight,
          qty: e.quantity,
          brandId: e.brand,
          manageStock: null,
          stockAvailability: true,
          status: e.status === "true" ? true : false,
          visibility: e.visibility === "true" ? true : false,
          gstId: e.gst,
        },
        ProductAdditionalInfos: {
          weight: e.productWeight,
          dimensions: `${e.length}x${e.breadth}x${e.height}`,
          materials: e.materials,
          otherInfo: e.otherInfo,
        },
        descriptions: {
          name: e.productName,
          description: e.productLongDescription,
          shortDescription: e.productShortDescription,
          urlKey: e.urlKey,
          metaTitle: e.metaTitle,
          metaDescription: e.metaDescription,
          metaKeywords: e.metaKeyword,
        },
        categories: {
          categoryId: e.category,
          subCategoryId: e.subCategory,
        },
        attributes: JSON.parse(localStorage.getItem("attributeArr")),
        tags: e.tags,
        // productImages: imageArr,
        productImages: [],
        // productImages: e.productImages,
        // productImages: image,
      },
      variations: variants?.length === 0 || variants === undefined? [] : variants,
    };
    for (let index in params?.variations) {
      if (params?.variations.hasOwnProperty(index)) {
        if(params?.variations[index]?.productId == null){
          let filterImage = params?.variations[index]?.productImages.filter((item) => {
            item.image = item.image.split("/")[3];
             return item;
          });
          params.variations[index].productImages = filterImage;
        } else {
          params.variations[index].productImages=[];
        }
      }
    }
    //  console.log("params", params);

    await editProduct(params)
      .then((response) => {
        if (response.data.success === true) {
          toast.success(response.data.data, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
          localStorage.removeItem("a");
          localStorage.removeItem("finalArray");
          setTimeout(() => {
            navigate(-1);
          }, 3000);
        } else {
          toast.error(response.data.error, {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
      })
      .catch(function (error) {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3500,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  const getProductsByID = async () => {
    await viewProductsbyId(id)
      .then((response) => {
        console.log(response.data.data.productInfo.id);
        setTags(response.data.data.productInfo.ProductTags);
        setData(response.data.data.productInfo);
        setProductDescription(
          response.data.data.productInfo.ProductDescriptions[0]
        );
        setProductId(response.data.data.productInfo.id);
        setProductImages(response.data.data.productInfo.ProductImages);
        setSelectValue(response.data.data.productInfo.ProductCategories[0]);
        setSubValue(response.data.data.productInfo.ProductSubCategories[0]);
        setProductAttribute(response.data.data.productInfo.attributes);
        setVariants(response.data.data.variations);
        setvarSKU(response?.data?.data?.variations?.map((items) => items?.sku));
        // setProductAttribute(response.data.data.productInfo.ProductAttributeValueIndices);
        setAdditionInfo(response.data.data.productInfo.ProductAdditionalInfos);
        setGST(response.data.data.productInfo.gst);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="test">
      <form id="product-edit-form" onSubmit={handleSubmit(productSubmit)}>
        <div className="page-heading d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center">
            <Link to={"/products"} className="btn btn-secondary btn-sm">
              Back To All Product
            </Link>
          </div>
        </div>
        <div className="row">
          <div className="col-md-8">
            <General
              register={register}
              formStateError={errors}
              name={productDesc.name}
              sku={data.sku}
              price={data.price}
              currency={data.currencySymbol}
              weight={data.weight}
              shortDescription={productDesc.shortDescription}
              longDescription={productDesc.description}
              setValue={setValue}
              additionalInfo={additionalInfo}
            />
            <div className="row">
              <div className="col-md-6">
                <SelectCategories
                  register={register}
                  selectValue={selectValue}
                  selectSubvalue={selectSubvalue}
                  setValue={setValue}
                />
                <Brands
                  register={register}
                  brandId={data.brandId}
                  setValue={setValue}
                />
              </div>
              <div className="col-md-6">
                <EditAttribute
                  register={register}
                  attributes={attributes}
                  setValue={setValue}
                />
                <Tags register={register} tags={tags} setValue={setValue} />
              </div>
            </div>

            <Media
              productImages={productImages}
              sku={data.sku}
              setValue={setValue}
              getProductsByID={getProductsByID}
              productId={productId}
            />
          </div>
          <div className="col-md-4">
            <ProductStatus
              register={register}
              setValue={setValue}
              status={Boolean(data.status)}
              visibility={data.visibility}
              featured={data.isFeatured}
              productType={data.productType}
            />
            <Inventory
              register={register}
              formStateError={errors}
              stockAvailability={Boolean(data.stockAvailability)}
              qty={data.qty}
              setValue={setValue}
            />
            <GST
              register={register}
              gstId={data?.gstId}
              setValue={setValue}
              gst={gst}
            />
            {/* <AddAttribute register={register} /> */}
          </div>
        </div>
        <Variant
          register={register}
          variants={variants}
          sku={varSKU}
          setVariants={setVariants}
        />
        <SearchEngine
          register={register}
          formStateError={errors}
          urlKey={productDesc.urlKey}
          metaTitle={productDesc.metaTitle}
          metaDescription={productDesc.metaDescription}
          metaKeywords={productDesc.metaKeywords}
          setValue={setValue}
        />
        <div className="form-submit-button flex border-t border-divider my-5 justify-between">
          <button type="button" className="btn btn-success mx-3">
            <span>Cancel</span>
          </button>
          <button type="submit" className="btn btn-success mx-3">
            <span>Save</span>
          </button>
        </div>
      </form>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </div>
  );
};

export default EditProduct;
