import { data } from "jquery";
import React from "react";
import { useState } from "react";
import { createContext } from "react";
import { useEffect } from "react";
import Select from "react-select";
import { getAllBrandFun } from "../../../../../Services/brandService";
import { getAllTagFun } from "../../../../../Services/tagServices";
import AddProduct from "../AddProduct";

const Tags = ({ register }) => {
  const [tag, setTag] = useState([]);
  const [arr, setArr] = useState([]);
  const [tagValues, setTagValues] = useState([]);
  const [changeStatus, setChange] = useState(false);
  const [initialState, setInitialState] = useState(0);
  //   const TagsData = createContext(tagValues);

  useEffect(() => {
    tagdata();
    localStorage.removeItem("tags");
  }, []);

  //   tag api call
  const tagdata = () => {
    getAllTagFun()
      .then((res) => {
        setTag(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const Options = tag.map(({ id, name }) => ({ value: id, label: name }));

  return (
    <div className="card shadow my-3">
      <div className="card-section  box-border">
        <div className="flex pb-1 justify-between card-section-header mb-1">
          <h3 className="card-session-title">Tags</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <Select
                  isMulti
                  options={Options}
                  required={true}
                  className="basic-multi-select tags"
                  classNamePrefix="select"
                  // {...register("tags", {required:"Tags!"})}
                  onChange={(e) => {
                    localStorage.setItem(
                      "tags",
                      JSON.stringify(e.map((VAL) => ({ tagId: VAL.value })))
                    );
                    console.log(e.length)
                    // setChange(true);
                    setInitialState(e.length)
                  }}
                />
              </div>
              {/* {initialState} */}
              {/* {changeStatus ? "error will not be shown!": "error here!"} */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Tags;
