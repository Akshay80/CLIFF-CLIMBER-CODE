import React from "react";

const ProductStatus = ({ register }) => {
  return (
    <div className="card shadow my-3 subdued">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Product status</h2>
      </div>
      <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="status">Status</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="status0" className="flex">
                  <input
                    type="radio"
                    id="status0"
                    aria-label="radio 1"
                    label="Design"
                    defaultChecked
                    defaultValue={false}
                    {...register("status")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">Disabled</span>
                </label>
              </div>
              <div>
                <label htmlFor="status1" className="flex">
                  <input
                    aria-label="radio 1"
                    type="radio"
                    id="status1"
                    defaultValue={true}
                    {...register("status")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Enabled</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="card-section   box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="visibility">Visibility</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="visibility0" className="flex">
                  <input
                    type="radio"
                    id="visibility0"
                    defaultValue={false}
                    defaultChecked
                    {...register("visibility")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">Not visible</span>
                </label>
              </div>
              <div>
                <label htmlFor="visibility1" className="flex">
                  <input
                    type="radio"
                    id="visibility1"
                    defaultValue={true}
                    {...register("visibility")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Visible</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="featured">Featured product</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="featured" className="flex">
                  <input
                    type="radio"
                    id="featured"
                    defaultValue={false}
                    defaultChecked
                    {...register("featured")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">Disabled</span>
                </label>
              </div>
              <div>
                <label htmlFor="featured" className="flex">
                  <input
                    type="radio"
                    id="visibility"
                    defaultValue={true}
                    {...register("featured")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Enabled</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="card-section  box-border">
        <div className="form-field-container dropdown null">
          <label htmlFor="status">Product Type</label>
          <div className="field-wrapper flex flex-grow items-baseline">
            <select className="form-field" {...register("product_type")}>
              <option value="Other Order">Other Order</option>
              <option value="Combat Uniform">Combat Uniform</option>
              <option value="Combat Jackets">Combat Jackets</option>
            </select>
            <div className="field-border"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProductStatus;
