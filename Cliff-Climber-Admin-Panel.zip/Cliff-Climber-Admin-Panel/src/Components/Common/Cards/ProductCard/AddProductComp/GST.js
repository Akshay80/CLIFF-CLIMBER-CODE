import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { viewGST } from "../../../../../Services/gstService";
import AddProduct from "../AddProduct";

const GST = ({ register, formStateError }) => {
  const [gst, setGST] = useState([]);

  //   const TagsData = createContext(tagValues);

  useEffect(() => {
    gstData();
  }, []);

  //   GST api call
  const gstData = async () => {
    await viewGST()
      .then((res) => {
        setGST(res?.data?.data);
        console.log(res?.data?.data);
      })
      .catch(function (error) {});
  };

  return (
    <div className="card shadow my-3">
      <div className="card-section  box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">GST</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  name="gst"
                  id="group_id"
                  {...register("gst", {
                    required: "GST is required."
                  })}
                >
                  <option selected="true" disabled="disabled" value="">Please Select GST</option>
                  {gst?.map((gstData, key) => {
                    return (
                      <option value={gstData?.id} key={key}>
                        {gstData?.gst}
                      </option>
                    );
                  })}
                </select>
                <div className="field-border"></div>
               
              </div>
              {formStateError.gst && (
                <p className="errors" style={{color: "red"}}>{formStateError.gst.message}</p>
              )}
              
            </div>
            
          </div>
        </div>

      </div>
    </div>
  );
};
export default GST;
