import React from "react";

const Inventory = ({ register, formStateError }) => {
  return (
    <div className="card shadow my-3 subdued">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Inventory</h2>
      </div>
      {/* <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="manage_stock">Manage stock?</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="manage_stock0" className="flex">
                  <input
                    type="radio"
                    id="manage_stock0"
                    defaultValue="0"
                    defaultChecked
                    {...register("manageStock")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">No</span>
                </label>
              </div>
              <div>
                <label htmlFor="manage_stock1" className="flex">
                  <input
                    type="radio"
                    id="manage_stock1"
                    defaultValue="1"
                    {...register("manageStock")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Yes</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      {/* <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="stock_availability">Stock availability</label>
            <div className="field-wrapper radio-field">
              <div>
                <label htmlFor="stock_availability0" className="flex">
                  <input
                    type="radio"
                    id="stock_availability0"
                    defaultValue="0"
                    defaultChecked
                    {...register("stockAvailability")}
                  />
                  <span className="radio-checked">
                    <span></span>
                  </span>
                  <span className="pl-1">No</span>
                </label>
              </div>
              <div>
                <label htmlFor="stock_availability1" className="flex">
                  <input
                    type="radio"
                    id="stock_availability1"
                    defaultValue="1"
                    {...register("stockAvailability")}
                  />
                  <span className="radio-unchecked"></span>
                  <span className="pl-1">Yes</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          <div className="form-field-container null">
            <label htmlFor="qty">Quantity</label>
            <div className="field-wrapper flex flex-grow">
              <input
                type="text"
                placeholder="Quantity"
                defaultValue=""
                {...register("quantity", {
                  required: "Quantity is required.",
                  pattern: {
                    value: /^(0|[1-9]\d*)(\.\d+)?$/,
                    message: "Only numbers are required",
                  },
                })}
              />
              <div className="field-border"></div>
            </div>
            {formStateError.quantity && (
                <p className="errors">{formStateError.quantity.message}</p>
              )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default Inventory;
