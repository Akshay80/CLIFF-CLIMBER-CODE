import { data } from "jquery";
import React from "react";
import { useState } from "react";
import { createContext } from "react";
import { useEffect } from "react";
import Select from "react-select";
import { getAllBrandFun } from "../../../../../Services/brandService";
import { getAllTagFun } from "../../../../../Services/tagServices";
import AddProduct from "../AddProduct";

const Brands = ({ register, formStateError }) => {
  const [brand, setBrand] = useState([]);

 
  //   const TagsData = createContext(tagValues);

  useEffect(() => {
    brandData();
   
    
  }, []);

  //   brand api call
  const brandData = async () => {
    await getAllBrandFun()
      .then((res) => {
        setBrand(res?.data?.data);
      })
      .catch(function (error) {});
  };


 
  return (
    <div className="card shadow my-3">
      
      <div className="card-section  box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">Brands</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  id="group_id"
                  name="brand"
                  {...register("brand", {
                    required: "Brands is required."
                  })}
                >
                  <option selected={true} disabled="disabled" value="">Select Brands</option>
                  {brand?.map((brandData, key) => {
                    return (
                      <option value={brandData?.id} key={key}>
                        {brandData?.name}
                      </option>
                    );
                  })}
                </select>
                <div className="field-border"></div>
              </div>
              {formStateError.brand && (
                <p className="errors">{formStateError.brand.message}</p>
              )}
            </div>
          </div>
        </div>
      </div>

     
    </div>
  );
};
export default Brands;
