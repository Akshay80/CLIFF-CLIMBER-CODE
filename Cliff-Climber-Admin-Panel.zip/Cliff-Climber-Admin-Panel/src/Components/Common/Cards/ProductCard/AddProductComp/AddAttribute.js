import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { viewAttributeFun } from "../../../../../Services/attributeService";

const AddAttribute = ({ register }) => {
  const [id, setId] = useState();
  const [attributeData, setAttributeData] = useState([]);
  const [attributeArr, setAttributeArr] = useState([]);
  const [variationRelationId, setVariationRelId] = useState();
  useEffect(() => {
    viewAttributeData();
    localStorage.removeItem("attributeArr");
  }, []);

  const viewAttributeData = () => {
    viewAttributeFun()
      .then((res) => {
        setAttributeData(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const attributeChange = (e) => {
    setId(e.target.id);
    // console.log(e.target.name);
    if(e.target.name === "color")
    {
      setVariationRelId(e.target.selectedOptions[0].id);
    }
    const arr = {
      attributeId: e.target.id,
      attributeOptionId: e.target.selectedOptions[0].id,
      optionText: e.target.value,
      variationRelationId: e.target.name === "color" ? e.target.selectedOptions[0].id: variationRelationId
    };
    setAttributeArr((prev) => [...prev, arr]);
  };

  
  if (attributeArr.length > 0) {
    localStorage.setItem("attributeArr", JSON.stringify(attributeArr));
  }

  return (
    <div className="card shadow  my-3">
      <div className="card-section pb-1 box-border">
        <div className="flex justify-between pb-0 card-section-header mb-1">
          <h3 className="card-session-title">Attributes</h3>
        </div>
        <div className="card-session-content pt-lg">
          <table className="table table-auto">
            <tbody>
              {attributeData?.map((data) => (
                <tr key={data?.id}>
                  {/* {console.log(data)} */}
                  <td>{data?.name}</td>
                  <td>
                    <div className="form-field-container dropdown null">
                      <div className="field-wrapper flex flex-grow items-baseline">
                        <select
                          className="form-field"
                          id={data?.id}
                          name={data?.nameCode}
                          onChange={(e) => {
                            attributeChange(e);
                          }}
                        >
                          {/* <option defaultValue=""></option> */}
                          <option selected="true" disabled="disabled">Please select</option>
                          {data?.AttributeOptions?.map((option, key) => (
                            <option
                              key={key}
                              id={option?.id}
                              value={option?.name}
                              pid={option?.id}
                            >
                              {option?.name}
                            </option>
                          ))}
                        </select>


                        <div className="field-border"></div>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default AddAttribute;
