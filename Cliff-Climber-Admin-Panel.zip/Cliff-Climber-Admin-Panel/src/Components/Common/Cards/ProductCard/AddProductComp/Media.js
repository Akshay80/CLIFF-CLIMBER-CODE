/* eslint-disable jsx-a11y/img-redundant-alt */
import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import ImageUploader from "react-images-upload";
import {
  uploadProductImage,
  deleteProductImage,
} from "../../../../../Services/productService";
import { imageUrl } from "../../../../../config/settings/env";
import "../../../../../Styles/_custom.scss";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { useNavigate } from "react-router-dom";

const Media = () => {
  const [pictures, setPictures] = useState([]);
  const [click, setClick] = useState(false);
  const [deleted, setDeleted] = useState([]);
  const [imag, setImage] = useState([]);
  var data = JSON.parse(localStorage.getItem("productImages"));
  // const [count, setCount] = useState(0);
  const [proImg, setProImg] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.removeItem("productImages");
  }, []);

  // const onDrop = (pictureFiles, pictureDataURLs) => {
  //   setPictures(pictureFiles);
  //   setProImg((prev) => [...prev, pictureFiles]);
  //   // setClick(true);
  //   // setCount(count + 1);
  // };

  const onButton = async (files) => {
    // proImg?.map((items) => {
    setClick(false);
    var formData = new FormData();
    formData.append("key", JSON.parse(localStorage.getItem("productRadomNum")));
    formData.append("product", files);

    // API call for Image Upload

    await uploadProductImage(formData)
      .then((response) => {
        if (response.data.success === true) {
          toast.success("Product Image has been Uploaded!", {
            position: "top-right",
            autoClose: 2000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: false,
            progress: 0,
            toastId: "my_toast",
          });
        }
        setImage(response.data.data);
        // localStorage.setItem("items", JSON.stringify(response.data.data))
        const key = JSON.parse(localStorage.getItem("productRadomNum"));
        const images = response.data.data.map(({ imageUrl }) => ({
          key: key,
          image: imageUrl.replace(`uploads/product/product_${JSON.parse(localStorage.getItem("productRadomNum"))}/`,''),
        }));
    
        localStorage.setItem("items", JSON.stringify(images));
      })
      .catch((error) => {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
    // });
  };

  if (JSON.parse(localStorage.getItem("productRadomNum"))) {
    const key = JSON.parse(localStorage.getItem("productRadomNum"));
    const images = imag.map(({ name }) => ({
      key: key,
      image: localStorage.getItem("items"),
    }));
    localStorage.setItem("productImages", JSON.stringify(images));
  }

  if (JSON.parse(localStorage.getItem("productRadomNum"))) {
    const key = JSON.parse(localStorage.getItem("productRadomNum"));
    const images = pictures.map(({ name }) => ({
      key: key,
      image: imag,
    }));

    // localStorage.setItem("proImg", JSON.stringify(images));
  }

  if (JSON.parse(localStorage.getItem("productRadomNum"))) {
    const key = JSON.parse(localStorage.getItem("productRadomNum"));
    const images = pictures.map(({ name }) => ({ key: key, image: name }));
    localStorage.setItem("proImg2", JSON.stringify(images));
  }

  const deleteImage = async (name) => {
    setClick(true);

    // var focus = imag.filter((item) => item.imageUrl !== name);
    // console.log("focus", focus);
    // setDeleted(focus);
    const params = {
      key: JSON.parse(localStorage.getItem("productRadomNum")),
      filename: name,
    };

    await deleteProductImage(params)
      .then((response) => {
        toast.success(response.data.data, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        // console.log(imag);
        setDeleted(response.data.data);
        const key = JSON.parse(localStorage.getItem("productRadomNum"));
        const images = response.data.data.map(({ imageUrl }) => ({
          key: key,
          image: imageUrl.replace(`uploads/product/product_${JSON.parse(localStorage.getItem("productRadomNum"))}/`,''),
        }));
    
        localStorage.setItem("items", JSON.stringify(images));
        // response.data.data.map(({imageUrl}) => localStorage.setItem("items", 
        
        // JSON.stringify(response.data.data));
        //  setClick(false);
        // localStorage.removeItem("items", response.data.data.pop())
      })
      .catch((error) => {
        console.log(error);
        toast.error(error.error, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  return (
    <div className="card shadow my-3">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Media</h2>
      </div>
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          {/* <div className="product-image-manager">
            <div id="productMainImages" className="image-list" tabIndex="0">
              <div className="uploader grid-item">
                <div className="uploader-icon">
                  <label className="cursor" htmlFor="l8l64nb4">
                    <svg
                      style={{ width: "30px", height: "30px" }}
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M4 5a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.121-1.121A2 2 0 0011.172 3H8.828a2 2 0 00-1.414.586L6.293 4.707A1 1 0 015.586 5H4zm6 9a3 3 0 100-6 3 3 0 000 6z"
                        clipRule="evenodd"
                      ></path>
                    </svg>
                  </label>
                </div>
                <div className="invisible">
                  <input type="file" id="l8l64nb4" multiple="" />
                </div>
              </div>
            </div>
          </div> */}
          {/* <ImageUploader
            withIcon={true}
            // withPreview={img}
            buttonText={<i className="fa fa-camera"></i>}
            onChange={onDrop}
            imgExtension={[".jpg", ".jpeg", ".png", ".webp"]}
            fileSizeError=""
            maxFileSize={999999999999}
            singleImage={true}
          /> */}

          <label htmlFor="file-upload" className="custom-file-upload">
            <i className="fa fa-camera"></i>
          </label>
          <input
            id="file-upload"
            type="file"
            onChange={(e) => onButton(e.target.files[0])}
          />
          {/* <button
            onClick={onButton}
            width={100}
            type="button"
            height={100}
            className="buttonStyle"
          >
            <i className="fa fa-upload me-1"></i> Upload Image
          </button> */}

          <div className="uploadPicturesWrapper">
            <div
              style={{
                position: "relative",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexWrap: "wrap",
                width: "100%",
                marginTop: 15,
              }}
            >
              {/* {count > 0 ? (
                <div className="uploadPictureContainer">
                  <div className="deleteImage">X</div>
                  <img src={img} className="uploadPicture" alt="preview" />
                </div>
              ) : null} */}
              {/* <p>{count}</p> */}
              {click === true
                ? deleted.map((items, index) => (
                    <div className="uploadPictureContainer mt-3" key={index}>
                      {/* {console.log("deleted:",items)} */}
                      <input
                        key={index}
                        className="deleteImage"
                        type="button"
                        id={items?.imageUrl}
                        value="X"
                        onClick={(e) => deleteImage(e.target.id)}
                      >
                        {/*  */}
                      </input>

                      <img
                        src={imageUrl + items?.imageUrl}
                        className="uploadPicture"
                        alt="preview"
                      />
                    </div>
                  ))
                : imag.map((items, index) => (
                    <div className="uploadPictureContainer mt-3" key={index}>
                      <input
                        key={index}
                        className="deleteImage"
                        type="button"
                        id={items?.imageUrl}
                        value="X"
                        onClick={(e) => deleteImage(e.target.id)}
                      >
                        {/*  */}
                      </input>

                      <img
                        src={imageUrl + items?.imageUrl}
                        className="uploadPicture"
                        alt="preview"
                      />
                    </div>
                  ))}
            </div>
          </div>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </div>
  );
};
export default Media;
