import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { viewCategoryFun } from "../../../../../Services/categoryService";
import { viewSubCategoryFun } from "../../../../../Services/subCategoryService";

const SelectCategories = ({ register }) => {
  const [categoryData, setCategoryData] = useState([]);
  const [subCategoryData, setSubCategoryData] = useState([]);
  const [displaySubCategory, setDisplaySubCategory] = useState(false);
  var arr = [];

  const categories = async () => {
    await viewCategoryFun()
      .then((res) => {
        setCategoryData(res.data.data);
      })
      .catch(function (error) {});
  };

  useEffect(() => {
    categories();
  }, []);

  //   sub category
  const categoryChange = (e) => {
    if (e.target.value) {
      setDisplaySubCategory(true);
      viewSubCategoryFun()
        .then((res) => {
          res?.data?.data?.map((subCate) => {
            if (subCate?.Category?.id === e.target.value) {
              arr.push(subCate);
            }
          });
          setSubCategoryData(arr);
        })
        .catch(function (error) {});
    } else {
      console.log("something went wrong");
    }
  };

  return (
    <div className="card shadow my-3">
      <div className="card-section  box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h3 className="card-session-title">Categories</h3>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <div className="form-field-container dropdown null">
              <div className="field-wrapper flex flex-grow items-baseline">
                <select
                  className="form-field"
                  id="group_id"
                  {...register("category")}
                  onChange={(e) => categoryChange(e)}
                  defaultValue={true}
                >
                  <option selected={true} disabled="disabled">
                    Please Select Categories
                  </option>
                  {categoryData?.map((category, key) => (
                    <option value={category.id} key={key}>
                      {category.name}
                    </option>
                  ))}
                </select>
                <div className="field-border"></div>
              </div>
              {displaySubCategory && (
                <div className="field-wrapper flex flex-grow items-baseline mt-3 mb-4">
                  <select
                    className="form-field"
                    id="group_id"
                    {...register("subCategory")}
                  >
                    <option selected={true} defaultValue="" disabled="disabled">
                      Select Sub-Categories
                    </option>
                    {subCategoryData.length > 0 &&
                      subCategoryData?.map((data, key) => (
                        <option key={data?.id} value={data?.id}>
                          {data?.name}
                        </option>
                      ))}
                  </select>
                  <div className="field-border"></div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SelectCategories;
