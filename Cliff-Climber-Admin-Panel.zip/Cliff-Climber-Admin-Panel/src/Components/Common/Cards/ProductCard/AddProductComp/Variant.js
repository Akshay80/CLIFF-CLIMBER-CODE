/* eslint-disable react-hooks/exhaustive-deps */
import React, { useCallback, useEffect } from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import ImageUploader from "react-images-upload";
import { viewAttributeFun } from "../../../../../Services/attributeService";
import {
  uploadProductImage,
  deleteProductImage,
} from "../../../../../Services/productService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { imageUrl } from "../../../../../config/settings/env";
import "../../../../../Styles/_custom.scss";
import { data } from "jquery";
import { isEmpty } from "lodash";
import { viewGST } from "../../../../../Services/gstService";
const Variant = ({ setVariationArr }) => {
  const [variant, setVariant] = useState(false);
  const [createVariant, setCreateVariant] = useState(false);
  const [newVariant, setNewVariant] = useState(false);
  const [inputList, setInputList] = useState(false);
  const [attributeData, setAttributeData] = useState([]);
  const [attributeArr, setAttributeArr] = useState([]);
  const [variationRelationId, setVariationRelId] = useState();
  const [key, _] = useState(Math.floor(1000 + Math.random() * 9000));
  const [key1, __] = useState(Math.floor(1000 + Math.random() * 9000));
  const [click, setClick] = useState(false);
  const [imag, setImage] = useState([]);
  const [deleted, setDeleted] = useState([]);
  const [isNew, setIsNew] = useState(false);
  const [arrays, setArrays] = useState([]);
  const [count, setCount] = useState(0);
  const [imagess, setImagess] = useState([]);
  const [pictures, setPictures] = useState([]);
  const [gst, setGST] = useState([]);
  const [random, setRandom] = useState(Math.floor(1000 + Math.random() * 9000));

  const onDrop = (pictureFiles, pictureDataURLs) => {
    setPictures(pictureFiles);
    // setFinalImages(...finalImages, [images])
  };

  // if (JSON.parse(localStorage.getItem("productRadomNum"))) {
  //   const key = JSON.parse(localStorage.getItem("productRadomNum"));
  //   const images = pictures.map(({ name }) => ({ key: key, image: name }));
  //   localStorage.setItem("productImages", JSON.stringify(images));
  // }
  useEffect(() => {
    setVariationArr(inputList);
  }, [inputList]);

  useEffect(() => {
    gstData();
  }, []);

  //   GST api call
  const gstData = async () => {
    await viewGST()
      .then((res) => {
        setGST(res?.data?.data);
        // console.log(res?.data?.data);
      })
      .catch(function (error) {});
  };

  const viewAttributeData = () => {
    viewAttributeFun()
      .then((res) => {
        setAttributeData(res?.data?.data);
      })
      .catch(function (error) {});
  };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    const list = { ...inputList };
    list.variant.splice(index, 1);
    setInputList(list);
    // setVariationArr(list)
  };

  // handle click event of the Add button
  const handleAddClick = () => {
    const values = { ...inputList };
    setRandom(Math.floor(1000 + Math.random() * 9000));
    console.log("values:", values);
    values.variant.push({
      variationGroupId: "",
      sku: "",
      price: "",
      qty: "",
      hsn: "",
      parent: 0,
      gstId: "",
      ProductAdditionalInfos: {
        weight: "",
        dimensions: "",
        materials: "",
        otherInfo: "",
        weightType: ""
      },
      attributes: [
        {
          attributeId: "",
          attributeOptionId: "",
          optionText: "",
          variationRelationId: "",
        },
      ],
      productImages: [],
    });
    setInputList(values);
  };

  // add new variant
  console.log("inputList", inputList);
  const addNewVariant = () => {
    console.log("mera inputL: ", inputList)
    setRandom(Math.floor(1000 + Math.random() * 9000));
    if (!inputList) {
      setInputList({
        variant: [
          {
            variationGroupId: "",
            sku: "",
            hsn: "",
            parent: 0,
            price: "",
            qty: "",
            gstId: "",
            ProductAdditionalInfos: {
              weight: "",
              dimensions: "",
              materials: "",
              otherInfo: "",
              parent: 0,
              weightType: ""
            },
            attributes: [
              {
                attributeId: "",
                attributeOptionId: "",
                optionText: "",
                variationRelationId: "",
              },
            ],
            productImages: [],
          },
        ],
      });
    } else {
      handleAddClick();
    }
    setNewVariant(true);
  };

  const handleOnChange = (i, type, value) => {
    const values = { ...inputList };
    console.log("input", inputList)
    values.variant[i][type] = value;
    // console.log("hsn ki values: ", values.variant[i]["hsn"]);
    values.variant[i].ProductAdditionalInfos.dimensions = `${
      values.variant[i]["length"] === undefined
        ? ""
        : values.variant[i]["length"]
    } x ${
      values.variant[i]["breadth"] === undefined
        ? ""
        : values.variant[i]["breadth"]
    } x ${
      values.variant[i]["height"] === undefined
        ? ""
        : values.variant[i]["height"]
    }`;
    values.variant[i].ProductAdditionalInfos.weight = `${
      values.variant[i]["weight"] === undefined
        ? ""
        : values.variant[i]["weight"]
    }`;
    values.variant[i].ProductAdditionalInfos.materials = `${
      values.variant[i]["material"] === undefined
        ? ""
        : values.variant[i]["material"]
    }`;
    values.variant[i].ProductAdditionalInfos.otherInfo = `${
      values.variant[i]["otherInfo"] === undefined
        ? ""
        : values.variant[i]["otherInfo"]
    }`;
    setInputList(values);
  };

  useEffect(() => {
    viewAttributeData();
    localStorage.removeItem("inputList");
  }, []);

  const attributeChange = (i, subindex, value) => {
    let innerVal = [];
    let selectedAttributeData = [];
    const values = { ...inputList };

    if (
      values.variant[i].attributes.length == 1 &&
      values.variant[i].attributes[0].optionText == ""
    ) {
      attributeData.forEach((data) => {
        innerVal = data.AttributeOptions.filter((val) => val.name == value);

        if (!isEmpty(innerVal)) {
          values.variant[i].attributes[subindex].optionText = value;
          values.variant[i].attributes[subindex].attributeId = data.id;
          values.variant[i].attributes[subindex].attributeOptionId =
            innerVal[0].id;
          values.variant[i].attributes[subindex].variationRelationId =
            innerVal[0].id;
        }
      });
    } else if (
      values.variant[i].attributes.length == 1 &&
      values.variant[i].attributes[0].optionText != value
    ) {
      attributeData.forEach((data) => {
        selectedAttributeData = data;
        innerVal = data.AttributeOptions.filter((val) => val.name == value);
      });
      values.variant[i].attributes.push({
        attributeId: selectedAttributeData.id,
        attributeOptionId: innerVal[0].id,
        optionText: value,
        variationRelationId:
          values.variant[i].attributes[0].variationRelationId,
      });
    }

    setInputList(values);
  };

  if (attributeArr.length > 0) {
    localStorage.setItem("VarattributeArr", JSON.stringify(attributeArr));
  }
  console.log("inputList", inputList);

  const onButton = async (e, i) => {
    setClick(false);
    var formData = new FormData();
    formData.append("key", random);
    formData.append("product", e.target.files[0]);
    const imageData = [...imag];

    // API call for Image Upload

    await uploadProductImage(formData)
      .then((response) => {
        if (response.data.success === true) {
          toast.success("Variant Image has been Uploaded!", {});
        }
        setImage(imageData);
        const values = { ...inputList };
        console.log(values);
        const apiVal = response.data.data;
        for (const key in apiVal) {
          if (Object.hasOwnProperty.call(apiVal, key)) {
            const element = apiVal[key];
            element.key = random;
          }
        }
        values.variant[i].productImages = apiVal;
        setInputList(values);
        const images = response.data.data.map(({ imageUrl }) => ({
          key: key1,
          image: imageUrl.replace(`uploads/product/product_${key1}/`, ""),
        }));

        localStorage.setItem("varItems", JSON.stringify(images));
      })
      .catch((error) => {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 3000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
    // });
  };

  const deleteImage = async (name) => {
    setClick(true);
    const params = {
      key: key,
      filename: name,
    };

    await deleteProductImage(params)
      .then((response) => {
        toast.success(response.data.data, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        // console.log(imag);
        setDeleted(response.data.data);
        const images = response.data.data.map(({ imageUrl }) => ({
          key: key,
          image: imageUrl.replace(`uploads/product/product_${key}/`, ""),
        }));

        localStorage.setItem("varItems", JSON.stringify(images));
        // response.data.data.map(({imageUrl}) => localStorage.setItem("items",

        // JSON.stringify(response.data.data));
        //  setClick(false);
        // localStorage.removeItem("items", response.data.data.pop())
      })
      .catch((error) => {
        console.log(error.error);
        toast.error(error.error, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
      });
  };

  return (
    <div className="card shadow my-3">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Variant</h2>
      </div>
      <div className="card-section  box-border">
        <div className="card-session-content pt-lg">
          <div>
            {variant === false && (
              <div className="justify-center text-center">
                {createVariant === false && (
                  <div className="mb-4">
                    <span className="pr-1">
                      This product has some variants like color or size?
                    </span>
                    <Link
                      to="#"
                      style={{ fontWeight: "600" }}
                      onClick={() => setVariant(true)}
                    >
                      {" "}
                      Create a variant group
                    </Link>
                  </div>
                )}
              </div>
            )}

            {variant && (
              // <div>
              //   <div>
              //     <h5>Select the list of attribute</h5>
              //   </div>

              //   <div className="form-field-container null">
              //     <div className="field-wrapper radio-field">
              //       <label>
              //         <input type="checkbox" defaultValue="color" />
              //         <span className="checkbox-unchecked"></span>
              //         <span className="m-2">Color</span>
              //       </label>
              //     </div>
              //   </div>
              //   <div className="form-field-container null">
              //     <div className="field-wrapper radio-field">
              //       <label>
              //         <input type="checkbox" defaultValue="size" />
              //         <span className="checkbox-unchecked"></span>
              //         <span className="m-2">Size</span>
              //       </label>
              //     </div>
              //   </div>

              <div className="mt-4">
                <Link
                  className="text-interactive "
                  to="#"
                  style={{ fontWeight: "600" }}
                  onClick={() => {
                    setCreateVariant(true);
                    setVariant(false);
                  }}
                >
                  Create
                </Link>
              </div>
              // </div>
            )}

            {newVariant &&
              inputList.variant.map((e, index) => (
                <div className="row" key={index}>
                  {/* {e.productImages.map((image) => {
                    return ( */}
                  <div className="col-md-5">
                    <label
                      htmlFor={`i-${index}`}
                      className="custom-file-upload"
                    >
                      <i className="fa fa-camera"></i>
                    </label>
                    <input
                      key={`k-${index}`}
                      id={`i-${index}`}
                      name="variant"
                      type="file"
                      className="file-upload-1"
                      // onChange={(e) => onButton(setImagess((prev) => [...prev, { key: '0', name: e.target.files[0]?.name}]))}
                      onChange={(e) => {
                        console.log("indexxxxx", index);
                        onButton(e, index);
                      }}
                    />

                    <div className="uploadPicturesWrapper">
                      <div
                        key={index}
                        style={{
                          position: "relative",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexWrap: "wrap",
                          width: "100%",
                          marginTop: 15,
                        }}
                      >
                        {click === true && createVariant
                          ? deleted.map((items, index) => (
                              <div
                                className="uploadPictureContainer mt-3"
                                key={index}
                              >
                                {/* {console.log("deleted:",items)} */}
                                <input
                                  key={index}
                                  className="deleteImage"
                                  type="button"
                                  id={items?.imageUrl}
                                  value="X"
                                  onClick={(e) => deleteImage(e.target.id)}
                                ></input>

                                <img
                                  src={imageUrl + items?.imageUrl}
                                  className="uploadPicture"
                                  alt="preview"
                                />
                              </div>
                            ))
                          : e.productImages.map((items, index) => (
                              <div
                                className="uploadPictureContainer mt-3"
                                key={index}
                              >
                                {/* {console.log(variant)} */}
                                <input
                                  key={index}
                                  className="deleteImage"
                                  type="button"
                                  id={items?.imageUrl}
                                  value="X"
                                  onClick={(e) => deleteImage(e.target.id)}
                                ></input>

                                <img
                                  src={imageUrl + items?.imageUrl}
                                  className="uploadPicture"
                                  alt="preview"
                                  name={newVariant}
                                  itemID={index}
                                />
                              </div>
                            ))}
                      </div>
                    </div>
                  </div>
                  {/* );
                  })} */}
                  <div className="col-md-7">
                    <div className="row">
                      {attributeData?.map((data, subindex) => (
                        <>
                          <div className="col-md-6">
                            {/* {console.log(data)} */}
                            <div
                              className="form-field-container dropdown null"
                              key={subindex}
                            >
                              <div className="field-wrapper flex flex-grow items-baseline">
                                <select
                                  className="form-field"
                                  id={data?.id}
                                  name={data?.nameCode}
                                  defaultValue={data?.name}
                                  onChange={(e) => {
                                    attributeChange(
                                      index,
                                      subindex,
                                      e.target.value
                                    );
                                  }}
                                >
                                  <option disabled>{data?.name}</option>
                                  {data?.AttributeOptions?.map(
                                    (option, key) => (
                                      <option
                                        key={key}
                                        id={option?.id}
                                        value={option?.name}
                                        pid={option?.id}
                                      >
                                        {option?.name}
                                      </option>
                                    )
                                  )}
                                </select>
                                <div className="field-border"></div>
                              </div>
                            </div>
                          </div>
                        </>
                      ))}
                    </div>
                    <hr />
                    <div className="row">
                      <div className="col-md-4">
                        <div className="form-field-container null">
                          <label htmlFor="sku">SKU</label>
                          <div className="field-wrapper flex flex-grow">
                            <input
                              type="text"
                              name="sku"
                              placeholder="SKU"
                              defaultValue={e.sku}
                              onChange={(e) => {
                                handleOnChange(index, "sku", e.target.value);
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-field-container null">
                          <label htmlFor="price">Price</label>
                          <div className="field-wrapper flex flex-grow">
                            <input
                              type="text"
                              name="price"
                              placeholder="Price"
                              defaultValue={e.price}
                              onChange={(e) => {
                                handleOnChange(index, "price", e.target.value);
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-4">
                        <div className="form-field-container null">
                          <label htmlFor="quantity">Quantity</label>
                          <div className="field-wrapper flex flex-grow">
                            <input
                              type="text"
                              name="qty"
                              placeholder="Quantity"
                              defaultValue={e.qty}
                              onChange={(e) => {
                                handleOnChange(index, "qty", e.target.value);
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* DIV FOR DIMENSIONS */}
                    <div className="row">
                      <div className="col-md-12">
                        <div className="form-field-container null">
                          <label>Dimensions</label>
                          <div className="input-group">
                            <input
                              type="text"
                              aria-label="Length"
                              className="form-control"
                              placeholder="Length"
                              onChange={(e) => {
                                handleOnChange(index, "length", e.target.value);
                              }}
                            />
                            <div className="input-group-prepend">
                              <span
                                className="input-group-text"
                                style={{ borderRadius: "0!important" }}
                              >
                                x
                              </span>
                            </div>
                            <input
                              type="text"
                              aria-label="Breadth"
                              className="form-control"
                              placeholder="Breadth"
                              onChange={(e) => {
                                handleOnChange(
                                  index,
                                  "breadth",
                                  e.target.value
                                );
                              }}
                            />
                            <div className="input-group-prepend">
                              <span
                                className="input-group-text"
                                style={{ borderRadius: "0!important" }}
                              >
                                x
                              </span>
                            </div>
                            <input
                              type="text"
                              aria-label="Height"
                              className="form-control"
                              placeholder="Height"
                              onChange={(e) => {
                                handleOnChange(index, "height", e.target.value);
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* DIV FOR DIMENSIONS END*/}

                    <div className="row">
                      <div className="col-md-6">
                        <div className="form-field-container null">
                          <label htmlFor="weight">Material</label>
                          <div className="field-wrapper flex flex-grow">
                            <input
                              type="text"
                              placeholder="Material"
                              onChange={(e) => {
                                handleOnChange(
                                  index,
                                  "material",
                                  e.target.value
                                );
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="form-field-container null">
                          <label htmlFor="GST">GST</label>
                          <div className="field-wrapper flex flex-grow">
                            <select
                              className="form-field"
                              id="group_id"
                              onChange={(e) => {
                                handleOnChange(index, "gstId", e.target.value);
                              }}
                            >
                              <option selected="true" disabled="disabled">
                                Please Select GST
                              </option>
                              {gst?.map((gstData, key) => {
                                return (
                                  <option value={gstData?.id} key={key}>
                                    {gstData?.gst}
                                  </option>
                                );
                              })}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-9">
                        <div className="form-field-container null">
                          <label htmlFor="otherInfo">
                            Additional Information
                          </label>
                          <div className="field-wrapper flex flex-grow">
                            <textarea
                              placeholder=""
                              onChange={(e) => {
                                handleOnChange(
                                  index,
                                  "otherInfo",
                                  e.target.value
                                );
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-3">
                        <div className="form-field-container null">
                          <label htmlFor="weight">Weight</label>
                          <div className="field-wrapper flex flex-grow">
                            <input
                              type="text"
                              placeholder="weight"
                              onChange={(e) => {
                                handleOnChange(index, "weight", e.target.value);
                              }}
                            />
                            <div className="field-border"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className="btn btn-remove"
                      onClick={() => handleRemoveClick(index)}
                    >
                      {" "}
                      Remove{" "}
                    </button>
                    {newVariant && (
                      <button
                        type="button"
                        className="btn btn-remove me-2"
                        onClick={() => {
                          setVariant(false);
                          setCreateVariant(false);
                          setNewVariant(false);
                        }}
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              ))}

            {createVariant && (
              <>
                <div className="row">
                  <div className="col-md-6">
                    <Link
                      className="mt-1 btn text-primary"
                      to="#"
                      onClick={() => {
                        addNewVariant();
                      }}
                    >
                      Add a new variant{" "}
                    </Link>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar
        closeOnClick
        rtl={false}
        pauseOnFocusLoss={false}
        draggable={false}
        pauseOnHover
        limit={1}
        transition={Flip}
      />
    </div>
  );
};
export default Variant;
