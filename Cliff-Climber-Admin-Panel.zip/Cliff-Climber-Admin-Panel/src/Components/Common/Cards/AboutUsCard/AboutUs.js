import React, { useState } from "react";
import "./Aboutus.css";
import { EditorState, convertToRaw, ContentState, convertFromHTML } from "draft-js";
import { Editor } from "react-draft-wysiwyg";
import draftToHtml from "draftjs-to-html";
import { useForm } from "react-hook-form";
import { getPost, changePost } from "../../../../Services/cmsService";
import { useEffect } from "react";
import "react-toastify/dist/ReactToastify.min.css";
import { toast } from "react-toastify";

const AboutUs = () => {
  const [editorState, setEditorState] = useState();
  const [editorValue, setEditorValue] = useState("");
  const [type, setType] = useState("");
  const [id, setID] = useState(0);
  const {
    register,
    setValue,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onEditorStateChange = (editorState) => {
    setEditorState(editorState);
    setEditorValue(draftToHtml(convertToRaw(editorState.getCurrentContent())));
  };

  const submitData = (data) => {
    const param = {
      id: id,
      type:type,
      title: data.title,
      editor: editorValue
    }

    changePost(param).then((res) => {
      console.log(res.data.data);
      toast.success(res.data.data, {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: false,
        progress: 0,
        toastId: "my_toast",
      });
    })
    .catch((error) => {
      console.log(error);
    })
  }

  useEffect(() => {
    const param = {
      type:"aboutus"
    }
    getPost(param).then((res) => {
      console.log(res.data.data);
      setType(res.data.data.type);
      setID(res.data.data.id);
      setValue("title", res.data.data.title)
      setEditorState(EditorState.createWithContent(
        ContentState.createFromBlockArray(
          convertFromHTML(`${res.data.data.content}`)
        )
      ))
    })
  },[])

 

  return (
    <div className="container">
      <div className="row">
        <div className="card p-5" style={{ marginTop: 30, marginBottom: 40 }}>
          <form onSubmit={handleSubmit(submitData)}>
          <div>
            <h5 className="fs-light">
              Page title<span className="text-danger">*</span>
            </h5>
          </div>
          <div className="mb-3">
            <input
              type="text"
              className="form-control shadow-none"
              id="title"
              name="title"
              placeholder="title"
              {...register("title", {
                required: "title is required!",
              })}
            />
          </div>
          {errors.title && (
              <p className="errors">{errors.title.message}</p>
            )}

          <div className="mt-4">
            <h5 className="">Page Content</h5>
          </div>

          {/* WYSIWG EDITOR HERE */}
          <div>
          <Editor
            editorState={editorState}
            wrapperClassName="wrapper-class"
            editorClassName="editor-class"
            toolbarClassName="toolbar-class"
            placeholder="Type Something..."
            onEditorStateChange={(e) => onEditorStateChange(e)}
            id="content"
            name="about"
          />
          </div>
          {errors.content && (
              <p className="errors">{errors.content.message}</p>
            )}
          

          <div className="mx-auto mt-4">
            <button type="submit" className="btn btn-primary">
              💾 Save
            </button>
          </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;
