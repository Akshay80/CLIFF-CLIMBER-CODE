import React, { useEffect, useState } from "react";
import "./DashboardCard.scss";
import { dashboardService } from "../../../../Services/dashService";
import Loader from "../../../../Assets/Icon/loading.gif";

export const DashboardCard = () => {
  const [totalOrder, setOrder] = useState();
  const [totalSale, setSale] = useState();
  // const [totalCancelled, setCancel] = useState();
  const [totalCustomer, setCustomer] = useState();
  const [todaysOrder, setToday] = useState();
 
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    data();
  }, []);
  const data = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      dashboardService()
        .then((response) => {
          setOrder(response.data.data.totalOrders);
          setCustomer(response.data.data.totalCustomers);
          setToday(response.data.data.todaysOrders);
          setSale(response.data.data.todaysSale);
          // setCancel(response.data.data.totalCancelled);
        })
        .catch((error) => {
          console.log(error);
        });
    }, 2500);
  };
  return (
    <div className="container">
      <div className="row">
        {/* Total Orders */}
        <div className="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-4">
          <div className="dashboard-card">
            <div
              className="card h-100 w-100 py-2"
              style={{ maxWidth: "250px" }}
            >
              <div className="col-12 d-flex align-items-center">
                <div className="card-body p-3">
                  <p className="card-text cardTitle">Today's Order</p>
                  <h3 className="cardNumber">
                    {loading ? (
                      <img src={Loader} alt="loading" width={24} />
                    ) : (
                      todaysOrder
                    )}
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-4">
          <div className="dashboard-card">
            <div
              className="card h-100 w-100 py-2"
              style={{ maxWidth: "250px" }}
            >
          
              <div className="col-12">
                <div className="card-body p-3">
                  <p className="card-text cardTitle">Today's Sales</p>
                  <h3 className="cardNumber">
                    {loading ? (
                      <img src={Loader} alt="loading" width={24} />
                    ) : (
                      `₹${totalSale}`
                    )}
                    
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-4">
          <div className="dashboard-card">
            <div
              className="card h-100 w-100 py-2"
              style={{ maxWidth: "250px" }}
            >
             
              <div className="col-12">
                <div className="card-body p-3">
                  <p className="card-text cardTitle">Total Orders</p>
                  <h3 className="cardNumber">
                    {loading ? (
                      <img src={Loader} alt="loading" width={24} />
                    ) : (
                      totalOrder
                    )}
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-xs-12 mb-4">
          <div className="dashboard-card">
            <div
              className="card h-100 w-100 py-2"
              style={{ maxWidth: "250px" }}
            >
            
              <div className="col-12">
                <div className="card-body p-3">
                  <p className="card-text cardTitle">Total Customers</p>
                  <h3 className="cardNumber">
                    {loading ? (
                      <img src={Loader} alt="loading" width={24} />
                    ) : (
                      totalCustomer
                    )}
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
