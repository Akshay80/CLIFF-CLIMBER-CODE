import React, { useEffect, useState } from "react";
import { viewCustomerService } from "../../../../Services/customerServices";

const CustomerData = () => {
  const [customerData, setCustomer] = useState([]);
  useEffect(() => {
    viewCustomerService()
      .then((response) => {
        console.log(response.data.data);
        setCustomer(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div className="overflow-auto" style={{ height: "250px" }}>
      <table className="table table-responsive table-bordered">
        <thead>
          <tr>
            <th scope="col">S.No.</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">City</th>
            <th scope="col">State</th>
            <th scope="col">Postal Code</th>
          </tr>
        </thead>
        <tbody>
          {customerData.map((customer, index) => (
            <tr key={index}>
              <th scope="row">{index + 1}</th>
              <td>{customer.firstName + " " + customer.lastName}</td>
              <td>{customer.email}</td>
              <td>{customer.Address === null? "-" : customer?.Address?.city}</td>
              <td>{customer.Address === null? "-" : customer?.Address?.state }</td>
              <td>{customer.Address === null? "-" : customer?.Address?.zipCode}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CustomerData;
