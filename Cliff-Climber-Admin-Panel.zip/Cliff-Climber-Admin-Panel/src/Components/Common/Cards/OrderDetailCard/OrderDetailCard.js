import React, {useEffect, useState} from "react";
import { ReactComponent as OrderIcon } from "../../../../Assets/Icon/orderinprogress.svg";
import { dashboardService } from "../../../../Services/dashService";
import "./OrderDetailCard.scss";

const OrderDetailCard = () => {
  const [recentOrders, setRecentOrders] = useState([]);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [failedOrders, setFailedOrders] = useState([]);

  useEffect(() => {
    dashboardService().then((response) => {
      console.log("response", response.data.data);
      setRecentOrders(response.data.data.recentOrders);
      setPendingOrders(response.data.data.pendingOrders);
      setFailedOrders(response.data.data.failedOrders);
    })
    .catch((error) => {
      console.log(error);
    })
  }, [])
  
  return (
    <div className="accordion" id="accordionExample">
      <div className="accordion-item border-0">
        <div
          id="collapseOne"
          className="accordion-collapse collapse show"
          aria-labelledby="headingOne"
          data-bs-parent="#accordionExample"
        >
          <div className="accordion-body">
            <nav>
              <div className="nav nav-tabs" id="nav-tab" role="tablist">
                <button
                  className="nav-link active btn-sm"
                  id="nav-home-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#nav-home"
                  type="button"
                  role="tab"
                  aria-controls="nav-home"
                  aria-selected="true"
                >
                  Recent Orders
                </button>
                {/* <button
                  className="nav-link btn-sm"
                  id="nav-profile-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#nav-profile"
                  type="button"
                  role="tab"
                  aria-controls="nav-profile"
                  aria-selected="false"
                >
                  Pending Orders
                </button> */}
                <button
                  className="nav-link btn-sm"
                  id="nav-contact-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#nav-contact"
                  type="button"
                  role="tab"
                  aria-controls="nav-contact"
                  aria-selected="false"
                >
                  Failed Orders
                </button>
              </div>
            </nav>
            <div className="tab-content" id="nav-tabContent">
              <div
                className="tab-pane fade show active"
                id="nav-home"
                role="tabpanel"
                aria-labelledby="nav-home-tab"
              >
                <div className="overflow-auto py-2" style={{ height: "250px" }}>
                  <table className="table table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">S.No.</th>
                        <th scope="col">Order ID</th>
                        <th scope="col">Email Address</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentOrders.map((items, index) => (
                      <tr key={index}>
                        <th scope="row">{index+1}</th>
                        <td>{items.orderNumber}</td>
                        <td>{items.customerEmail}</td>
                        <td>{items.orderState}</td>
                      </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div
                className="tab-pane fade"
                id="nav-profile"
                role="tabpanel"
                aria-labelledby="nav-profile-tab"
              >
                <div className="overflow-auto py-2" style={{ height: "250px" }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">S.No.</th>
                        <th scope="col">Order ID</th>
                        <th scope="col">Email Address</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pendingOrders.map((items, index) => (
                      <tr>
                         <th scope="row">{index+1}</th>
                        <td>{items.orderNumber}</td>
                        <td>{items.customerEmail}</td>
                        <td>{items.orderState}</td>
                      </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div
                className="tab-pane fade"
                id="nav-contact"
                role="tabpanel"
                aria-labelledby="nav-contact-tab"
              >
                <div className="overflow-auto py-2" style={{ height: "250px" }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th scope="col">S.No.</th>
                        <th scope="col">Order ID</th>
                        <th scope="col">Email Address</th>
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                    {failedOrders.map((items, index) => (
                      <tr>
                         <th scope="row">{index+1}</th>
                        <td>{items.orderNumber}</td>
                        <td>{items.customerEmail}</td>
                        <td>{items.orderState}</td>
                      </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetailCard;
