import { Import } from "@rsuite/icons";
import React, { useReducer } from "react";
import Table from "react-bootstrap/Table";
import "./OrderEdit.css";
import Activity from "./OrderEditComp/Activity";
import BillingDetail from "./OrderEditComp/billingDetail";
import CustomerDetail from "./OrderEditComp/CustomerDetail";
import PaymentStatus from "./OrderEditComp/PaymentStatus";
import OrderDetail from "./OrderEditComp/OrderDetail";
import { viewOrdersByID } from "../../../../Services/orderService";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useState } from "react";
import Active from './OrderEditComp/Active';
import TrackingDetails from "./OrderEditComp/TrackingDetails";

const OrderEdit = () => {
  const { orderId } = useParams();
  const [orderData, setOrderData] = useState([]);
  const [orderState, setOrderState]= useState();
  const [ignored, forceUpdate] = useReducer(x => x + 1, 0);
  // var check = false;

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(async function () {
   await viewOrdersByID(orderId)
      .then((response) => {
        setOrderData(response.data.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [orderId, ignored]);

 

  return (
    <div className="row">
      {/* Header */}
      <div className="page-heading flex justify-between items-center">
        <div className="flex justify-start space-x-1 items-center">
          {/* {orderData.paymentState === "PENDING" && (
            <span className="badge pending">
              <span className=" complete pending progress rounded-100"></span>
              pending
            </span>
          )}
          {orderData.paymentState === "PROCESSING" && (
            <span className="badge danger ">
              {" "}
              <span className="complete danger progress rounded-100"></span>{" "}
              Processing
            </span>
          )}
          {orderData.paymentState === "COMPLETE" && (
            <span className="badge success ">
              {" "}
              <span className="complete success progress rounded-100"></span>{" "}
              Completed
            </span>
          )} */}
        </div>
      </div>

      <div className="col-md-8">
        {/* Order detail  */}
        <OrderDetail
          orderItems={orderData.OrderItems}
          paymentstate={orderData.paymentState}
          orderState={orderData.orderState}
        />

        {/* <TrackingDetails ship={orderData.shippingMethod} track={orderData.trackingId}/> */}

        {/* Billing Detail */}
        <BillingDetail
          totalQty={orderData.totalQty}
          subTotal={orderData.currencySymbol + orderData.subTotal}
          delieveryCharges={
            orderData.currencySymbol + orderData.deliveryCharges
          }
          shippingFee={orderData.shippingFeeInclTax}
          taxAmount={orderData.currencySymbol + orderData.taxAmount}
          grandTotal={orderData.currencySymbol + orderData.grandTotal}
        />

        {/* Activity */}
        {/* <Activity orderState={orderData.orderState} /> */}
        <Active orderState={orderData.orderState}/>
      </div>

      <div className="col-md-4">
        {/* Customer notes */}
        <PaymentStatus paymentstate={orderData.paymentState}/>

        {/* Customer Detail */}
        <CustomerDetail
          email={orderData.customerEmail}
          name={orderData.customerFullName}
          phone={orderData.phone}
          shippingAddress={orderData.shippingAddress}
          billingAddress={orderData.billingAddress}
          unitAddress={orderData.unitAddress}
          specialInstruction={orderData.specialInstruction}
        />
      </div>
    </div>
  );
};

export default OrderEdit;
