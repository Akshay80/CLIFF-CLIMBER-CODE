import React from "react";

const PaymentStatus = ({paymentstate}) => {
  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Payment Status</h2>
      </div>

      <div className="card-section box-border">
        <div className="card-session-content pt-lg">
          <div>
          <div className="flex justify-between card-section-header mb-1">
              <h6 className="card-session-title">Payment status</h6>
            </div>
            <span className="text-border fw-bold">{paymentstate}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
export default PaymentStatus;
