import React, { useState, useEffect, useReducer } from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepButton from "@mui/material/StepButton";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { confirmAlert } from "react-confirm-alert";
import { setOrderState, viewOrdersByID } from "../../../../../Services/orderService";
import { ToastContainer, toast, Flip } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { useParams } from "react-router-dom";
import "../OrderEdit.css"
import { Container, StepContent, StepLabel } from "@mui/material";
import useMediaQuery from '@mui/material/useMediaQuery';

const steps = [
  "Order Placed",
  "Order Packed",
  "Order Shipped",
  "Out for Delivery",
  "Order Delievered"
];

export default function Active() {
  const [activeStep, setActiveStep] = React.useState(0);
  const [completed, setCompleted] = React.useState({});
  const [toggle, setToggle] = useState(false);
  const [ignored, forceUpdate] = useReducer(x => x + 1, 0);
  const { orderId } = useParams();
  const [truth, setTruth] = useState(false);
  const [updatedState, setUpdateState] = useState("CONFIRMED");
  const isMobile = useMediaQuery('(max-width:600px)');

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const getOrderState = () => {
    if (updatedState === undefined) {
      setActiveStep("");
    }
    if (updatedState === "CONFIRMED") {
      setActiveStep(0);
    }
    if (updatedState === "PACKED") {
      setActiveStep(1);
    }
    // if (orderState === "READY-FOR-DISPACHED") {
    //   setActiveStep(2);
    // }
    if (updatedState === "SHIPPED") {
      setActiveStep(2);
    }
    if (updatedState === "OUT-FOR-DELIVERY") {
      setActiveStep(3);
    }
    if (updatedState === "DELIVERED") {
      setActiveStep(4);
    }
    // forceUpdate();
  };
  

  useEffect(() => {
    getActive();
  }, [setUpdateState, updatedState, toggle]);

  const getActive = async() => {
    await viewOrdersByID(orderId).then((res) => {
      setUpdateState(res?.data?.data?.orderState);
      console.log(res?.data?.data?.orderState);
    })
    .catch((error) => {
      console.log(error);
    });
  }

  useEffect(() => {
    getOrderState();
  }, [updatedState, activeStep, getOrderState, ignored, forceUpdate, toggle]);

 

  const totalSteps = () => {
    return steps.length;
  };

  const completedSteps = () => {
    return Object.keys(completed).length;
  };

  const isLastStep = () => {
    return activeStep === totalSteps() - 1;
  };

  const allStepsCompleted = () => {
    return completedSteps() === totalSteps();
  };

  const handleNext = () => {
    const newActiveStep =
      isLastStep() && !allStepsCompleted()
        ? // It's the last step, but not all steps have been completed,
          // find the first step that has been completed
          steps.findIndex((step, i) => !(i = 1 in completed))
        : activeStep + 1;
        console.log(newActiveStep);
    handleProceed(newActiveStep);
    setActiveStep(newActiveStep);
  };

  const handleStep = (step) => () => {
    setActiveStep(step);
  };

  const handleProceed = (type) => {
    confirmAlert({
      title: "Proceed",
      message: `Are you sure you want to proceed to next step?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-success",
          onClick: () => {
            confirmProceed(type);
          },
        },
        {
          label: "No",
          className: "btn btn-danger",
        },
      ],
    });
  };

  const confirmProceed = (type) => {
    setTruth(true);
    const params = {
      id: orderId,
      type: `${type}`,
    };
    setOrderState(params)
      .then((response) => {
        toast.success(response.data.data, {
          position: "top-right",
          autoClose: 2000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        getActive();
        // forceUpdate();
        // setToggle(true)
      })
      .catch((error) => {
        toast.error(error.error, {
          position: "top-right",
          autoClose: 4500,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
          toastId: "my_toast",
        });
        console.log(error);
      });
      
  };


  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Activity</h2>
      </div>
      <div className="card-section box-border pb-5" style={{ zIndex: 0 }}>
    {isMobile === true? (
//  <Box sx={{ width: "100%", display: "flex", flexDirection: "column", alignItems: "center"}}>
//  <Stepper activeStep={activeStep} alternativeLabel orientation="vertical" >
//    {steps.map((label, index) => (
//      <Step key={label} completed={completed[index]}>
//        <StepButton color="inherit" onClick={handleStep(index)}>
//          {label}
//        </StepButton>
//      </Step>
//    ))}
//  </Stepper>
//  <div>
//    <React.Fragment>
//      <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
//        <Box sx={{ flex: "1 1 auto" }} />
//        <Button
//        // color="#21b6ae"
//        className="btn-full"
//          variant="contained"
//          onClick={handleNext}
//          sx={{ mr: 1 }}
//          disabled={activeStep === 4}

//        >
//          Next
//        </Button>
//      </Box>
     
//    </React.Fragment>
//  </div>
// </Box>


<Box sx={{ maxWidth: 400 }}>
<Stepper activeStep={activeStep} orientation="vertical">
  {steps.map((step, index) => (
    <Step key={step}>
      <StepLabel>
        {step}
      </StepLabel>
      <StepContent>
        <Box sx={{ mb: 2 }}>
          <div>
            <Button
              variant="contained" 
              className="btn-full"
              onClick={handleNext}
              disabled={activeStep === 4}
              sx={{ mt: 1, mr: 1 }}
            >
              Next
            </Button>
          </div>
        </Box>
      </StepContent>
    </Step>
  ))}
</Stepper>
</Box>


    ): (
      <Box sx={{ width: "100%" }}>
      <Stepper activeStep={activeStep} alternativeLabel orientation="horizontal" >
        {steps.map((label, index) => (
          <Step key={label} completed={completed[index]}>
            <StepButton color="inherit" onClick={handleStep(index)}>
              {label}
            </StepButton>
          </Step>
        ))}
      </Stepper>
      <div>
        <React.Fragment>
          <Box sx={{ display: "flex", flexDirection: "row", pt: 2 }}>
            <Box sx={{ flex: "1 1 auto" }} />
            <Button
            // color="#21b6ae"
            className="btn-full"
              variant="contained"
              onClick={handleNext}
              sx={{ mr: 1 }}
              disabled={activeStep === 4}

            >
              Next
            </Button>
          </Box>
          
        </React.Fragment>
      </div>
    </Box>
    )}
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar
          closeOnClick
          rtl={false}
          pauseOnFocusLoss={false}
          draggable={false}
          pauseOnHover
          limit={1}
          transition={Flip}
        />
      </div>
    </div>
  );
}
