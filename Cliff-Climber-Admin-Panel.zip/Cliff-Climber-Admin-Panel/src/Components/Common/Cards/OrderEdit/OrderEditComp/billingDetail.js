import React from "react";

import Table from "react-bootstrap/Table";
const BillingDetail = ({ totalQty, subTotal, delieveryCharges, shippingFee, taxAmount, grandTotal}) => {
  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title ">
          <div className="flex justify-between space-x-1">
            Billing Details
            {/* {paymentstate === "PENDING" && (
              <>
                <span className=" circle default">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Pending</span>
              </>
            )}
            {paymentstate === "PROCESSING" && (
              <>
                <span className="warning circle">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Processing</span>
              </>
            )}

            {paymentstate === "COMPLETE" && (
              <>
                <span className=" circle success ">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Paid</span>
              </>
            )}
            {paymentstate === "CANCELLED" && (
              <>
                <span className="circle red">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">CANCELLED</span>
              </>
            )} */}
            
          </div>
        </h2>
      </div>
      <div className="card-section box-border">
        <div className="card-session-content pt-lg">
          <div className="row px-3 table">
            <Table>
              <tbody>
                <tr>
                  <td>Subtotal</td>
                  <td>{totalQty} items</td>
                  <td style={{textAlign: "right"}}>{subTotal}</td>
                </tr>
                <tr>
                  <td>Delievery Charges</td>
                  <td></td>
                  <td style={{textAlign: "right"}}>{delieveryCharges}</td>
                </tr>
                <tr>
                  <td>Shipping Charges</td>
                  <td></td>
                  <td style={{textAlign: "right"}}>{shippingFee === null? "₹0.00": shippingFee}</td>
                </tr>
                <tr>
                  <td>Tax</td>
                  <td></td>
                  <td style={{textAlign: "right"}} >{taxAmount}</td>
                </tr>
                {/* <tr>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                </tr> */}
              </tbody>
            </Table>
            <Table>
              <thead>
                <tr>
                  <td>Paid by customer</td>
                  <td></td>
                  <td style={{textAlign: "right"}}>{grandTotal}</td>
                </tr>
              </thead>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};
export default BillingDetail;
