import React, { useEffect, useState } from "react";
import { typeOf } from "react-multiple-image-input";
import StepProgressBar from "react-step-progress";
import "react-step-progress/dist/index.css";

const Activity = ({ orderState }) => {
  var [num, setNum] = useState(0);
  var [incNum, setIncNum] = useState(0);
  var [updateIndex, setIndex] = useState(false);
  // setup step validators, will be called before proceeding to the next step
  const step2Validator = () => {
    console.log();
    return true;
  };

  const step3Validator = () => {
    return false;
  };

  useEffect(() => {
    if (orderState === undefined) {
      setNum("");
    }
    if (orderState === "CONFIRMED") {
      setNum(0);
      setIndex(true);
    }
    if (orderState === "PACKED") {
      setNum(1);
      setIndex(true);
    }
    if (orderState === "SHIPPED") {
      setNum(2);
      setIndex(true);
    }
    if (orderState === "OUT-FOR-DELIVERY") {
      setNum(3);
      setIndex(true);
    }
    if (orderState === "DELIVERED") {
      setNum(4);
      setIndex(false);
    }
    if (orderState === "CANCELLED") {
      setNum(5);
    }
  }, [orderState, num]);

  function onFormSubmit() {
    // handle the submit logic here
    // This function will be executed at the last step
    // when the submit button (next button in the previous steps) is pressed
    console.log("finished form!");
  }

  const onPrevious = () => {
    console.log("clicked previous!");
    if (updateIndex === true && num > 0) {
      setIncNum(num--);
    } else {
      console.log("you cannot decreement less than 0");
    }
  };

  const onNext = () => {
    console.log("clicked next!");
    if (updateIndex === true && num < 4) {
      setIncNum(num++);
    } else {
      console.log("you cannot increement further");
    }
  };

  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Activity</h2>
      </div>
      <div className="card-section box-border pb-5" style={{ zIndex: 0 }}>
        <div className="App">
          {num !== "" ? (
            <StepProgressBar
              startingStep={num}
              onSubmit={onFormSubmit}
              // previousBtnName={"Previous"}
              // nextBtnName={"Next"}
              steps={[
                {
                  label: "Order Placed",
                  name: "order",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/29may)</span>,
                },
                {
                  label: "Order Packed",
                  name: "packed",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/29may)</span>,
                },
                {
                  label: "Ready to Dispatch",
                  name: "ready",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/29may)</span>,
                },
                {
                  label: "Order Shipped",
                  name: "shipped",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/30may)</span>,
                },
                {
                  label: "Out for Delivery",
                  name: "Out-for-Delivery",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/31may)</span>,
                  // validator: step2Validator,
                },
                {
                  label: "Order Delivered",
                  name: "delivered",
                  // subtitle: <span style={{ fontSize: 12 }}>(2pm/1june)</span>,
                },
              ]}
            />
          ) : null}

          {/* Button Logic */}

          {/* <div className="d-flex justify-content-between">
            <div>
              <button
                className="btn"
                style={{ backgroundColor: "#215C55", color: "#fff" }}
                onClick={onPrevious}
              >
                Previous
              </button>
            </div>
            <div>
              <button
                className="btn"
                style={{ backgroundColor: "#215C55", color: "#fff" }}
                onClick={onNext}
              >
                Next
              </button>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
};

export default Activity;
