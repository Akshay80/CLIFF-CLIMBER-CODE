 /* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from "react";
import { viewInvoicebyId } from "../../../../../Services/orderService";
import Table from "react-bootstrap/Table";
import { useParams } from "react-router-dom";

const TrackingDetails = (props) => {
  const { orderId } = useParams();
  const [ship, setShip] = useState("Not yet Selected");
  const [track, setTrack] = useState(0);
  var check = JSON.parse(window.localStorage.getItem('check'));

  useEffect(() => {
    if(check === true)
    {
      getInvoiceByID();
    }
    console.log("tracking wala hai")
  }, [orderId, ship, track, setShip, setTrack, check]);


  const getInvoiceByID = async() => {
await viewInvoicebyId(orderId)
.then((res) => {
  // console.log("mera response from API: ", res.data.data.shippingMethod);
  // console.log("props : ", props);
  setShip(res.data.data.shippingMethod);
  setTrack(res.data.data.trackingId);
  console.log("mai chala");
})
.catch((error) => {
  console.log(error);
});
  }

  if(check === true)
  {
console.log("i am groot");
getInvoiceByID();
  }
  else
  {
    console.log("i am harry potter");
  }



  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title ">
          <div className="flex justify-between space-x-1">Tracking Details</div>
        </h2>
      </div>
      <div className="card-section box-border">
        <div className="card-session-content pt-lg">
          <div className="row px-3 table">
            <Table>
              <tbody>
                <tr>
                  <td>Tracking Id</td>
                  <td></td>
                  <td style={{ textAlign: "right" }}>{track === null? 0: track}</td>
                </tr>
                <tr>
                  <td>Shipment service</td>
                  <td></td>
                  <td style={{ textAlign: "right" }}>{ship=== null? "Yet to be shipped!": ship}</td>
                </tr>
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};
export default TrackingDetails;
