import React, { useCallback } from "react";
import Table from "react-bootstrap/Table";
import { Link } from "react-router-dom";
import { ReactComponent as EditIcon } from "../../../../../Assets/Icon/Edit.svg";
import { useForm } from "react-hook-form";
import { useState } from "react";
import { changeShipAddress } from "../../../../../Services/orderService";
import { toast } from "react-toastify";

const CustomerDetail = ({
  name,
  email,
  phone,
  shippingAddress,
  billingAddress,
  unitAddress,
  specialInstruction
}) => {
  const { handleSubmit, clearErrors, setValue, register } = useForm();

  const editValue = useCallback(() => {
    setValue("addressLineOne", shippingAddress?.addressLineOne);
    setValue("addressLineTwo", shippingAddress?.addressLineTwo);
    setValue("city", shippingAddress?.city);
    setValue("state", shippingAddress?.state);
    // setValue("country", shippingAddress?.country);
    setValue("country", 101)
    setValue("zipCode",  shippingAddress?.zipCode);
  }, [shippingAddress, setValue])

  const submitAddress = async (data) => {
    setValue("phone", shippingAddress?.phone);
    setValue("GSTNO", shippingAddress?.GSTNO);
    setValue("fullname", shippingAddress?.fullname);
    setValue("addressId", shippingAddress?.id);
    const params = {
      addressId: shippingAddress?.id,
      fullname: shippingAddress?.fullname,
      GSTNO: shippingAddress?.GSTNO,
      phone: shippingAddress?.phone,
      ...data
    }
    changeShipAddress(params).then((response)=> {
      toast.success(response.data.data, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: false,
        progress: 0,
      });
    })
    .catch((error) =>{
      console.log(error);
    })

  };

  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title">Customer</h2>
      </div>

      <div className="card-section border-b box-border">
        <div className="card-session-content pt-lg">
          {/* <Link to="" className="text-interactive hover:underline block"></Link> */}
          <span>
            {specialInstruction === null
              ? "No additional instructions given by customer"
              : specialInstruction}
          </span>
        </div>
      </div>
      <div className="card-section border-b box-border">
        <div className="flex justify-between card-section-header mb-1">
          <h6>Contact information</h6>
        </div>
        <div className="card-session-content pt-lg">
          <div>
            <a
              href={`mailto:${email}`}
              className="text-interactive hover:underline"
              target={"_blank"}
              rel="noreferrer"
            >
              {email}
            </a>
          </div>
          <div>
            <span>{phone}</span>
          </div>
        </div>
      </div>
      {unitAddress ? (
        <div className="card-section border-b box-border">
          <div className="flex justify-between card-section-header mb-1">
            <h5
              className="card-session-title mb-4"
              style={{ color: "#646464" }}
            >
              Unit address
            </h5>
          </div>
          <div className="card-session-content pt-lg">
            <div className="mt-1">
              <span
                className="card-session-title me-2"
                style={{ color: "#646464" }}
              >
                Unit name:
              </span>
              <span>{unitAddress?.unitName}</span>
            </div>

            <div className="mt-1">
              <span
                className="card-session-title me-2"
                style={{ color: "#646464" }}
              >
                Unit address:
              </span>
              <span>{unitAddress?.unitAddress}</span>
            </div>

            <div className="mt-1">
              <span>
                <span
                  className="card-session-title me-2"
                  style={{ color: "#646464" }}
                >
                  Unit careof:
                </span>
                {unitAddress?.careOf}
              </span>
            </div>
            <div className="mt-1">
              <span>
                <span
                  className="card-session-title me-2"
                  style={{ color: "#646464" }}
                >
                  Created by:
                </span>
                {unitAddress?.UnitCreatedBy}
              </span>
            </div>

            <div className="mt-1">
              <span
                className="card-session-title me-2"
                style={{ color: "#646464" }}
              >
                Unit pincode:
              </span>
              {unitAddress?.unitPincode}
            </div>
          </div>
        </div>
      ) : (
        <>
          <>
            <div className="card-section border-b box-border">
              <div className="flex justify-between card-section-header mb-1">
                <h6 className="card-session-title">Shipping address</h6>
                {/* <button
                  className="btn btn-full text-white"
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal"
                >
                  Edit
                </button> */}
                <EditIcon
                  className="mt-1 edit-icon"
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal"
                  onClick={editValue}
                />
              </div>
              <div className="card-session-content pt-lg">
                <div className="mt-3">
                  <span
                    className="card-session-title me-2"
                    style={{ color: "#646464" }}
                  >
                    Address 1:
                  </span>
                  <span>{shippingAddress?.addressLineOne}</span>
                </div>
                <div className="mt-1">
                  <span
                    className="card-session-title me-2"
                    style={{ color: "#646464" }}
                  >
                    Address 2:
                  </span>
                  <span>{shippingAddress?.addressLineTwo}</span>
                </div>
                <div className="mt-1">
                  <div>
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      City:
                    </span>
                    {shippingAddress?.city}
                  </div>

                  <div className="mt-1">
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      State:
                    </span>
                    {shippingAddress?.state}
                  </div>
                </div>

                <div className="mt-1">
                  <span
                    className="card-session-title me-2"
                    style={{ color: "#646464" }}
                  >
                    Country:
                  </span>
                  {shippingAddress?.country}
                </div>

                <div className="mt-1">
                  <span
                    className="card-session-title me-2"
                    style={{ color: "#646464" }}
                  >
                    Pincode:
                  </span>
                  <span>{shippingAddress?.zipCode}</span>
                </div>
              </div>
            </div>
            {shippingAddress?.isBillingAsSameShipping === true ? (
              <div className="p-4">
                <div class="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value=""
                    id="myCheckBOX"
                    checked={true}
                  />
                  <label className="form-check-label" for="flexCheckChecked">
                    Same as Billing Address
                  </label>
                </div>
              </div>
            ) : (
              <div className="card-section box-border">
                <div className="flex justify-between card-section-header mb-1">
                  <h6 className="card-session-title">Billing address</h6>
                </div>
                <div className="card-session-content pt-lg">
                  <div className="mt-3">
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      Address 1:
                    </span>
                    <span>{billingAddress?.addressLineOne}</span>
                  </div>
                  <div className="mt-1">
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      Address 2:
                    </span>
                    <span>{billingAddress?.addressLineTwo}</span>
                  </div>
                  <div className="mt-1">
                    <div>
                      <span
                        className="card-session-title me-2"
                        style={{ color: "#646464" }}
                      >
                        City:
                      </span>
                      {billingAddress?.city}
                    </div>

                    <div className="mt-1">
                      <span
                        className="card-session-title me-2"
                        style={{ color: "#646464" }}
                      >
                        State:
                      </span>
                      {billingAddress?.state}
                    </div>
                  </div>

                  <div className="mt-1">
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      Country:
                    </span>
                    {billingAddress?.country}
                  </div>

                  <div className="mt-1">
                    <span
                      className="card-session-title me-2"
                      style={{ color: "#646464" }}
                    >
                      Pincode:
                    </span>
                    <span>{billingAddress?.zipCode}</span>
                  </div>
                </div>
              </div>
            )}
          </>
          <div
            className="modal fade"
            id="exampleModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header border-0">
                  <h5 className="modal-title">Change Shipping Address</h5>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <form onSubmit={handleSubmit(submitAddress)}>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="mb-1">
                          <label
                            for="exampleFormControlInput1"
                            className="form-label"
                          >
                            Address 1
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput1"
                            placeholder="Address 1"
                            {...register('addressLineOne', {
                              required: 'Address1 is required!' 
                            })}
                          />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="mb-1">
                          <label
                            for="exampleFormControlInput2"
                            className="form-label"
                          >
                            Address 2
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput2"
                            placeholder="Address 2"
                            {...register('addressLineTwo', {
                              required: 'Address2 is required!' 
                            })}
                          />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="mb-1">
                          <label
                            for="exampleFormControlInput3"
                            className="form-label"
                          >
                            City
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput3"
                            placeholder="City"
                            {...register('city', {
                              required: 'City is required!' 
                            })}
                          />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="mb-1">
                          <label
                            for="exampleFormControlInput4"
                            className="form-label"
                          >
                            State
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput4"
                            placeholder="State"
                            {...register('state', {
                              required: 'State is required!' 
                            })}
                          />
                        </div>
                      </div>

                      <div className="col-md-6">
                        <div className="mb-1">
                          <label
                            for="exampleFormControlInput5"
                            className="form-label"
                          >
                            Country
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput5"
                            placeholder="Country"
                            disabled
                            defaultValue={"India"}
                          />
                        </div>
                      </div>


                      <div className="col-md-6">
                        <div className="mb-0">
                          <label
                            for="exampleFormControlInput6"
                            className="form-label"
                          >
                            Pincode
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="exampleFormControlInput6"
                            placeholder="Pincode"
                            
                            {...register('zipCode', {
                              required: 'Pincode is required!' 
                            })}
                          />
                        </div>
                      </div>

                    </div>
                    <div className="modal-footer border-0 mt-3">
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                  <button type="submit" className="btn btn-primary btn-sm" data-bs-dismiss="modal">
                    Save changes
                  </button>
                </div>
                  </form>
                </div>

                
              
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
export default CustomerDetail;
