// /* eslint-disable jsx-a11y/alt-text */
// import React from "react";
// import Barcode from "react-barcode";
// import ReactToPrint from "react-to-print";
// import '../../../../../Styles/_custom.scss';

// const Invoice = React.forwardRef((props, ref) => (
//   <ReactToPrint documentTitle="Invoice">
//   <div ref={ref}>
//     {console.log(props)}
//     <div className="InvoicePrint">
//       <div
//         style={{
//           background: "#d8d8d8",
//           textAlign: "center",
//           fontWeight: "boldest",
//           minHeight: 32,
//           verticalAlign: "middle",
//         }}
//       >
//         <h3 className="mb-0 fw-bold" style={{ borderBottom: "1px solid" }}>
//           TAX INVOICE
//         </h3>
//       </div>
//       <div
//         className="text-center"
//         style={{ minHeight: 28, borderBottom: "1px solid #999999" }}
//       >
//         <h5 className="fw-normal">PREPAID SHIPMENT - Deliever Order Only</h5>
//       </div>

//       <div
//         className="d-flex mt-4 justify-content-between p-3"
//         style={{ marginBottom: -5 }}
//       >
//         <div>
//           <img
//             src="https://ik.imagekit.io/bfrs/tr:w-250,h-125,pr-true,cm-pad_resize/image_cliffclimber/data/logo/Logo.png"
//             alt="logo"
//           />
//           <div>
//             <p className="myparagraphings mb-0">
//               Cliff Climbers (India) Pvt. Ltd
//             </p>
//             <p className="myparagraphings mb-0">E-5 Govt Industrial State</p>
//             <p className="myparagraphings mb-0">Patel Nagar</p>
//             <p className="myparagraphings mb-0">DehraDun</p>
//             <p className="myparagraphings mb-0">Uttrakhand, India, 248001</p>
//             <p className="myparagraphings mb-0">Telephone: +91-135-2728292</p>
//             <p className="myparagraphings mb-0">Landline: +91-135-2620005</p>
//             <p className="myparagraphings mb-0">ecom@cliffclimbers.in</p>
//             <p className="myparagraphings mb-0">(State Code)</p>
//             <p className="myparagraphings mb-0">(GSTIN No.: 05AAFCC2270GIZI)</p>
//           </div>
//         </div>

//         <div>
//           <div
//             className="d-flex justify-content-between"
//             style={{ marginBottom: -5 }}
//           >
//             <h6 className="myparagraphings fw-bold">
//               Order Date: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
//             </h6>
//             <p className="myparagraphings">{props.orderDate}</p>
//           </div>

//           {/* <div> */}
//             <div
//               className="d-flex justify-content-between"
//               style={{ marginBottom: -5 }}
//             >
//               <h6 className="myparagraphings fw-bold">Invoice no:</h6>
//               <p className="myparagraphings">Ecom-ccipl123</p>
//             </div>

//             <div
//               className="d-flex justify-content-between"
//               style={{ marginBottom: -5 }}
//             >
//               <h6 className="myparagraphings fw-bold">Invoice Date:</h6>
//               <p className="myparagraphings">&nbsp;&nbsp;&nbsp;24/11/2012</p>
//             </div>

//             <div
//               className="d-flex justify-content-between"
//             >
//               <h6 className="myparagraphings fw-bold">Invoice No Bar Code:</h6>
//               <p className="myparagraphings">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
//             </div>

//             <div className="text-center">
//               <Barcode
//                 value="Ecom-ccipl-00087"
//                 format="CODE128"
//                 height={50}
//                 width={1}
//                 displayValue={false}
//               />
//               <p
//                 className="fw-bold myparagraphings mb-0 mt-0 text-center"
//                 style={{ fontSize: 15 }}
//               >
//                 Ecom-ccipl-00087
//               </p>
//             {/* </div> */}
//           </div>
//           {/* <div className='text-center'> */}

//           <div>

//             <div
//               className="d-flex mt-4  justify-content-between"
//               style={{ marginBottom: -5 }}
//             >
//               <h6 className="fw-bold myparagraphings">Order ID:</h6>
//               <p className="myparagraphings">{props.orderId}</p>
//             </div>

//             {/* <div> */}
//               <div
//                 className="d-flex justify-content-between"
//                 style={{ marginBottom: -5 }}
//               >
//                 <h6 className="fw-bold myparagraphings">Order ID Bar Code:</h6>
//                 &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;
//               </div>
//               <div className="text-center">
//                 <div>
//                 <Barcode
//                   value={props.orderId}
//                   displayValue={false}
//                   format="CODE128"
//                   width={1.8}
//                   height={50}
//                 />
//                 </div>
                
//                 <p
//                   className="fw-bold myparagraphings mb-0 mt-0 text-center"
//                   style={{ fontSize: 15 }}
//                 >
//                   {props.orderId}
//                 </p>
//               </div>
//             {/* </div> */}
//           </div>

//           {/* </div> */}
//           {/* </div> */}
//         </div>

//         {/* Shipping */}

//         <div>
//           <div className="d-flex">
//             <h6 className="fw-bold">Shipping Details</h6>
//           </div>
//           <div className="d-flex mt-1" style={{ marginBottom: -10 }}>
//             <h6 className="fw-bold myparagraphings">Shipped By:</h6>
//             &nbsp; &nbsp;
//             <p className="fw-bold myparagraphings">DTDC</p>
//           </div>

//           <div className="d-flex" style={{ marginBottom: -10 }}>
//             <h6 className="fw-bold myparagraphings">Routing Code:</h6>
//             &nbsp; &nbsp;
//             <p className="fw-bold myparagraphings">NA</p>
//           </div>

//           <div style={{ marginBottom: -10 }}>
//             <h6 className="fw-bold myparagraphings">AWB Tracking Number </h6>
//           </div>
//           <div>
//             <Barcode
//               value="U20531307"
//               displayValue={false}
//               format="CODE128"
//               width={1.8}
//               height={50}
//               font="sans-serif"
//               fontSize={15}
//               fontWeight="bold"
//             />
//             <p
//               className="fw-bold myparagraphings mb-0=1 mt-0 text-center"
//               style={{ fontSize: 15 }}
//             >
//               U20531307
//             </p>
//           </div>
//           <div>
//             <p className="fw-bold myparagraphings mb-0">Payment Method</p>
//             <p className="fw-bold myparagraphings">
//               Netbanking/ Debit Card / Credit Card
//             </p>
//           </div>
//         </div>
//       </div>

//       {/* Second Section  */}
//       <div className="d-flex align-items-center mt-2 justify-content-around p-3 pb-0">
//         <table className="table table-bordered border-0">
//           <thead className="table-secondary border-0">
//             <tr>
//               <th scope="col-6 " className="fw-bolder myparagraphings">
//                 Billing Address
//               </th>
//               <th scope="col-6" className="fw-bolder myparagraphings">
//                 Shipping Address
//               </th>
//             </tr>
//           </thead>
//           <tbody>
//             <tr>
//               {props.billingAddress ? (
//                 <td colSpan="1">
//                 <p className="myparagraphings mb-0">{props.billingAddress.fullname}</p>
//                 <p className="myparagraphings mb-0">{props.billingAddress.addressLineOne}</p>
//                 <p className="myparagraphings mb-0">{props.billingAddress.addressLineTwo}</p>
//                 <p className="myparagraphings mb-0">{props.billingAddress.city}</p>
//                 <p className="myparagraphings mb-0">
//                   {props.billingAddress.state},{" "}{props.billingAddress.zipCode}, {props.billingAddress.country}
//                 </p>
//                 <p className="myparagraphings mb-0">{props.billingAddress.email}</p>
//                 <p className="myparagraphings mb-0">{props.billingAddress.phone}</p>
//               </td>): 
//               <td>
//               <p className="myparagraphings mb-0">Same as Shipping Address</p>
//               </td>
//               }
              
//               <td colSpan="1">
//                 <p className="myparagraphings mb-0">{props.shippingAddress.fullname}</p>
//                 <p className="myparagraphings mb-0">{props.shippingAddress.addressLineOne}</p>
//                 <p className="myparagraphings mb-0">{props.shippingAddress.addressLineTwo}</p>
//                 <p className="myparagraphings mb-0">{props.shippingAddress.city}</p>
//                 <p className="myparagraphings mb-0">
//                 {props.shippingAddress.state},{" "}{props.shippingAddress.zipCode}, {props.shippingAddress.country}
//                 </p>
//                 <p className="myparagraphings mb-0">{props.shippingAddress.email}</p>
//                 <p className="myparagraphings mb-0">{props.shippingAddress.phone}</p>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </div>

//       {/* Third Section */}
//       <div className="p-3 fw-bolder" style={{ fontSize: 12 }}>
//         Shipment Weight: {props.totalWeight} Kg
//       </div>
//       <div className="d-flex align-items-center mt-2 justify-content-around p-3 pt-1 pb-2">
//         <table className="table table-bordered table-sm table-responsive border-0">
//           <thead
//             className="border-0 table-secondary"
//             style={{ borderBottomWidth: "1px!important" }}
//           >
            
//             <tr>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 S#
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Product
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 HSN
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Unit Price
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Quantity
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Discount
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Taxable Amount
//               </th>
//               <th colSpan="2" scope="col" className="fw-bolder myparagraphings">
//                 CGST
//               </th>
//               <th colSpan="2" scope="col" className="fw-bolder myparagraphings">
//                 SGST/UTGST
//               </th>
//               <th colSpan="2" scope="col" className="fw-bolder myparagraphings">
//                 IGST
//               </th>
//               <th colSpan="1" scope="col" className="fw-bolder myparagraphings">
//                 Sub Total
//               </th>
//             </tr>
//             <tr>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings"></th>
//               <th className="fw-bolder myparagraphings">Rate</th>
//               <th className="fw-bolder myparagraphings">Amt</th>
//               <th className="fw-bolder myparagraphings">Rate</th>
//               <th className="fw-bolder myparagraphings">Amt</th>
//               <th className="fw-bolder myparagraphings">Rate</th>
//               <th className="fw-bolder myparagraphings">Amt</th>
//               <th className="fw-bolder myparagraphings"></th>
//             </tr>
//           </thead>
//           <tbody>
//             {props.orderedItems.map((items) => (
//               <tr>
//               <td>
//                 <p className="myparagraphings mb-0">1</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">
//                   {items.productName}
//                 </p>
//                 <p className="myparagraphings mb-0">SKU : {items.productSku}</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">6403</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{props.currencySymbol}{items.productPrice}</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{items.qty}</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{items.discountAmount === null ? `${props.currencySymbol}0.00`:props.currencySymbol +items.discountAmount}</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{props.currencySymbol}{items.taxAmount}</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">0.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{props.currencySymbol}0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">0.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{props.currencySymbol}0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">0.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">{props.currencySymbol}0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}{items.finalPriceInclTax}</p>
//               </td>
//             </tr>
//             ))}
//             {/* <tr>
//               <td>
//                 <p className="myparagraphings mb-0">1</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">
//                   CLIFF CLIMBERS Sleeping Bag POLARLITE
//                 </p>
//                 <p className="myparagraphings mb-0">Model : 200 , SKU : 200</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">6403</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.1,590.63</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">1</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.3,805.08</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">0.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">0.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.0.00</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">18.00%</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0">Rs.684.92</p>
//               </td>

//               <td>
//                 <p className="myparagraphings mb-0 text-end">Rs.4,490.00</p>
//               </td>
//             </tr> */}

//             {/* Second row at Table */}
//             <tr>
//               <td colSpan="4">
//                 <h6 className="myparagraphings mb-0 text-end fw-bolder">
//                   Quantity Total :
//                 </h6>
//               </td>
//               <td>
//                 <p className="myparagraphings mb-0">{props.totalQty}</p>
//               </td>
//               <td colSpan="6">
//                 <p className="myparagraphings mb-0 text-end fw-bolder">
//                   Free Shipping:
//                 </p>
//               </td>
//               <td colSpan="3">
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}0.00</p>
//               </td>
//             </tr>

            

//             {/* Third Row at Table */}
//             <tr>
//               <td colSpan="11">
//                 <h6 className="myparagraphings mb-0 text-end fw-bolder">
//                   Sub-Total:
//                 </h6>
//               </td>

//               <td colSpan="3">
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}{props.subTotal}</p>
//               </td>
//             </tr>

//             {/* Fourth Row at Table */}

//             <tr>
//             <td colSpan="11">
//                 <h6 className="myparagraphings mb-0 text-end fw-bolder">
//                   Delivery Charges:
//                 </h6>
//               </td>

//               <td colSpan="3">
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}{props.delieveryCharges}</p>
//               </td>
//             </tr>

//             {/* Fifth Row at Table */}
//             <tr>
//               <td colSpan="11">
//                 <h6 className="myparagraphings mb-0 text-end fw-bolder">
//                   GST 18% (Inclusive):
//                 </h6>
//               </td>

//               <td colSpan="3">
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}0.00</p>
//               </td>
//             </tr>

//             {/* Sixth Row at Table */}
//             <tr>
//               <td colSpan="11">
//                 <h6 className="myparagraphings mb-0 text-end fw-bolder">
//                  Total:
//                 </h6>
//               </td>

//               <td colSpan="3">
//                 <p className="myparagraphings mb-0 text-end">{props.currencySymbol}{props.grandTotal}</p>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </div>

//       {/* Table Ends */}

//       <div className="p-3 mt-0 pt-0 myparagraphings pb-1">
//         <b>Total Amount in words ( INR )</b> : <span className="text-capitalize">{props.wordsInRs} only.</span>
//       </div>
//       <div className="p-3 mt-0 pt-0 myparagraphings">
//         Whether tax payable on reverse charge basis - No
//       </div>

//     <div className="d-flex">
//       <div style={{flex: 2}}>

//       <div>
//           <p className="ms-3 mt-0 pt-1 myparagraphings pb-0 mb-1">
//             DISCLAIMER :
//           </p>
//         </div>
//         <div>
//           <p className="ms-3 mt-0 myparagraphings pb-0">
//             TERMS AND CONDITIONS :
//           </p>
//         </div>

//       </div>
        
      
//         <div style={{flex: 1}}>
//         <div>
//           <img
//             src="https://ik.imagekit.io/bfrs/tr:w-100,h-100,pr-true,cm-pad_resize,bg-FFFFFF/image_cliffclimber/"/>
//         </div>
//         <div>
//         <p className="myparagraphings">(Authorised Signatory)</p>
//         </div>
//         </div>
        
//       </div>


//     </div>
//   </div>
//   </ReactToPrint>
// ));

// export default Invoice;
