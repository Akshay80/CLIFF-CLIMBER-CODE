import React, { useState, useRef, useEffect } from "react";
import Table from "react-bootstrap/Table";
import { useParams } from "react-router-dom";
import ReactToPrint, { useReactToPrint } from "react-to-print";
import {
  setOrderState,
  viewInvoicebyId,
} from "../../../../../Services/orderService";
import { updateTrackingDetails } from "../../../../../Services/trackingService";
import Invoice from "./Invoice";
import moment from "moment/moment";
import numWords from "num-words";
import { Button, Form, Modal } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import { confirmAlert } from "react-confirm-alert";

const OrderDetail = ({ orderItems, paymentstate, orderState }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();
  const [show, setShow] = useState(false);
  const [billingAddress, setBillingAddress] = useState([]);
  const [shippingAddress, setShippingAddress] = useState([]);
  const [orderedItems, setOrderItems] = useState([]);
  const [totalQty, setTotalQty] = useState(0);
  const [grandTotal, setGrandTotal] = useState(0);
  const [subTotal, setSubTotal] = useState(0);
  const [currencySymbol, setCurrency] = useState("₹");
  const [delieveryCharges, setDelieveryCharges] = useState(0);
  const [totalWeight, setTotalWeight] = useState(0);
  const [orderNumber, setOrderNumber] = useState(0);
  const [orderDate, setOrderDate] = useState("");
  const [wordsInRs, setWordsInRs] = useState(0);
  const componentRef = useRef(null);
  const handleClose = () => {
    setShow(false);
    reset();
  };
  const handleShow = () => setShow(true);
  const { orderId } = useParams();

  const [ship, setShip] = useState("Not yet select!");
  const [track, setTrack] = useState(0);
  const [shipping, setShippingMethod] = useState("");
  const [tracking, setTrackingID] = useState(0);
  // const [isCancel, setisCancel] = useState(true);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });

  useEffect(() => {
    getInvoiceByID();
  }, [orderId, shipping, tracking]);

  const getInvoiceByID = async () => {
    await viewInvoicebyId(orderId)
      .then((response) => {
        setShippingMethod(response?.data?.data?.shippingMethod);
        setTrackingID(response?.data?.data?.trackingId);
        setBillingAddress(response?.data?.data?.billingAddress);
        setShippingAddress(response?.data?.data?.shippingAddress);
        setOrderItems(response?.data?.data?.OrderItems);
        setTotalQty(response?.data?.data?.totalQty);
        setGrandTotal(response?.data?.data?.grandTotal);
        setSubTotal(response?.data?.data?.subTotal);
        setCurrency(response?.data?.data?.currencySymbol);
        setDelieveryCharges(response?.data?.data?.deliveryCharges);
        setTotalWeight(response?.data?.data?.totalWeight);
        setOrderNumber(response?.data?.data?.orderNumber);
        setOrderDate(
          moment(response?.data?.data?.createdAt).format("DD/MM/YYYY")
        );
        setWordsInRs(numWords(response?.data?.data?.grandTotal));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const trackDataSubmit = (data) => {
    const params = {
      shippingMethod: data.shippingMethod,
      trackingId: data.trackingId,
      orderId: orderId,
    };
    updateTrackingDetails(params)
      .then((res) => {
        setShip(res?.data?.data?.shippingMethod);
        setTrack(res?.data?.data?.trackingId);
        toast.success(res.data.data, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
        });
        reset();
        handleClose();
        getInvoiceByID();
      })
      .catch((error) => {
        console.log(error);
        toast.error(error, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
        });
      });
  };

  const handleDelete = async () => {
    const params = {
      id: orderId,
      type: "5",
    };

    await setOrderState(params)
      .then((response) => {
        console.log(response.data.data);
        // setisCancel(true);
        toast.success(response.data.data, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: false,
          progress: 0,
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const confirmCancel = () => {
    confirmAlert({
      title: "Cancel",
      message: `Are you sure you want to cancel this order?`,
      buttons: [
        {
          label: "Yes",
          className: "btn btn-danger",
          onClick: () => {
            handleDelete();
          },
        },
        {
          label: "No",
          className: "btn btn-success",
        },
      ],
    });
  };

  return (
    <div className="card shadow my-2">
      <div className="flex justify-between card-header">
        <h2 className="card-title ">
          <div className="flex justify-between space-x-1">
            Ordered Items
            {/* {paymentstate === "PENDING" && (
              <>
                <span className="circle default">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Pending</span>
              </>
            )}

            {paymentstate === "PROCESSING" && (
              <>
                {" "}
                <span className="warning circle">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Processing</span>
              </>
            )}

            {paymentstate === "COMPLETE" && (
              <>
                <span className=" circle success ">
                  <span className="self-center">
                    <span></span>
                  </span>
                </span>
                <span className="mx-1">Paid</span>
              </>
            )} */}
          </div>
        </h2>
      </div>
      <div className="card-section box-border">
        <div className="card-session-content pt-lg">
          <div className="row">
            <table className="table">
              <tbody>
                {orderItems?.map((items, index) => (
                  <tr key={index}>
                    <td className="p-2">
                      {" "}
                      {/* {console.log("suraj", items)} */}
                      <div className="product-thumbnail ">
                        <div className="thumbnail">
                          <svg
                            style={{ width: "2rem" }}
                            fill="currentcolor"
                            viewBox="0 0 20 20"
                            focusable="false"
                            aria-hidden="true"
                          >
                            <path
                              fillRule="evenodd"
                              d="M6 11h8V9H6v2zm0 4h8v-2H6v2zm0-8h4V5H6v2zm6-5H5.5A1.5 1.5 0 0 0 4 3.5v13A1.5 1.5 0 0 0 5.5 18h9a1.5 1.5 0 0 0 1.5-1.5V6l-4-4z"
                            ></path>
                          </svg>
                        </div>
                        <span className="qty rounded-pill w-50">
                          {items?.qty}
                        </span>
                      </div>
                    </td>
                    <td>
                      {" "}
                      <span className="font-semibold ">
                        {`${items?.productName}  ${
                          items?.attribute === undefined
                            ? ""
                            : `(${items?.attribute?.map((item) => {
                                return " " + item?.toUpperCase() + " ";
                              })})`
                        }`}
                      </span>
                      {console.log(items)}
                    </td>
                    <td>
                      {" "}
                      <span>{items.qty}</span>
                    </td>
                    <td>
                      {" "}
                      <span className="">
                        {items?.total === null ? "₹0.00" : `₹${items?.total}`}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <hr />
          <div className="container-fluid ms-5">
            {/* <div className="row">
              <div className="col-6">
                <p style={{ fontSize: 14 }}>Tracking ID</p>
              </div>
              <div className="col-6">
                <p style={{ fontSize: 14 }}>
                  {tracking !== null ? tracking : 0}
                </p>
              </div>
            </div>
            <div className="row">
              <div className="col-6">
                <p style={{ fontSize: 14 }}>Shipment service</p>
              </div>
              <div className="col-6">
                <p style={{ fontSize: 14 }}>
                  {shipping !== null ? shipping : "Not Yet Selected!"}
                </p>
              </div>
            </div> */}
            <div className="row">
              <h6 className="fw-bold">
                <i class="fa fa-truck"></i> Shipping Details
              </h6>
              <p style={{ fontSize: 14 }}>
                {shipping !== null ? shipping : "Not Yet Selected!"} |{" "}
                {tracking !== null ? tracking : 0}
              </p>
            </div>
          </div>

          <div className="card-section pt-2">
            <div className="card-session-content pt-lg">
              {/* <div className="flex justify-content-around"> */}
              <div className="container-fluid">
                <div className="row text-center">
                  {/* GENERATE INVOICE */}
                  {/* <div className="col-md-6 col-xs- btn-block mt-2 mb-2">
                
               
                <button  variant="primary"
                        type="button"
                        
                        className=" btn btn-dark btn-full btn-lg border-0" style={{color: '#fff', fontSize: 14}} onClick={handlePrint}>Generate the Invoice</button>
                </div> */}
                  <div className="col-md-6 col-xs-12  btn-block mt-2 mb-2">
                    {orderState === "OUT-FOR-DELIVERY" ||
                    orderState === "SHIPPED" ? null : (
                      <button
                        variant="primary"
                        onClick={handleShow}
                        type="button"
                        style={{ fontSize: 14 }}
                        className=" btn btn-full btn-dark btn-lg border-0"
                      >
                        Add your tracking number
                      </button>
                    )}
                  </div>
                  <div className="col-md-6 col-xs-12 btn-block mt-2 mb-2">
                    <button
                      variant="primary"
                      type="button"
                      style={{ fontSize: 14 }}
                      className=" btn btn-full btn-dark btn-lg border-0"
                      onClick={confirmCancel}
                      disabled={orderState === "CANCELLED" ? true : false}
                    >
                      {orderState === "CANCELLED"
                        ? "Order has been cancelled"
                        : "Cancel your current order"}
                    </button>
                  </div>
                </div>
                {/* </div> */}
              </div>
            </div>
          </div>
          {/* <div className="d-none">
            <ReactToPrint documentTitle="Invoice">
          <Invoice ref={componentRef} billingAddress={billingAddress} shippingAddress={shippingAddress} orderedItems={orderedItems} totalQty={totalQty} grandTotal={grandTotal} subTotal={subTotal} currencySymbol={currencySymbol} delieveryCharges={delieveryCharges} totalWeight={totalWeight} orderId={orderNumber} orderDate={orderDate} wordsInRs={wordsInRs}/>
          </ReactToPrint>
          </div> */}

          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton className="border-0 pb-0">
              <Modal.Title>Add Tracking Details</Modal.Title>
            </Modal.Header>
            <Form onSubmit={handleSubmit(trackDataSubmit)}>
              <Modal.Body>
                <div className="form-field-container null">
                  <label htmlFor="tracking">Tracking Id</label>

                  <div className="field-wrapper flex flex-grow">
                    <input
                      type="text"
                      name="trackingId"
                      placeholder="Tracking Id"
                      className="outline-none shadow-none"
                      {...register("trackingId", {
                        required: "Tracking Id is required!"
                      })}
                    />

                    <div className="field-border"></div>
                  </div>
                </div>
                {errors.trackingId && (
                  <p className="errors">{errors.trackingId.message}</p>
                )}
                <div className="form-field-container null">
                  <label htmlFor="career">Carreer</label>
                  <div className="field-wrapper flex flex-grow">
                    <select
                      className="form-field"
                      id="group_id"
                      name="shippingMethod"
                      {...register("shippingMethod", {
                        required: "THIS IS REQUIRED!",
                      })}
                    >
                      <option selected={true} disabled value="">
                        Please select
                      </option>
                      <option value="delhivery">Delhivery</option>
                      <option value="dtdc">DTDC</option>
                      <option value="indiapost">India Post</option>
                    </select>
                    <div className="field-border"></div>
                  </div>
                </div>
              </Modal.Body>
              <Modal.Footer className="border-0">
                <Button
                  className="btn-full border-0"
                  variant="dark"
                  onClick={handleClose}
                >
                  Close
                </Button>
                <Button
                  className="btn-full border-0"
                  variant="primary"
                  type="submit"
                  // onClick={handleClose}
                >
                  Save
                </Button>
              </Modal.Footer>
            </Form>
          </Modal>
        </div>
      </div>
    </div>
  );
};
export default OrderDetail;
