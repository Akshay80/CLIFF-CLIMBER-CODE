import React from 'react'

const ResetPassword = () => {
    return (
        <div>
            
        </div>
    )
}

export default ResetPassword
