export function getToken() {
  let token = localStorage.getItem("token");
  if (token) {
    return true;
  } else {
    window.history.pushState(null, document.title, window.location.href);
    return false;
  }
}

export function setUserDetail(userDetail) {
  localStorage.setItem("userDetail", userDetail);
}

export function setUserToken(token) {
  if (token !== undefined) {
    localStorage.setItem("token", token);
  } else {
    window.history.pushState(null, document.title, window.location.href);
    window.addEventListener('popstate', function (event)
{
  window.history.pushState(null, document.title, window.location.href);
});
  }
}

export function getUserToken() {
  return localStorage.getItem("token");
}

export function clearToken() {
  localStorage.removeItem("token");
  window.history.pushState(null, document.title, window.location.href);
  window.addEventListener('popstate', function (event)
{
  window.history.pushState(null, document.title, window.location.href);
});
}
