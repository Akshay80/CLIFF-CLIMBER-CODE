import React from "react";
import { Routes, Route } from "react-router-dom";
import UserProfile from "../Components/Common/UserInfo/UserProfile";
import Path from "../Constant/RouterConstant";
import DefaultLayout from "../Layout/DefaultLayout/DefaultLayout";
import Dashboard from "../Pages/Dashboard";
import Customer from "../Pages/UserManagement/Customer/Customer";
import CustomerDetail from "../Pages/UserManagement/Customer/CustomerDetail";
import Categories from "../Pages/ProductManagement/Categories/Categories";
import Tags from "../Pages/ProductManagement/Tags/Tags";
import Ingredients from "../Pages/ProductManagement/Ingredients/Ingredients";
import OrderManagement from "../Pages/OrderManagement";
import OrderProfile from "../Pages/OrderManagement/OrderProfile/OrderProfile";
import ChangePassword from "../Components/Auth/ChangePassword/ChangePassword";
// import TaxTable from "../Components/Common/Table/TaxTable/TaxTable";
import DiscountTable from "../Components/Common/Table/DiscountTable/DiscountTable";
import FoodTable from "../Components/Common/Table/FoodTable/FoodTable";
import ApprovedOrder from "../Pages/OrderManagement/ApprovedOrder/ApprovedOrder";
import RejectedOrder from "../Pages/OrderManagement/RejectedOrder/RejectedOrder";
import CompletedOrder from "../Pages/OrderManagement/CompletedOrder/CompletedOrder";
import CancelledOrder from "../Pages/OrderManagement/CancelledOrder/CancelledOrder";
import OfferTable from "../Components/Common/Table/OfferTable/OfferTable";
import SubCategories from "../Pages/ProductManagement/SubCategories/SubCategories";
import Banner from "../Pages/WebManagement/Banner/Banner";
import Attribute from "../Pages/WebManagement/Attribute/Attribute";
import Brand from "../Pages/WebManagement/Brand/Brand";
import PartnerTable from "../Components/Common/Table/PartnerTable/PartnerTable";
import PincodeTable from "../Components/Common/Table/PincodeTable/PincodeTable";
import PromoBanner from "../Pages/WebManagement/PromoBannerTable/PromoBannerTable";
import AboutUs from "../Pages/CMS/AboutUs/AboutUs";
import AllProductsTable from "../Components/Common/Table/ProductTable/AllProductsTable";
import AddProduct from '../Components/Common/Cards/ProductCard/AddProduct';
import EditProduct from '../Components/Common/Cards/ProductCard/EditProduct';
import GSTTable from "../Components/Common/Table/GSTTable/GSTTable";
import PrivacyPolicy from "../Components/Common/Cards/PrivacyPolicyCard/PrivacyPolicy";
import TermsandCondtions from "../Components/Common/Cards/TermsandConditonCard/TermsandCondition";
import OrdersTable from "../Components/Common/Table/OrdersTable/OrdersTable";
import OrderEdit from "../Components/Common/Cards/OrderEdit/OrderEdit";
import ReviewTable from "../Components/Common/Table/ReviewTable/ReviewTable";
import Invoice from "../Components/Common/Cards/OrderEdit/OrderEditComp/Invoice";
import ShippingandReturn from '../Components/Common/Cards/ShippingandReturnCard/ShippingandReturn';
import FeedbackTable from "../Components/Common/Table/FeedbackTable/FeedbackTable";
import ReasonTable from "../Components/Common/Table/ReasonTable/ReasonTable";
import UnitTable from "../Components/Common/Table/UnitTable/UnitTable";
import NotFound from "../Pages/404/404";
import MobileBannerTable from "../Components/Common/Table/MobileBannerTable/MobileBannerTable";

function PrivateRoutes() {
  return (
    <Routes>
      <Route path={Path.dashboard} element={<DefaultLayout />}>
        <Route path={Path.changePassword} element={<ChangePassword />} />
        <Route path={""} element={<Dashboard />} />
        <Route path={Path.customer} element={<Customer />} />
        <Route
          path={`${Path.customerDetails}/:customerId`}
          element={<CustomerDetail />}
        />
        <Route path={`${Path.editOrders}/:orderId`} element={<OrderEdit />} />
        <Route path={Path.attribute} element={<Attribute />}/>
        <Route path={Path.categories} element={<Categories />} />
        <Route path={Path.subcategory} element={<SubCategories />} />
        <Route path={Path.banner} element={<Banner />} />
        <Route path={Path.banners} element={<PromoBanner />} />
        <Route path={Path.brand} element={<Brand />} />
        <Route path={Path.tags} element={<Tags />} />
        <Route path={Path.partner} element={<PartnerTable />} />
        <Route path={Path.pincode} element={<PincodeTable />} />
        <Route path={Path.about} element={<AboutUs />} />
        <Route path={Path.privacy} element={<PrivacyPolicy />} />
        <Route path={Path.terms} element={<TermsandCondtions />} />
        <Route path={Path.shipping} element={<ShippingandReturn />} />
        <Route path={Path.products} element={<AllProductsTable />} />
        <Route path={Path.product} element={<AddProduct />} />
        <Route
          path={`${Path.product}/:id`}
          element={<EditProduct />}
        />
        <Route path={Path.reviews} element={<ReviewTable />} />
        <Route path={Path.gst} element={<GSTTable />} />
        <Route path={Path.discount} element={<DiscountTable />} />
        <Route path={Path.promotion} element={<OfferTable />} />
        <Route path={Path.ingredients} element={<Ingredients />} />
        <Route path={Path.orderManagement} element={<OrderManagement />} />
        <Route path={Path.orders} element={<OrdersTable />} />
        <Route path={Path.approvedOrder} element={<ApprovedOrder />} />
        <Route path={Path.rejectedOrder} element={<RejectedOrder />} />
        <Route path={Path.completedOrder} element={<CompletedOrder />} />
        <Route path={Path.cancelledOrder} element={<CancelledOrder />} />
        <Route path={`${Path.orderDetails}/:orderId`} element={<OrderProfile />} />
        <Route path={Path.userProfile} element={<UserProfile />} />
        <Route path={Path.food} element={<FoodTable />} />
        <Route path={Path.invoice} element={<Invoice />} />
        <Route path={Path.feedback} element={<FeedbackTable />} />
        <Route path={Path.reason} element={<ReasonTable />} />
        <Route path={Path.unit} element={<UnitTable />} />
        <Route path={Path.mobilebanner} element={<MobileBannerTable />} />
      </Route>
    
    </Routes>
  );
}

export default PrivateRoutes;
